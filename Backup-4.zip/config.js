const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// --------------( Settings Owner )-------------- \\
global.nomorowner = ["6283132860356", "000"]
global.owner = "6283132860356"
global.versi = "11.0.0"
global.namaowner = "Danny S8X" // jangan di ubah
global.namadev = "Danny S8X" // jangan di ubah

// --------------( Settings Bot )-------------- \\
global.prefa = ["","!",".",",","#","/","🎭","〽️"]
global.filenames = "../system/DannyS8X.js"
global.packname = 'WhatsApp Bot Danny S8X'
global.botname = 'Simple Bot Generasi 11'
global.generasi = '𝐕𝐞͢𝐫𝐬𝐢͢𝐨𝐧͢𝐬 𝟏𝟏'
global.title = '𝐃𝐚𝐧𝐧͜͡𝐲 𝐒𝟖𝐗 シ'
global.footer = '𝐃𝐚𝐧𝐧𝐲 𝐒𝟖𝐗 ☇ 3𝒔𝑪𝒂𝒏𝒏𝒐𝒓'
global.author = '𝐃𝐚𝐧𝐧𝐲 𝐒𝟖𝐗 𝟓𝟗𝟗 シ'
global.botname2 = 'Simple Bot V11'
global.wm = "Simple Bot"
global.baileys = "baileys" // jangan ubah
global.pairing = "TAMAXSSS" // jangan ubah

// --------------( Settings Telegram )-------------- \\
module.exports = {
  BOT_TOKEN: "7904965972:AAFD0h_0ywcYj9BHmG-SQSaf0SUKTQkBSxg",
    allowedDevelopers: ['7453694313'], // ID
};

// --------------( Settings Sosmed )-------------- \\
global.ytdev = 'https://youtube.com/@DannyS8Xtzy'
global.sosmed = 't.me/DannyS8Xror'
global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah
global.linkOwner = "https://wa.me/6283132860356" // jan di ubah

// --------------( Settings Nickname )-------------- \\
global.bugs = {
forclose: "⭑̤⟅̊༑ ▾  ⿻ тαмα ιиfιиιту ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤‏‎‏‎‏‎‏",
delay: "𝕿𝖍𝖆𝖓𝕮𝖑𝖊𝖛𝖊𝖗 ༚👻⃰ꢵ"
}

// --------------( Settings Group )-------------- \\
global.linkgbbuypublic = "" // masukkan link grub reseller panel
global.linkgcreseller = "" // masukkan link grub reseller panel
global.linkGrup = "https://chat.whatsapp.com/GA2wiiKuj6PJfnjtD7oBiF"

// --------------( Settings Apikey )-------------- \\
global.apipayment = "new"
global.apipayment2 = "NabzxBotz"
global.apiSimpleBot = "simplebotz85"
global.apikey = "zakkigans12"

// --------------( Settings Jeda )-------------- \\
// --------------( 1000 = 1 Detik )-------------- \\
global.delayjpmch = 2000
global.delayJpm = 3500
global.delayPushkontak = 3000

// --------------( Settings Vercel )-------------- \\
global.vercelToken = "-"

// --------------( Settings Github )-------------- \\
global.githubToken = "-" //Your GitHub Token
global.githubUsername = "-" //Your GitHub Username

// --------------( Settings Saluran )-------------- \\
global.salurantestimoni = "https://whatsapp.com/channel/0029Vav8XGHL2ATznQc17P3A"
global.linkSaluran = "https://whatsapp.com/channel/0029Vaion3d6hENjxVNaMS02"
global.linkChannel = "https://whatsapp.com/channel/0029Vaion3d6hENjxVNaMS02"
global.idSaluran = "120363333324119584@newsletter"
global.namaSaluran = "Danny S8X OfficiaL"
global.grubmarketplace = "https://chat.whatsapp.com/GA2wiiKuj6PJfnjtD7oBiF"

// --------------( Settings Orkut )-------------- \\
global.IdMerchant = "OK1755355"
global.ApikeyOrderKuota = "168947917342696541755355OKCT0C356C5BE567AEC3D8EA992E37B5D7A0"
global.QrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214703095830176330303UMI51440014ID.CO.QRIS.WWW0215ID20243219240010303UMI5204541153033605802ID5921MAULL STORE OK17553556006BEKASI61051711162070703A0163043D20"
global.pworkut = ""
global.pinorkut = ""
global.apidigitalocean = ""
global.pinH2H = ""
global.passwordH2H = ""

// --------------( Settings Token )-------------- \\
global.tokeninstall = "skyzodev"
global.bash = "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)"

// --------------( Settings Cloudflare )-------------- \\
global.apitoken_cloudflare = ""
global.accountid_cloudflare = ""
global.email_cloudflare = ""


// --------------( Settings All Payment )-------------- \\
global.dana = "000"
global.namadana = 'R*****'
global.ovo = "Tidak Tersedia"
global.gopay = "000"
global.namagopay = 'R*****'

// --------------( Settings Thumbnail )-------------- \\
global.image = {
menu: "https://github.com/kiuur.png", 
reply: "https://files.catbox.moe/5xwxv6.jpg", 
logo: "https://files.catbox.moe/5xwxv6.jpg", 
dana: "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg", 
ovo: "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg", 
gopay: "https://img100.pixhost.to/images/667/540083275_skyzopedia.jpg", 
qris: "https://img100.pixhost.to/images/926/543616090_DannyS8Xdeveloper.jpg"
}
global.video = 'https://files.catbox.moe/ysvq2o.mp4'

// --------------( Settings Panel V1 )-------------- \\
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://tamamods.kantinvps.my.id" // Hapus Tanda / di akhir domain
global.apikey = "ptla_KJRrgr5Wh2tuH0YPN5xbabeQX59Vg2Shc2JIHfSUopz" //ptla
global.capikey = "ptlc_YHkE5j9pevqXxSHwfVIfl4rSCY6xX47Py6orUidnahu" //ptlc

// --------------( Settings Panel V2 )-------------- \\
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "" // Hapus Tanda / di akhir domain
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc

// --------------( Settings Lainnya )-------------- \\
global.linktutor = 'https://youtu.be/bWsTCzmkI7E?si=gTsV3GXAl-W1V5rh'

// --------------( Settings Subdomain )-------------- \\
global.subdomain = {
"thandev.my.id": {
"zone": "a2d5c6358889833d655bbcc8b722658f", 
"apitoken": "5pRg7xCP9q9V5Q4OPG_fN2Uu9lvO1BQHDG3IxY52"
}, 
"thangtg.xyz": {
"zone": "e0f0aa7c1b552528c4491b962792a94b", 
"apitoken": "_K8xAxwtMeAeuyxLc6H6MheHDXWFEVBFucPJRHq4"
}, 
"thanoffc.store": {
"zone": "9c9f5e3b6be87836c14caedd44669de6", 
"apitoken": "U9DDNRA4TVCpra_mTXlD6n0CgLpc57FwHn4pB9gQ"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535",
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"reseller-panel.me": {
"zone": "b1efab0f1d81a0137eb5d62e00d6e3f8",
"apitoken": "W3b66ootKk1pERNSB6DbyW383OXRCoakw3PQExyS"
},
"fayypedia.xyz": {
"zone": "061040b178a09e07bcb1c989dfc0c171", 
"apitoken": "VBkoU8H4ZcpZnb2Q_m_dHGtGL4IAeZUXGpwCg71S"
}, 
"fayzaafx.my.id": {
"zone": "2688ec16cf017d8b76b056992ef77b15", 
"apitoken": "ijjFxobV49FkPMFw1ed-wrjMyRWMF31_0hg8Q0ch"
}, 
"fayzaafx.xyz": {
"zone": "5f4a582dd80c518fb2c7a425256fb491", 
"apitoken": "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby"
}, 
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
},
"fayzaafx.web.id": {
"zone": "422abe2ae8a9225fe824441da4b84645",
"apitoken": "QaeiWSZkabCabpdutbHJ09hAyGtjUpPbCywRiWz2"
},
"zcake.us.kg": {
"zone": "63729ecb4fb36abf6a546aa8d0f2090d", 
"apitoken": "5zL3j880znmlh3Avpm8lIkrfhdU-khI6njLmJsKH"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283",
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},

"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
},
"kenz-host.my.id": {
"zone": "df24766ae8eeb04b330b71b5facde5f4", 
"apitoken": "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
},
"panelkishop.web.id": {
"zone": "8f4812b3c78ca478b5d162b6cb35d1b3", 
"apitoken": "3Y0cW3cVVIhyeWHytqFEbGDrdWaAC-k8twOEeFP2"
},
"tokopanelkishop.biz.id": {
"zone": "d87d4f320d9902f31fbbcc5ee23fafe8", 
"apitoken": "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535", 
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"rikionline.shop": {
"zone": "082ec80d7367d6d4f7c52600034ac635", 
"apitoken": "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283", 
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE"
}, 
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887", 
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP"
}, 
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41", 
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny"
}, 
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35", 
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa", 
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs"
},
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}

// --------------( Settings Message )-------------- \\
global.mess = {
	owner: "𝗖𝗮𝗻 𝗢𝗻𝗹𝘆 𝗕𝗲 𝗨𝘀𝗲𝗱 𝗕𝘆 𝗢𝘄𝗻𝗲𝗿!",
	seller: "𝗢𝗻𝗹𝘆 𝗨𝘀𝗲𝗱 𝗕𝘆 𝗧𝗵𝗼𝘀𝗲 𝗪𝗵𝗼 𝗛𝗮𝘃𝗲 𝗔𝗱𝗱𝗲𝗱 𝗥𝗲𝘀𝗲𝗹𝗹𝗲𝗿 𝗣𝗮𝗻𝗲𝗹!",
	seller2: "𝗢𝗻𝗹𝘆 𝗨𝘀𝗲𝗱 𝗕𝘆 𝗧𝗵𝗼𝘀𝗲 𝗪𝗵𝗼 𝗛𝗮𝘃𝗲 𝗔𝗱𝗱𝗲𝗱 𝗥𝗲𝘀𝗲𝗹𝗹𝗲𝗿 𝗣𝗮𝗻𝗲𝗹 𝗦𝗲𝗿𝘃𝗲𝗿 𝟮!",
	admin: "𝗖𝗮𝗻 𝗢𝗻𝗹𝘆 𝗕𝗲 𝗨𝘀𝗲𝗱 𝗕𝘆 𝗚𝗿𝗼𝘂𝗽 𝗔𝗱𝗺𝗶𝗻!",
	botAdmin: "𝗖𝗮𝗻 𝗢𝗻𝗹𝘆 𝗕𝗲 𝗨𝘀𝗲𝗱 𝗔𝗳𝘁𝗲𝗿 𝗕𝗼𝘁 𝗕𝗲𝗰𝗼𝗺𝗲𝘀 𝗔𝗱𝗺𝗶𝗻!",
	group: "𝗖𝗮𝗻 𝗢𝗻𝗹𝘆 𝗕𝗲 𝗨𝘀𝗲𝗱 𝗪𝗶𝘁𝗵𝗶𝗻 𝗚𝗿𝗼𝘂𝗽𝘀!",
	prem: "𝗢𝗻𝗹𝘆 𝗖𝗮𝗻 𝗕𝗲 𝗨𝘀𝗲𝗱 𝗕𝘆 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗨𝘀𝗲𝗿𝘀!",
	wait: '𝙒𝙖𝙞𝙩𝙞𝙣𝙜 𝙁𝙤𝙧 𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜 ⏱️',
	error: '𝐄𝐫𝐫𝐨𝐫!',
	bugrespon: '*𝙋𝙧𝙤𝙘𝙚𝙨𝙨⏳*',
	done: '*𝙎𝙪𝙘𝙘𝙚𝙨𝙨🔥*'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})